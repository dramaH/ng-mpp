import { Component, OnInit} from '@angular/core';

@Component({
  selector: 'app-gantt-page',
  templateUrl: './gantt-page.component.html',
  styleUrls: ['./gantt-page.component.less']
})
export class GanttPageComponent implements OnInit {

  async ngOnInit() {

  }




}
