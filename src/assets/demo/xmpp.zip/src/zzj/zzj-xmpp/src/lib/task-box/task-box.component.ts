import { Component, OnInit, Input, ElementRef, SimpleChanges, OnChanges, Inject, ViewChild, Output, EventEmitter } from '@angular/core';
import { NzNotificationService, NzMessageService } from 'ng-zorro-antd';
import moment from 'moment';
import { IXmpp, Xmpp, XmppColumn, PREVTYPE, XmppPredecessorLink, XmppTask } from '../src/api-public';
import { GanttHelperService } from '../gantt-chart-service/gantt-helper.service';
import { isNullOrUndefined } from 'util';
// import { GanttPermission } from '../../../services/gantt-chart/this.Xmpp.permission';



class EditModel {
  public relations: XmppPredecessorLink[];
  public taskName: string;
  public showDuration: number;
  public constructor(param) {
    (param.relations) && (this.relations = param.relations);
    (param.taskName) && (this.taskName = param.taskName);
    (param.showDuration) && (this.showDuration = param.showDuration);
  }
}

declare var Neon: any;
@Component({
  selector: 'app-task-box',
  templateUrl: './task-box.component.html',
  styleUrls: ['./task-box.component.scss']
})
export class TaskBoxComponent implements OnInit {
  @ViewChild('newTaskNameInput', { static: false }) newTaskNameInput: ElementRef;
  @ViewChild('editInput', { static: false }) editInput: ElementRef;
  @Input() Xmpp: Xmpp;
  @Output() newTaskBlur: EventEmitter<void> = new EventEmitter<void>();
  public isVisible = false;
  public currentDate = moment();
  public taskNameWidth = 100;
  public prevTaskWidth = 0;
  public headerWidth = 340;
  public otherWidthTotal = 800;
  public actualDisabled = true;
  public isAllselected = false;

  // 前置任务编辑器

  public editPermission = true;
  columnList = [];

  newTask: any = {
    id: -1,
    taskName: '',
    startDate: null,
    endDate: null
  };
  ctrlDown = false;
  editTaskId: number;
  settingModalView = false;
  editInfo: EditModel;
  PREVTYPE = PREVTYPE;
  settingTask: XmppTask;
  clickTimer: any = null;
  public constructor(
    private _notification: NzNotificationService,
    private ganttHelpServ: GanttHelperService,
    private message: NzMessageService
  ) {
    console.log(this.Xmpp);
    const that = this;
    document.onkeydown = function (event) {
      const e = event || window.event || arguments.callee.caller.arguments[0];
      if (e && e.keyCode === 17) { // 按 Esc
        that.ctrlDown = true;
      }
    };
    document.onkeyup = function (event) {
      const e = event || window.event || arguments.callee.caller.arguments[0];
      if (e && e.keyCode === 17) { // 按 Esc
        that.ctrlDown = false;
      }
    };
  }

  public ngOnInit() {
    // this.headerWidth = this.Xmpp.column.totalWidth;
    // this.columnList = this.Xmpp.column.columnNames;
  }

  editStuteChange(c: XmppColumn, task: XmppTask, open: boolean) {
    if (open) {
      this.editTaskId = task.id;
      c.isEdit = true;
    } else {
      this.editTaskId = null;
      c.isEdit = false;
      if (c.key === 'duration' || c.key === 'actualDuration' || c.type === 'date') {
        this.Xmpp.render();
      }
    }
    setTimeout(() => {
      // console.log(this.editInput)
      if (this.editInput) {
        this.editInput.nativeElement.focus();
      }
    }, 300);
  }



  resizeCallback($event, column) {
    const finder = this.Xmpp.column.columnNames.find((item) => item.key === column.key);
    if (finder) {
      finder.width += $event.x;
      this.Xmpp.column.totalWidth += $event.x;
    }
  }

  addTaskFromNewLine(type: string, $event) {

    if (!$event || $event === '') {
      return;
    }

    this.Xmpp.task.activeTaskId = null;
    if (type === 'name' && $event !== '') {
      this.Xmpp.task.addTaskHandle({ taskName: $event });
    }
    if (type === 'startDate') {
      this.Xmpp.task.addTaskHandle({ startDate: $event, duration: 1 });
    }
    if (type === 'endDate') {
      this.Xmpp.task.addTaskHandle({ endDate: $event, duration: 1 });
    }

    this.newTask = {
      id: -1,
      taskName: '',
      startDate: null,
      endDate: null,
    };

    setTimeout(() => {
      // this.newTask = null;
      this.newTaskBlur.emit();
      setTimeout(() => {
        if (this.editInput) {
          this.editInput.nativeElement.focus();
        }
      }, 500);
    }, 500);
  }

  // 工期blur

  /*
  工作安排中， 禁用计划完成时间早于当前时间的任务
  */
  public isBeforeCurrent(endDate: any) {
    const isPlanning = false;
    if (isPlanning) {
      const currentDate = this.currentDate;
      const isBefore = moment(endDate).isBefore(currentDate);
      if (isBefore) {
        return true;
      } else {
        return false;
      }
    } else {
      return false;
    }
  }


  /*
  * 时间选择器
  */
  public dateClickTask(task: any) {
    this.updateServiceData();
  }

  private updateServiceData() {
    this.Xmpp.render();
  }

  public createNotification = (type, title, message) => {
    this._notification.create(type, title, message);
  }
  public foldTaskLevel(task) {
    const index = task.id - 1;

    const allTasks = this.Xmpp.allTasks;
    const children = allTasks[index].childTaskID;

    for (let i = 0; i < children.length; i++) {
      const child = children[i] - 1;
      allTasks[child].isSelected = false;
    }

    allTasks[index].isFold = true;
    this.Xmpp.render();
  }

  public openTaskLevel(task) {
    const index = task.id - 1;
    this.Xmpp.allTasks[index].isFold = false;
    this.Xmpp.render();
  }


  // 全选
  public selectAllTask() {
    const allTasks = this.Xmpp.allTasks;
    const allSelected = this.isAllselected;
    if (allSelected) {
      allTasks.forEach((element) => {
        element.isSelected = true;
      });
      this.Xmpp.task.selectedTasks = this.Xmpp.allTasks;
    } else {
      allTasks.forEach((element) => {
        element.isSelected = false;
      });
      this.Xmpp.task.selectedTasks = [];
    }
    console.log(this.Xmpp.task.selectedTasks);
    // this.Xmpp.render();
  }

  selectAll() {
    this.Xmpp.task.isAllSelect = !this.Xmpp.task.isAllSelect;
    if (this.Xmpp.task.isAllSelect) {
      this.Xmpp.task.selectedTasks = this.Xmpp.allTasks;
    } else {
      this.Xmpp.task.selectedTasks = [];
    }
    this.Xmpp.allTasks.forEach(task => {
      task.isSelected = this.Xmpp.task.isAllSelect;
    });
    console.log(this.Xmpp.task.selectedTasks);
  }


  clickTaskRow(task?: XmppTask) {
    // if (!this.Xmpp.task.activeTaskId || (this.Xmpp.task.activeTaskId && this.Xmpp.task.activeTaskId !== task.id)) {
    //   this.Xmpp.task.activeTaskId = task.id;
    //   task.isSelected = true;
    // }
    clearTimeout(this.clickTimer);
    let that = this;
    this.clickTimer = setTimeout(function () { //在单击事件中添加一个setTimeout()函数，设置单击事件触发的时间间隔 

      if (that.ctrlDown) {
        task.isSelected = !task.isSelected;
        const index = that.Xmpp.task.selectedTasks.findIndex(item => item.id === task.id);
        if (task.isSelected) {
          if (index === -1) {
            that.Xmpp.task.selectedTasks.push(task);
          }
        } else {
          if (index !== -1) {
            that.Xmpp.task.selectedTasks.splice(index, 1);
          }
        }
      } else {
        that.Xmpp.task.selectedTasks.forEach(task => {
          task.isSelected = false;
        });
        task.isSelected = true;
        if (task.isSelected) {
          that.Xmpp.task.selectedTasks = [task];
        } else {
          that.Xmpp.task.selectedTasks = [];
        }
      }
      if (task.id !== -1) {
        const c = (document.getElementById('maskCanvas')) as HTMLCanvasElement;
        const ctxMask = c.getContext('2d');
        ctxMask.clearRect(0, 0, that.Xmpp.draw.canvasWidth, that.Xmpp.draw.canvasHeight);
        that.Xmpp.draw.drawSelectTask(task.id);
      }
    }, 300);


  }

  /**
   * 双击显示设置弹窗
   * @param task 
   */
  public showSettings(task: XmppTask) {
    clearTimeout(this.clickTimer);
    const relations = [];
    task.prevRelation.forEach((ele) => {
      relations.push(ele);
    });
    if (relations.length === 0) {
      relations.push(new XmppPredecessorLink({
        relation: 1,
        delay: 0
      }));
    }

    const showDuration = task.showDuration;
    this.editInfo = new EditModel({
      relations,
      taskName: task.taskName,
      showDuration
    });
    this.settingTask = task;
    this.settingModalView = true;
  }

  /**
   * 设置弹窗提交事件
   * @param xmpp
   */
  public settingSave() {
    const relations = this.editInfo.relations;
    const prevRelation = [];
    relations.forEach((element) => {
      if (element.prevId && !isNullOrUndefined(element.relation)) {
        prevRelation.push(new XmppPredecessorLink({
          id: element.id,
          prevId: parseInt(element.prevId),
          relation: element.relation,
          delay: element.delay,
          isDelete: element.isDelete
        }));
      }
    });
    const checkResult = this.checkRelations(prevRelation);
    if (checkResult) {
      this.message.error(checkResult);
      // alert(checkResult);
    } else {
      this.settingTask.prevRelation = prevRelation;
      this.settingTask.taskName = this.editInfo.taskName;
      // currentTask.showDuration = this.editInfo.showDuration;
      this.getShowDuration(this.editInfo.showDuration);
      this.Xmpp.render();
      this.settingModalView = false;
    }
  }

  public getShowDuration(value) {
    const wantedShow = value;
    const exceptDate = this.Xmpp.calendar.exceptDate;
    const startDate = this.settingTask.startDate;
    let endDate;
    if (startDate) {
      // 先判断有没有受例外日期的影响
      const startUnix1 = moment(startDate).unix();
      const endUnix1 = moment(startDate).add(wantedShow - 1, 'days').unix();
      // 先根据例外日期，改变任务的开始时间和结束时间
      exceptDate.forEach((item) => {
        let toDate = moment(item.toDate).unix();
        let fromDate = moment(item.fromDate).unix();
        // 任务结束时间在例外日期之间
        if (endUnix1 <= toDate && endUnix1 >= fromDate) {
          const correctDate = moment(item.toDate).clone().add(1, 'days');
          endDate = correctDate;
        }
      });

      // 再统计任务中所有的例外日期总天数
      const startUnix2 = moment(startDate).unix();
      let endUnix2;
      if (endDate) {
        endUnix2 = moment(endDate).unix();
      } else {
        endDate = moment(startDate).add(wantedShow - 1, 'days');
        endUnix2 = endUnix1;
      }
      let allExcept = 0;
      exceptDate.forEach((item) => {
        let toDate = moment(item.toDate).unix();
        let fromDate = moment(item.fromDate).unix();
        // 例外日期在任务的开始时间和结束时间之间
        if (startUnix2 <= toDate && endUnix2 >= fromDate) {
          const exceptDuration = moment(item.toDate).clone().diff(moment(item.fromDate), 'days') + 1;
          allExcept = allExcept + exceptDuration;
        }
      });

      const duration = moment(endDate).clone().diff(moment(startDate), 'days') + 1;
      const showCount = duration - allExcept;

      if (showCount !== wantedShow) {
        const changes = wantedShow - showCount;
        this.settingTask.duration = duration + changes;
      } else {
        this.settingTask.duration = duration;
      }
    } else {
      this.settingTask.duration = value;
      this.settingTask.showDuration = value;
    }
  }

  public checkRelations(relations: any[]) {

    let checkRepeat: string;
    let checkSameId: string;
    let checkLoop: string;
    let checkPrevId: string;
    const allTasks = this.Xmpp.allTasks;
    const taskLength = allTasks.length;
    const usefulRelation = [];
    relations.forEach((rela) => {
      if (!rela.isDelete) {
        usefulRelation.push(rela);
      }
    });
    // 检查4: 非法字符
    usefulRelation.forEach((element) => {
      const id = parseInt(element.prevId);
      if (isNaN(id)) {
        checkPrevId = `任务标识必须为数字`;
        return false;
      } else {
        if (id < 1 || id > taskLength) {
          checkPrevId = `任务标识不存在, error:'${id}'`;
          return false;
        }
      }
    });

    // 检查1： 前置任务id重复
    usefulRelation.forEach((i) => {
      const id = i.prevId;
      const idArray = [];
      usefulRelation.forEach((j) => {
        if (j.prevId === id) {
          idArray.push(j);
        }
      });
      if (idArray.length > 1) {
        checkRepeat = `任务'${idArray[0]}'两次链接到同一个后续任务`;
        return;
      }
    });

    // 检查2：prevId与任务Id相同
    usefulRelation.forEach((element) => {
      const id = element.prevId;
      if (id === this.settingTask.id) {
        checkSameId = `前置任务不能为自己, error:${id}`;
        return;
      }
    });


    // 检查3: 是否产生循环
    usefulRelation.forEach((element) => {
      const id = element.prevId;
      const prevTask = allTasks[id - 1];
      let check;
      if (prevTask && prevTask.prevRelation.length > 0) {
        check = prevTask.prevRelation.findIndex((relation) => {
          return relation.prevId === this.settingTask.id;
        });
        if (check !== -1) {
          checkLoop = `任务'${id}'产生循环`;
          return;
        }
      }
    });

    if (checkPrevId) {
      return checkPrevId;
    } else if (checkRepeat) {
      return checkRepeat;
    } else if (checkSameId) {
      return checkSameId;
    } else if (checkLoop) {
      return checkLoop;
    } else {
      return false;
    }
  }

  public addRelation() {
    this.editInfo.relations.push(new XmppPredecessorLink({
      relation: 1,
      delay: 0
    }));
  }

  public deleteRelation(index: number) {
    // this.editInfo.relations.splice(index, 1);
    this.editInfo.relations[index].isDelete = 1;
  }




  // clickTaskName(task: GanttModel) {
  //   // this.clickCheckBox(task)

  //   // let activeTask = this.Xmpp.task.activeTask;
  //   // if (!this.Xmpp.task.activeTask) {
  //   //   this.Xmpp.task.activeTask = task;
  //   // } else {
  //   //   if (this.Xmpp.task.activeTask.id == task.id) {
  //   //     this.Xmpp.task.activeTask = null
  //   //   } else {
  //   //     this.Xmpp.task.activeTask = task;
  //   //   }
  //   // }
  //   // console.log(this.Xmpp.task.activeTask)
  //   // this.Xmpp.draw.updateCanvasInfo();
  // }


  // public clickCheckBox(task) {
  //   this.Xmpp.task.caculateListener.next();
  // }

  public submitFinishBinds() {
    // this.ganttHelpServ.saveTasksHanle(this.Xmpp, 'save');
  }

  public getActualDate(date) {
    if (date) {
      return moment(date).format('YYYY-MM-DD');
    } else {
      return false;
    }
  }
}
