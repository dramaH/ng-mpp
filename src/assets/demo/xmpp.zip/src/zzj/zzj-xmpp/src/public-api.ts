/*
 * Public API Surface of zzj-mpp
 */

export * from './lib/gantt-chart.module';
export * from './lib/gantt-chart.component';
export * from './lib/src/api-public';
export * from './lib/gantt-chart-service/gantt.config';
export * from './lib/gantt-chart-service/gantt-request.service';
export * from './lib/src/lib/gantt.main';
// export * from './lib/gantt.main';
