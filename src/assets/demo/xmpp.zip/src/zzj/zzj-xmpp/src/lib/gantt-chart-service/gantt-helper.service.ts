import { Injectable } from '@angular/core';
import moment from 'moment';
import { NzMessageService } from 'ng-zorro-antd';
import { GanttRequestService } from './gantt-request.service';
import { PREVTYPE, Xmpp, XmppTask } from '../src/api-public';
import { isNullOrUndefined } from 'util';
@Injectable({
  providedIn: 'root'
})
export class GanttHelperService {
  public settingVisible = false;
  public currentTask: XmppTask;
  // relations: any = [];
  // alreadyDeleteTasks: any[] = [];
  loading = false;
  public constructor(
    private message: NzMessageService,
    private ganttRequestSev: GanttRequestService
  ) {

  }


  // public async saveTasksHanle(xmpp: Xmpp, type: string) {
  //   const getGuid = () => {
  //     const s = [];
  //     const hexDigits = '0123456789abcdef';
  //     for (let i = 0; i < 36; i++) {
  //       s[i] = hexDigits.substr(Math.floor(Math.random() * 0x10), 1);
  //     }
  //     s[14] = '4'; // bits 12-15 of the time_hi_and_version field to 0010
  //     s[19] = hexDigits.substr((s[19] & 0x3) | 0x8, 1); // bits 6-7 of the clock_seq_hi_and_reserved to 01
  //     s[8] = s[13] = s[18] = s[23] = '-';
  //     const uuid = s.join('');
  //     return uuid;
  //   };
  //   const allTasks = xmpp.allTasks;
  //   const taskHasSqlId = [];
  //   const alreadyAddTasks: XmppTask[] = [];
  //   const alreadyEditTasks: XmppTask[] = [];
  //   const alreadyDeleteTasks: XmppTask[] = this.alreadyDeleteTasks;
  //   this.loading = true;

  //   xmpp.mpp.ParentId2WBS();

  //   // 组装 alreadyEditTasks
  //   for (const task of allTasks) {
  //     if (task.defaultData) {
  //       taskHasSqlId.push(task);
  //     } else {
  //       xmpp.task.maxUID = xmpp.task.maxUID + 1;
  //       task.uid = xmpp.task.maxUID;
  //       alreadyAddTasks.push(task);
  //     }
  //   }


  //   // 组装 alreadyEditTasks
  //   for (const element of taskHasSqlId) {
  //     const defaultData = element.defaultData;
  //     const dateKey = ['startDate', 'endDate', 'actualStartDate', 'actualEndDate'];
  //     const arrayKey = ['bindings', 'childTaskID', 'prevRelation'];
  //     for (const itemKey in defaultData) {
  //       // 工期变化不考虑，再次获取tasklist会重新计算工期
  //       if (itemKey === 'duration' || itemKey === 'actualDuration') {
  //         continue;
  //       }
  //       // 时间参数变化
  //       if (dateKey.indexOf(itemKey) !== -1) {
  //         const elementDate = moment(element[itemKey]).format('YYYY MM DD');
  //         const defaultDate = moment(defaultData[itemKey]).format('YYYY MM DD');
  //         if (elementDate !== defaultDate) {
  //           const datefinder = alreadyEditTasks.findIndex((task) => {
  //             return task.sqId === element.sqId;
  //           });
  //           if (datefinder === -1) {
  //             alreadyEditTasks.push(element);
  //           }
  //         }
  //         continue;
  //       }
  //       // 数组类型参数变化
  //       if (arrayKey.indexOf(itemKey) !== -1) {
  //         const elementArray = element[itemKey].toString();
  //         const defaultArray = defaultData[itemKey].toString();
  //         if (elementArray !== defaultArray) {
  //           const arrayfinder = alreadyEditTasks.findIndex((task) => {
  //             return task.sqId === element.sqId;
  //           });
  //           if (arrayfinder === -1) {
  //             alreadyEditTasks.push(element);
  //           }
  //         }
  //         continue;
  //       }

  //       // 普通参数变化
  //       if (element[itemKey] !== defaultData[itemKey]) {
  //         const normalfinder = alreadyEditTasks.findIndex((task) => {
  //           return task.sqId === element.sqId;
  //         });
  //         if (normalfinder === -1) {
  //           alreadyEditTasks.push(element);
  //         }
  //       }

  //     }
  //   }

  //   // 查询id是否连续
  //   const finder = allTasks.find((task, index) => {
  //     return task.id !== index + 1;
  //   });

  //   if (finder) {
  //     // 有错乱
  //     console.warn(finder);
  //     this.message.error('orderId重复');
  //   } else {
  //     const tasks = alreadyAddTasks.concat(alreadyEditTasks);
  //     // 整理
  //     const paramJson = [];
  //     alreadyAddTasks.forEach((task) => {
  //       task.sqId = getGuid();
  //       paramJson.push({
  //         op: 'create',
  //         type: 'task',
  //         data: task.toMpp()
  //       });
  //     });
  //     alreadyEditTasks.forEach((task) => {
  //       paramJson.push({
  //         op: 'update',
  //         type: 'task',
  //         data: task.toMpp()
  //       });
  //     });
  //     alreadyDeleteTasks.forEach((sqid) => {
  //       paramJson.push({
  //         op: 'delete',
  //         type: 'task',
  //         data: { Id: sqid }
  //       });
  //     });
  //     console.log(paramJson);
  //     this.dealwithPredecessorLink(xmpp, tasks, paramJson);
  //     const res = await this.ganttRequestSev.putTasks(xmpp.mpp.mppInfo.id, paramJson);
  //     if (res) {
  //       this.message.success('提交成功');
  //     } else {
  //       this.message.success('提交成功');
  //     }
  //     this.loading = false;
  //   }
  // }

  dealwithPredecessorLink(xmpp: Xmpp, tasks: XmppTask[], paramJson: any[]) {
    for (const element of tasks) {
      const relation = element.prevRelation;
      relation.forEach((prev) => {
        // 处理PredecessorLink
        if (prev.id && !prev.isDelete) {
          paramJson.push({
            op: 'update',
            type: 'link',
            data: {
              PredecessorUID: xmpp.allTasks[prev.prevId - 1].uid,
              ParentId: element.sqId,
              Type: prev.relation,
              LinkLag: prev.delay * 8 * 600,
              Id: prev.id
            }
          });
        } else if (prev.id && prev.isDelete) {
          paramJson.push({
            op: 'delete',
            type: 'link',
            data: {
              Id: prev.id
            }
          });
        } else if (!prev.id && !prev.isDelete) {
          paramJson.push({
            op: 'create',
            type: 'link',
            data: {
              PredecessorUID: xmpp.allTasks[prev.prevId - 1].uid,
              ParentId: element.sqId,
              Type: prev.relation,
              LinkLag: prev.delay ? prev.delay * 8 * 600 : 0
            }
          });
        }
      });
    }
  }



  public showRelation(task) {
    this.currentTask = task;
    const showRelation = [];
    if (task.prevRelation.length > 0) {
      task.prevRelation.forEach((item) => {
        const relation = this.translateNumber(item.relation);
        const delay = item.delay ? `+${item.delay}` : '';
        if (item.prevId && !item.isDelete) {
          const string = `${item.prevId}${relation}${delay}`;
          showRelation.push(string);
        }
      });
    }
    if (showRelation.length === 0) {
      return '请选择';
    }
    return showRelation.join(',');
  }

  public translateNumber(relation) {
    if (relation === PREVTYPE.FS) {
      return 'FS';
    }
    if (relation === PREVTYPE.SS) {
      return 'SS';
    }
    if (relation === PREVTYPE.FF) {
      return 'FF';
    }
    if (relation === PREVTYPE.SF) {
      return 'SF';
    }
  }

  // public showSettings(task: GanttModel) {
  //   const relations = [];
  //   task.prevRelation.forEach((ele) => {
  //     relations.push(ele);
  //   });
  //   if (relations.length === 0) {
  //     relations.push(new PredecessorLinkModel({
  //       relation: 1,
  //       delay: 0
  //     }));
  //   }

  //   const showDuration = task.showDuration;
  //   this.editInfo = new EditModel({
  //     relations,
  //     taskName: task.taskName,
  //     showDuration
  //   });
  //   this.settingVisible = true;
  // }

  // public settingSave(xmpp: Xmpp) {
  //   const relations = this.editInfo.relations;
  //   const prevRelation = [];
  //   const currentTask = this.currentTask;
  //   relations.forEach((element) => {
  //     if (element.prevId && !isNullOrUndefined(element.relation)) {
  //       prevRelation.push(new PredecessorLinkModel({
  //         id: element.id,
  //         prevId: parseInt(element.prevId),
  //         relation: element.relation,
  //         delay: element.delay,
  //         isDelete: element.isDelete
  //       }));
  //     }
  //   });
  //   const checkResult = this.checkRelations(xmpp, prevRelation);
  //   if (checkResult) {
  //     // this.createNotification('error', '请检查', checkResult)
  //     alert(checkResult);
  //   } else {
  //     currentTask.prevRelation = prevRelation;
  //     currentTask.taskName = this.editInfo.taskName;
  //     // currentTask.showDuration = this.editInfo.showDuration;
  //     this.getShowDuration(xmpp, currentTask, this.editInfo.showDuration);
  //     xmpp.render();
  //     this.settingVisible = false;
  //   }
  // }

  // public checkRelations(xmpp: Xmpp, relations: any[]) {
  //   // let relations = this.relations;
  //   const currentTask = this.currentTask;
  //   let checkRepeat: string;
  //   let checkSameId: string;
  //   let checkLoop: string;
  //   let checkPrevId: string;
  //   const allTasks = xmpp.allTasks;
  //   const taskLength = allTasks.length;
  //   const usefulRelation = [];
  //   relations.forEach((rela) => {
  //     if (!rela.isDelete) {
  //       usefulRelation.push(rela);
  //     }
  //   });
  //   // 检查4: 非法字符
  //   usefulRelation.forEach((element) => {
  //     const id = parseInt(element.prevId);
  //     if (isNaN(id)) {
  //       checkPrevId = `任务标识必须为数字`;
  //       return false;
  //     } else {
  //       if (id < 1 || id > taskLength) {
  //         checkPrevId = `任务标识不存在, error:'${id}'`;
  //         return false;
  //       }
  //     }
  //   });

  //   // 检查1： 前置任务id重复
  //   usefulRelation.forEach((i) => {
  //     const id = i.prevId;
  //     const idArray = [];
  //     usefulRelation.forEach((j) => {
  //       if (j.prevId === id) {
  //         idArray.push(j);
  //       }
  //     });
  //     if (idArray.length > 1) {
  //       checkRepeat = `任务'${idArray[0]}'两次链接到同一个后续任务`;
  //       return;
  //     }
  //   });

  //   // 检查2：prevId与任务Id相同
  //   usefulRelation.forEach((element) => {
  //     const id = element.prevId;
  //     if (id === currentTask.id) {
  //       checkSameId = `前置任务不能为自己, error:${id}`;
  //       return;
  //     }
  //   });


  //   // 检查3: 是否产生循环
  //   usefulRelation.forEach((element) => {
  //     const id = element.prevId;
  //     const prevTask = allTasks[id - 1];
  //     let check;
  //     if (prevTask && prevTask.prevRelation.length > 0) {
  //       check = prevTask.prevRelation.findIndex((relation) => {
  //         return relation.prevId === currentTask.id;
  //       });
  //       if (check !== -1) {
  //         checkLoop = `任务'${id}'产生循环`;
  //         return;
  //       }
  //     }
  //   });

  //   if (checkPrevId) {
  //     return checkPrevId;
  //   } else if (checkRepeat) {
  //     return checkRepeat;
  //   } else if (checkSameId) {
  //     return checkSameId;
  //   } else if (checkLoop) {
  //     return checkLoop;
  //   } else {
  //     return false;
  //   }
  // }

  // public settingCancel() {
  //   this.settingVisible = false;
  // }

  // public getShowDuration(xmpp: Xmpp, task, value) {
  //   const wantedShow = value;
  //   const exceptDate = xmpp.calendar.exceptDate;
  //   const startDate = task.startDate;
  //   let endDate;
  //   if (startDate) {
  //     // 先判断有没有受例外日期的影响
  //     const startUnix1 = moment(startDate).unix();
  //     const endUnix1 = moment(startDate).add(wantedShow - 1, 'days').unix();
  //     // 先根据例外日期，改变任务的开始时间和结束时间
  //     exceptDate.forEach((item) => {
  //       // 任务结束时间在例外日期之间
  //       if (endUnix1 <= item.endDate && endUnix1 >= item.startDate) {
  //         const correctDate = moment.unix(item.endDate).clone().add(1, 'days');
  //         endDate = correctDate;
  //       }
  //     });

  //     // 再统计任务中所有的例外日期总天数
  //     const startUnix2 = moment(startDate).unix();
  //     let endUnix2;
  //     if (endDate) {
  //       endUnix2 = moment(endDate).unix();
  //     } else {
  //       endDate = moment(startDate).add(wantedShow - 1, 'days');
  //       endUnix2 = endUnix1;
  //     }
  //     let allExcept = 0;
  //     exceptDate.forEach((item) => {
  //       // 例外日期在任务的开始时间和结束时间之间
  //       if (startUnix2 <= item.startDate && endUnix2 >= item.endDate) {
  //         const exceptDuration = moment.unix(item.endDate).clone().diff(moment.unix(item.startDate), 'days') + 1;
  //         allExcept = allExcept + exceptDuration;
  //       }
  //     });

  //     const duration = moment(endDate).clone().diff(moment(startDate), 'days') + 1;
  //     const showCount = duration - allExcept;

  //     if (showCount !== wantedShow) {
  //       const changes = wantedShow - showCount;
  //       task.duration = duration + changes;
  //     } else {
  //       task.duration = duration;
  //     }
  //   } else {
  //     task.duration = value;
  //     task.showDuration = value;
  //   }
  // }

  // public deleteRelation(index: number) {
  //   // this.editInfo.relations.splice(index, 1);
  //   this.editInfo.relations[index].isDelete = 1;
  // }

  // public addRelation() {
  //   this.editInfo.relations.push(new PredecessorLinkModel({
  //     relation: 1,
  //     delay: 0
  //   }));
  // }



}
