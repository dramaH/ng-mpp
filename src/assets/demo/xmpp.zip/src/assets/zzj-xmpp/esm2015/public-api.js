/**
 * @fileoverview added by tsickle
 * Generated from: public-api.ts
 * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
/*
 * Public API Surface of zzj-mpp
 */
export { GanttChartModule } from './lib/gantt-chart.module';
export { GanttComponent } from './lib/gantt-chart.component';
export { XmppWeekDayType, UInfoModel, XmppTask, XmppPredecessorLink, PREVTYPE, EXTENDATTRS, GanttMethod, Xmpp } from './lib/src/api-public';
export { GanttSize, GanttProjectModel } from './lib/gantt-chart-service/gantt.config';
export { PROJECTID, GanttRequestService } from './lib/gantt-chart-service/gantt-request.service';
export { Project } from './lib/src/lib/gantt.main';
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicHVibGljLWFwaS5qcyIsInNvdXJjZVJvb3QiOiJuZzovL0B6emovenpqLXhtcHAvIiwic291cmNlcyI6WyJwdWJsaWMtYXBpLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7O0FBSUEsaUNBQWMsMEJBQTBCLENBQUM7QUFDekMsK0JBQWMsNkJBQTZCLENBQUM7QUFDNUMscUhBQWMsc0JBQXNCLENBQUM7QUFDckMsNkNBQWMsd0NBQXdDLENBQUM7QUFDdkQsK0NBQWMsaURBQWlELENBQUM7QUFDaEUsd0JBQWMsMEJBQTBCLENBQUMiLCJzb3VyY2VzQ29udGVudCI6WyIvKlxuICogUHVibGljIEFQSSBTdXJmYWNlIG9mIHp6ai1tcHBcbiAqL1xuXG5leHBvcnQgKiBmcm9tICcuL2xpYi9nYW50dC1jaGFydC5tb2R1bGUnO1xuZXhwb3J0ICogZnJvbSAnLi9saWIvZ2FudHQtY2hhcnQuY29tcG9uZW50JztcbmV4cG9ydCAqIGZyb20gJy4vbGliL3NyYy9hcGktcHVibGljJztcbmV4cG9ydCAqIGZyb20gJy4vbGliL2dhbnR0LWNoYXJ0LXNlcnZpY2UvZ2FudHQuY29uZmlnJztcbmV4cG9ydCAqIGZyb20gJy4vbGliL2dhbnR0LWNoYXJ0LXNlcnZpY2UvZ2FudHQtcmVxdWVzdC5zZXJ2aWNlJztcbmV4cG9ydCAqIGZyb20gJy4vbGliL3NyYy9saWIvZ2FudHQubWFpbic7XG4vLyBleHBvcnQgKiBmcm9tICcuL2xpYi9nYW50dC5tYWluJztcbiJdfQ==