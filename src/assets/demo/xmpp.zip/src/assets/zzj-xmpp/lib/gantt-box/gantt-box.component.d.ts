import { OnInit, ElementRef } from '@angular/core';
import { Xmpp } from '../src/api-public';
export declare class GanttBoxComponent implements OnInit {
    canvasRef: ElementRef;
    maskCanvas: ElementRef;
    canvasInfo: any;
    Xmpp: Xmpp;
    weeksArry: any;
    weeksWidth: any;
    calendarWidth: number;
    canvasWidth: number;
    loadingShow: boolean;
    constructor();
    ngOnInit(): void;
    doMouseMove(event: any): void;
    changeWidth(): void;
    boxScroll(e: any): void;
    cleanCanvas: () => void;
    drawCanvas(): void;
}
