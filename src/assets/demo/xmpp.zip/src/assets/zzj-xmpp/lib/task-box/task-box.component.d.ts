import { OnInit, ElementRef, EventEmitter } from '@angular/core';
import { NzNotificationService, NzMessageService } from 'ng-zorro-antd';
import moment from 'moment';
import { Xmpp, XmppColumn, XmppPredecessorLink, XmppTask } from '../src/api-public';
import { GanttHelperService } from '../gantt-chart-service/gantt-helper.service';
declare class EditModel {
    relations: XmppPredecessorLink[];
    taskName: string;
    showDuration: number;
    constructor(param: any);
}
export declare class TaskBoxComponent implements OnInit {
    private _notification;
    private ganttHelpServ;
    private message;
    newTaskNameInput: ElementRef;
    editInput: ElementRef;
    Xmpp: Xmpp;
    newTaskBlur: EventEmitter<void>;
    isVisible: boolean;
    currentDate: moment.Moment;
    taskNameWidth: number;
    prevTaskWidth: number;
    headerWidth: number;
    otherWidthTotal: number;
    actualDisabled: boolean;
    isAllselected: boolean;
    editPermission: boolean;
    columnList: any[];
    newTask: any;
    ctrlDown: boolean;
    editTaskId: number;
    settingModalView: boolean;
    editInfo: EditModel;
    PREVTYPE: {
        FF: number;
        FS: number;
        SF: number;
        SS: number;
    };
    settingTask: XmppTask;
    clickTimer: any;
    constructor(_notification: NzNotificationService, ganttHelpServ: GanttHelperService, message: NzMessageService);
    ngOnInit(): void;
    editStuteChange(c: XmppColumn, task: XmppTask, open: boolean): void;
    resizeCallback($event: any, column: any): void;
    addTaskFromNewLine(type: string, $event: any): void;
    isBeforeCurrent(endDate: any): boolean;
    dateClickTask(task: any): void;
    private updateServiceData;
    createNotification: (type: any, title: any, message: any) => void;
    foldTaskLevel(task: any): void;
    openTaskLevel(task: any): void;
    selectAllTask(): void;
    selectAll(): void;
    clickTaskRow(task?: XmppTask): void;
    /**
     * 双击显示设置弹窗
     * @param task
     */
    showSettings(task: XmppTask): void;
    /**
     * 设置弹窗提交事件
     * @param xmpp
     */
    settingSave(): void;
    getShowDuration(value: any): void;
    checkRelations(relations: any[]): string | false;
    addRelation(): void;
    deleteRelation(index: number): void;
    submitFinishBinds(): void;
    getActualDate(date: any): string | false;
}
export {};
