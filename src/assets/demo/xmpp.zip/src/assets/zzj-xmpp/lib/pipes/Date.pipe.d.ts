import { PipeTransform } from '@angular/core';
export declare class DatePipe implements PipeTransform {
    transform(value: any, ...args: any[]): any;
}
