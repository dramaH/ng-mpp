import { ComponentFactoryResolver } from '@angular/core';
export declare class GanttChartModule {
    private resolver;
    constructor(resolver: ComponentFactoryResolver);
}
