export declare const GanttSize: {
    bottomHeight: number;
    taskHeight: number;
    calenderBaseWidth: number;
};
export declare class GanttProjectModel {
    id: string;
    parentId: string;
    calendars: any;
    creationDate: string;
    title: string;
    company: string;
    author: string;
    startDate: any;
    finishDate: any;
    dateFormat: any;
    constructor(param: any);
    toCreateJson(): {
        Title: string;
        Company: string;
        Author: string;
        StartDate: string;
        FinishDate: string;
    };
}
