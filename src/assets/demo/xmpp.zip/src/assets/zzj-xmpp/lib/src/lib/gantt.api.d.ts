import { Subject } from 'rxjs';
import { XmppColumn, IMPPProject, XmppTask, IMppTask, IMppExtendAttr, XmppWeekDay, XmppExceptDate } from './gantt-interface';
export declare class Xmpp {
    allTasks: Array<XmppTask>;
    globalLoading: boolean;
    mpp: {
        mppInfo: IMPPProject;
        mppTasks: IMppTask[];
        mppExtendAttrs: IMppExtendAttr[];
        extraAttrMap: Map<string, any>;
        /**
         * 处理后台的文件格式
         * @param mppTasks ITask[]
         */
        dealWithMPP(mppProject: IMPPProject, mppTasks: IMppTask[]): void;
        /**
         * 设置MppInfo
         * @param mppProject
         */
        setMppInfo(mppProject: IMPPProject): void;
        setMppTasks(mppTasks: IMppTask[]): void;
        /**
         * 将parentId关系结构处理成wbs层级
         */
        ParentId2WBS(): void;
    };
    task: {
        isAllSelect: boolean;
        /** 高亮的任务 */
        activeTaskId: number;
        /** 勾选的所有任务 */
        selectedTasks: XmppTask[];
        /** 任务列表可视任务数量 */
        showTaskLength: number;
        /** canvas绘制参数监听事件 */
        canvasInfoListener: Subject<XmppTask[]>;
        /** 降级折叠后，隐层的任务ids */
        hideTasksIds: [];
        /** 默认的任务列表高度 */
        taskHeight: 36;
        /** 任务列表可视区域开始index */
        startTaskIndex: number;
        /** 任务列表可视区域的任务组 */
        showTask: XmppTask[];
        maxUID: number;
        deleteTasksSqlIdStore: string[];
        /** 操作后，更新任务关联关系 */
        updateTaskHandle(): void;
        /** 获取折叠之后的可视任务 */
        getAllTaskAfterFold(): XmppTask[];
        /** 升降机操作后，更新任务的层级 */
        updateLeveInfo(): void;
        /** 更新任务时间 */
        updateStartDate(): void;
        /** 更新父任务时间 */
        updateParentStartDate(): void;
        /** 前端添加任务 */
        addTaskHandle(taskParam?: any): void;
        /** 前端删除任务 */
        deleteTaskHandle(taskIds: number[]): void;
        /** 降级任务 */
        depressTaskLevel(tasks: XmppTask[]): void;
        /** 升级任务 */
        promoteTaskLevel(tasks: XmppTask[]): void;
        /** 获取例外日期和时间周后算出来的时间 */
        getStartDateWithExcept(startDate: any, duration: number, endDate: any): any;
        /** 获取例外日期和时间周后算出来的时间 */
        nextDatePipe(startDate: any): any;
        lastDatePipe(endDate: any): any;
        /** 获取例外日期和时间周后算出来的时间 */
        getEndDateWithExcept(startDate: any, duration: number, endDate: any): any;
        /** 更新所有任务id */
        loopAllTasksId(): void;
    };
    draw: {
        selectedTaskId: number;
        showTooltip: true;
        canvasInfo: any[];
        exceptCanvasInfo: any[];
        canvasHeight: number;
        actualCanvasInfo: any[];
        mouseoverListener: Subject<{
            event: MouseEvent;
            task: XmppTask;
            position: {
                x: number;
                y: number;
            };
        }>;
        mouseupListener: Subject<{
            event: MouseEvent;
            task: XmppTask;
            position: {
                x: number;
                y: number;
            };
        }>;
        mousedownListener: Subject<{
            event: MouseEvent;
            task: XmppTask;
            position: {
                x: number;
                y: number;
            };
        }>;
        contextmenuListener: Subject<{
            event: MouseEvent;
            task: XmppTask;
            position: {
                x: number;
                y: number;
            };
        }>;
        color: {
            /** 计划时间颜色 */
            planColor: string;
            /** 任务为关键线路时，计划时间颜色 */
            planKeyColor: string;
            /** 实际时间颜色 */
            Actualcolor: string;
            /** 任务为关键线路时，实际时间颜色 */
            ActualkeyColor: string;
            /** 箭头及连线颜色 */
            arrowColor: string;
            /** 任务为关键线路时，箭头及连线颜色 */
            arrowKeyColor: string;
            /** 例外日期区域的颜色 */
            exceptDateColor: string;
        };
        lineHeight: number;
        actualLineHeight: number;
        canvasWidth: number;
        canvasLeftHide: number;
        setCanvasWidth: (width: number) => void;
        updateCanvasInfo: () => void;
        drawExceptArea: (ctx: CanvasRenderingContext2D) => void;
        drawTasks: (ctx: CanvasRenderingContext2D, isActual?: boolean) => void;
        drawSelectTask: (taskId: number) => void;
        canvasMouseEventListen: () => void;
        drawTooltip: (ele: any, task: XmppTask) => void;
    };
    column: {
        columnNames: any[];
        totalWidth: number;
        setColumn: (param: XmppColumn[]) => void;
    };
    calendar: {
        /** 默认日历id */
        calendarId: string;
        /** 日历周数组 */
        weeksArry: any[];
        /** 日历总宽度 */
        calenderWidth: number;
        /** 单元格日历（天）的宽度 */
        baseCellWidth: number;
        /** 例外日期 */
        exceptDate: XmppExceptDate[];
        /** 处理例外日期 */
        dealWithExceptDate: () => void;
        /** 工作周 */
        weekDays: XmppWeekDay[];
        pauseWeekDays: string[];
        /** 工作周休息日期枚举数组：[1, 7]即休息周六周日 */
        pauseWeekDayTypes: number[];
    };
    render: () => void;
    addGanttEventListener: (type: 'caculateListener' | 'mouseoverListener' | 'mouseupListener' | 'mousedownListener' | 'contextmenuListener', cb?: (res: {
        event: MouseEvent;
        task: XmppTask;
        position: any;
    }) => void) => void;
    constructor();
}
