import { Subject } from 'rxjs';
export interface XmppOptions {
    mppInfo: IMPPProject;
    mppTasks: IMppTask[];
    mppExtendAttrs: IMppExtendAttr[];
    columns: XmppColumn[];
    color: {
        /** 计划时间颜色 */
        planColor: string;
        /** 任务为关键线路时，计划时间颜色 */
        planKeyColor: string;
        /** 任务为延期任务时，计划时间颜色 */
        planDelayColor?: string;
        /** 实际时间颜色 */
        Actualcolor: string;
        /** 任务为关键线路时，实际时间颜色 */
        ActualkeyColor: string;
        /** 任务为延期任务时，实际时间颜色 */
        ActualDelayColor?: string;
        /** 箭头及连线颜色 */
        arrowColor: string;
        /** 任务为关键线路时，箭头及连线颜色 */
        arrowKeyColor: string;
        /** 例外日期区域的颜色 */
        exceptDateColor: string;
    };
    size: {
        taskHeight?: number;
        drawTaskHeight?: number;
        drawActualLineHeight?: number;
    };
}
export declare enum XmppWeekDayType {
    '日' = 1,
    '一' = 2,
    '二' = 3,
    '三' = 4,
    '四' = 5,
    '五' = 6,
    '六' = 7
}
export declare class UInfoModel {
    uuid: string;
    isFinished: number;
    finishAt: any;
    constructor(param: any);
}
export interface XmppColumn {
    key: 'tags' | 'taskName' | 'startDate' | 'duration' | 'endDate' | 'actualStartDate' | 'actualDuration' | 'actualEndDate' | string;
    name: string;
    width: number;
    type?: 'tags' | 'text' | 'taskName' | 'date' | 'checkbox';
    resize?: boolean;
    isEdit?: boolean;
}
export interface IXmpp {
    allTasks: Array<XmppTask>;
    globalLoading: boolean;
    mpp: {
        mppInfo: IMPPProject;
        mppTasks: IMppTask[];
        mppExtendAttrs: IMppExtendAttr[];
        extraAttrMap: Map<string, any>;
    };
    task: {
        activeTaskId: number;
        showTaskLength: number;
        canvasInfoListener: Subject<XmppTask[]>;
        hideTasksIds: any[];
        taskHeight: number;
        startTaskIndex: number;
        showTask: Array<XmppTask>;
        maxUID: any;
        deleteTasksSqlIdStore: string[];
        updateTaskHandle(param: IXmpp): void;
    };
    calendar: {
        calendarId: string;
        weeksArry: any[];
        calenderWidth: number;
        baseCellWidth: number;
        weekDays: XmppWeekDay[];
        exceptDate: XmppExceptDate[];
        pauseWeekDayTypes: number[];
        pauseWeekDays: string[];
    };
    draw: {
        selectedTaskId: number;
        canvasInfo: any[];
        exceptCanvasInfo: any[];
        canvasHeight: number;
        actualCanvasInfo: any[];
        canvasWidth: number;
        color: {
            /** 计划时间颜色 */
            planColor: string;
            /** 任务为关键线路时，计划时间颜色 */
            planKeyColor: string;
            /** 实际时间颜色 */
            Actualcolor: string;
            /** 任务为关键线路时，实际时间颜色 */
            ActualkeyColor: string;
            /** 箭头及连线颜色 */
            arrowColor: string;
            /** 任务为关键线路时，箭头及连线颜色 */
            arrowKeyColor: string;
            /** 例外日期区域的颜色 */
            exceptDateColor: string;
        };
        lineHeight: number;
        actualLineHeight: number;
        canvasLeftHide: number;
    };
    column: {
        columnNames: any[];
        totalWidth: number;
        setColumn(param: XmppColumn[]): void;
    };
    render(): void;
    addGanttEventListener(type: string, cb?: (res: any) => void): void;
}
export interface IMPPProject {
    actualsInSync: boolean;
    adminProject: boolean;
    assignments: any[];
    assignmentsUUIDs: string;
    author: string;
    autoAddNewResourcesAndTasks: boolean;
    autolink: boolean;
    baselineForEarnedValue: number;
    calendarUID: number;
    calendars: IMppCalendar[];
    calendarsUUIDs: string;
    category: string;
    company: string;
    creationDate: string;
    criticalSlackLimit: number;
    currencyCode: string;
    currencyDigits: number;
    currencySymbol: string;
    currencySymbolPosition: number;
    currentDate: string;
    daysPerMonth: number;
    defaultFinishTime: string;
    defaultFixedCostAccrual: number;
    defaultOvertimeRate: number;
    defaultStandardRate: number;
    defaultStartTime: string;
    defaultTaskEVMethod: number;
    defaultTaskType: number;
    durationFormat: number;
    earnedValueMethod: number;
    editableActualCosts: boolean;
    enabled: boolean;
    extendedAttributes: any[];
    extendedAttributesUUIDs: string;
    extendedCreationDate: string;
    finishDate: string;
    fiscalYearStart: boolean;
    fyStartDate: number;
    honorConstraints: boolean;
    id: string;
    insertedProjectsLikeSummary: boolean;
    lastSaved: string;
    manager: string;
    microsoftProjectServerURL: boolean;
    minutesPerDay: number;
    minutesPerWeek: number;
    moveCompletedEndsBack: boolean;
    moveCompletedEndsForward: boolean;
    moveRemainingStartsBack: boolean;
    moveRemainingStartsForward: boolean;
    multipleCriticalPaths: boolean;
    name: string;
    newTaskStartDate: number;
    newTasksEffortDriven: boolean;
    newTasksEstimated: boolean;
    parentId: string;
    projectExternallyEdited: boolean;
    removeFileProperties: boolean;
    resources: any[];
    resourcesUUIDs: string;
    revision: number;
    saveVersion: number;
    scheduleFromStart: boolean;
    splitsInProgressTasks: boolean;
    spreadActualCost: boolean;
    spreadPercentComplete: boolean;
    startDate: string;
    statusDate: string;
    subject: string;
    taskUpdatesResource: boolean;
    tasks: IMppTask[];
    tasksUUIDs: string;
    title: string;
    uid: string;
    weekStartDay: number;
    workFormat: number;
    [key: string]: any;
}
export interface IMppCalendar {
    uid: number;
    name: string;
    isBaseCalendar: boolean;
    baseCalendarUID: number;
    weekDays: IMppWeekDay[];
    weekDaysUUIDs: string;
    exceptions: IMppCalendarException[];
    exceptionsUUIDs: string;
    enabled: boolean;
    parentId: string;
    id: string;
}
export interface IMppWeekDay {
    dayType: number;
    dayWorking: boolean;
    fromDate: string;
    toDate: string;
    fromTime_0: string;
    toTime_0: string;
    fromTime_1: string;
    toTime_1: string;
    fromTime_2: string;
    toTime_2: string;
    fromTime_3: string;
    toTime_3: string;
    fromTime_4: string;
    toTime_4: string;
    enabled: boolean;
    parentId: string;
    id: string;
}
export interface IMppCalendarException {
    enteredByOccurrences: boolean;
    fromDate: string;
    toDate: string;
    occurrences: number;
    name: string;
    type: number;
    period: number;
    dasyOfWeek: number;
    monthIten: number;
    monthPosition: number;
    month: number;
    monthDay: number;
    dayWorking: boolean;
    parentId: string;
    id: string;
}
export interface IMppTask {
    active: number;
    actualCost: number;
    actualDuration: any;
    actualFinish: any;
    actualOvertimeCost: number;
    actualOvertimeWork: any;
    actualOvertimeWorkProtected: any;
    actualStart: any;
    actualWork: any;
    actualWorkProtected: any;
    acwp: number;
    baseline: any[];
    baselineUUIDs: any;
    bcwp: number;
    bcws: number;
    calendarUID: number;
    commitmentFinish: any;
    commitmentStart: any;
    commitmentType: number;
    constraintDate: any;
    constraintType: number;
    contact: any;
    cost: number;
    createDate: string;
    critical: boolean;
    cv: number;
    deadline: any;
    duration: string;
    durationFormat: number;
    earlyFinish: any;
    earlyStart: any;
    earnedValueMethod: number;
    effortDriven: boolean;
    enabled: boolean;
    estimated: boolean;
    extendedAttribute: any[];
    extendedAttributeUUIDs: any;
    externalTask: boolean;
    externalTaskProject: any;
    finish: string;
    finishVariance: number;
    fixedCost: number;
    fixedCostAccrual: any;
    freeSlack: number;
    hideBar: boolean;
    hyperlink: any;
    hyperlinkAddress: any;
    hyperlinkSubAddress: any;
    id: string;
    ignoreResourceCalendar: boolean;
    isNull: boolean;
    isPublished: boolean;
    isSubproject: boolean;
    isSubprojectReadOnly: boolean;
    lateFinish: any;
    lateStart: any;
    levelAssignments: boolean;
    levelingCanSplit: boolean;
    levelingDelay: number;
    levelingDelayFormat: number;
    manual: number;
    milestone: boolean;
    name: string;
    notes: any;
    outlineLevel: number;
    outlineNumber: any;
    overAllocated: boolean;
    overtimeCost: number;
    overtimeWork: any;
    parentId: string;
    percentComplete: number;
    percentWorkComplete: number;
    physicalPercentComplete: number;
    preLeveledFinish: any;
    preLeveledStart: any;
    predecessorLink: any[];
    predecessorLinkUUIDs: any;
    priority: number;
    recurring: boolean;
    regularWork: any;
    remainingCost: number;
    remainingDuration: any;
    remainingOvertimeCost: number;
    remainingOvertimeWork: any;
    remainingWork: any;
    resume: any;
    resumeValid: boolean;
    rollup: boolean;
    starVariance: number;
    start: string;
    statusmanager: any;
    stop: any;
    subprojectName: any;
    summary: boolean;
    totalSlack: number;
    type: number;
    uid: number;
    wbs: string;
    wbsLevel: any;
    work: any;
    workVariance: number;
    _ID: number;
    customAttrs: string;
}
export interface IMppExtendAttr {
    alias: any;
    appendNewValues: boolean;
    autoRollDown: boolean;
    calculationType: number;
    cfType: number;
    default: any;
    defaultGuid: any;
    elemType: number;
    enabled: boolean;
    fieldID: string;
    fieldName: string;
    formula: any;
    id: string;
    ltuid: any;
    maxMultiValues: number;
    parentId: string;
    phoneticAlias: any;
    restrictValues: boolean;
    rollupType: number;
    secondaryPID: any;
    userDef: boolean;
    valuelistSortOrder: number;
    _Guid: any;
}
export interface XmppTaskExtendedAttribute {
    fieldID: string;
    value: string;
    valueGUID: string;
    durationFormat: number;
    enabled: boolean;
    parentId: string;
    id: string;
}
export interface XmppResource {
    uid: number;
    name: string;
    start: string;
    finish: string;
    work: string;
}
export interface XmppWeekDay {
    id: string;
    dayType: number;
    dayWorking: boolean;
    fromDate: string;
    toDate: string;
    dayText: string;
}
export interface XmppExceptDate {
    id?: string;
    name: string;
    fromDate: string;
    toDate: string;
    parentId?: string;
}
export declare class XmppTask {
    /**
     * 公用参数
     */
    extendedAttribute: XmppTaskExtendedAttribute[];
    customExtendAttr?: XmppTaskExtendedAttribute;
    id?: number;
    symbol?: number;
    sqId?: string;
    uid?: number;
    wbs?: string | any;
    taskName?: string;
    isSelected: boolean;
    step: number;
    childTaskID?: any[];
    parentTaskID?: number;
    level: number;
    isFold: boolean;
    ganttChartId?: string;
    defaultData: any;
    bindings: any[];
    allFinished: boolean;
    isMilepost: boolean;
    prevRelation?: XmppPredecessorLink[];
    private _exceptDuration;
    exceptDuration: number;
    private _exceptActualDuration;
    exceptActualDuration: number;
    private _finishRate;
    finishRate: number;
    /**
     * 计划参数
     */
    truePrevTaskID?: any;
    isKey: boolean;
    laterChildId?: number;
    earlierChildId?: number;
    private _startDate;
    startDate: any;
    private _duration;
    duration: any;
    private _endDate;
    endDate: any;
    private _showDuration?;
    showDuration: number;
    showActualDuration?: number;
    /**
     * 实际参数
     */
    actulaTruePrevTaskID?: any;
    isActualKey: boolean;
    acLaterChildId: any;
    acEarlierChildId: any;
    private _actualStartDate;
    actualStartDate: any;
    private _actualDuration?;
    actualDuration: any;
    private _actualEndDate?;
    actualEndDate: any;
    tags?: {
        key: string;
        name?: string;
        iconUrl?: string;
        iconType?: string;
    }[];
    CustomAttrs: string;
    Xmpp: any;
    resources: XmppResource[];
    [key: string]: any;
    firstSet: boolean;
    constructor(param: any);
    toJson(): {
        orderId: number;
        ganttChartId: string;
        taskName: string;
        startAt: number;
        finishAt: number;
        duration: any;
        actualStartAt: number;
        actualFinishAt: number;
        parentTaskId: number;
        preTask: string;
        childTaskID: any[];
        level: number;
        bindings: any[];
        milestone: number;
        finishRate: number;
        step: number;
    };
    toEditJson(): {
        id: string;
        orderId: number;
        ganttChartId: string;
        taskName: string;
        startAt: number;
        finishAt: number;
        duration: any;
        actualStartAt: number;
        actualFinishAt: number;
        parentTaskId: number;
        preTask: string;
        childTaskID: any[];
        level: number;
        bindings: any[];
        milestone: number;
        finishRate: number;
        step: number;
    };
    toMpp(): {
        Id: string;
        _ID: number;
        UID: number;
        ParentId: string;
        Name: string;
        Start: string;
        Finish: string;
        Duration: string;
        ActualStart: string;
        ActualFinish: string;
        WBS: any;
        Milestone: boolean;
        CustomAttrs: string;
    };
    getMomentStart(date: any): string;
    handleStartDate(startDate: any): any;
    handleEndDate(endDate: any): any;
    handleDuration(duration: any): any;
    handleActualStartDate(startDate: any): any;
    handleActualEndDate(endDate: any): any;
    handleActualDuration(duration: any): any;
}
export declare class XmppPredecessorLink {
    id?: string;
    prevId?: any;
    relation: number;
    delay: number;
    predecessorLink?: number;
    defaultPerv?: any;
    isDelete: number;
    parentId: string;
    constructor(param: any);
}
