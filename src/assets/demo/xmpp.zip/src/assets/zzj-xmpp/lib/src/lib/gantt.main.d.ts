import { ComponentFactoryResolver, ComponentRef, ViewContainerRef } from '@angular/core';
import { GanttComponent } from '../../gantt-chart.component';
export declare class Project {
    static resolver: ComponentFactoryResolver;
    static newProject(container: ViewContainerRef, options: any): Promise<ComponentRef<GanttComponent>>;
}
