import { IXmpp, IMPPProject, IMppTask, XmppTask, XmppPredecessorLink } from './gantt-interface';
export declare class GanttMethod {
    static mpp: {
        dealWithProject(Gantt: IXmpp, ganttInfo: IMPPProject): void;
        dealWithMPPTasks(Gantt: IXmpp, mppTasks: IMppTask[]): any[];
        PT2Duration(str: any): number;
        WBS2ParentId(task: IMppTask, allTasks: IMppTask[]): {
            parentId: number;
            childId: any[];
            level: number;
        };
        ParentId2WBS(Gantt: any): void;
    };
    static canvas: {
        updateCanvasInfo(Gantt: IXmpp): void;
        positionCalculate(Gantt: IXmpp, minLineDay: any, dateType?: "actual"): void;
        /**
         * 绘制额外日期区域
         * @param Gantt IXmpp
         * @param  ctx 画布
         */
        drawExceptArea(Gantt: IXmpp, ctx: CanvasRenderingContext2D): void;
        /**
         * 绘制任务举行
         * @param Gantt
         * @param ctx
         * @param isActual
         */
        drawTasks(Gantt: IXmpp, ctx: CanvasRenderingContext2D, isActual?: boolean): void;
        /**
         * 在mask canvas上绘制选中任务的线
         * @param Gantt
         * @param index 选中任务在canvasInfo中的index
         */
        drawSelectTask(Gantt: IXmpp, taskId: number): void;
        /**
         * 绘制圆角矩形
         * @param cxt 画布
         * @param x 位置x
         * @param y 位置y
         * @param width 宽度
         * @param height 高度
         * @param radius 圆角
         */
        drawRoundRect(cxt: any, x: any, y: any, width: any, height: any, radius: any): void;
        /**
         * 绘制文本
         * @param ctx 画布
         * @param text 文本内容
         * @param x 位置x
         * @param y 位置y
         * @param fontSize 字体大小
         */
        drawText(ctx: any, text: string, x: number, y: number, fontSize: any, fillStyle?: any): void;
        /**
         * 绘制里程碑
         * @param ctx 画布
         * @param conf 配置
         */
        drawPolygon(ctx: any, conf: any): void;
        /**
         * 绘制父任务的括号
         * @param ctx 画布
         * @param fromX 开始x
         * @param fromY 开始y
         * @param toX 结束x
         * @param toY 结束y
         */
        drawSenior(ctx: any, fromX: any, fromY: any, toX: any, toY: any): void;
        /**
         * @param ctx Canvas绘图环境
         * @param fromX fromY：起点坐标（也可以换成p1，只不过它是一个数组）
         * @param toX toY：终点坐标 (也可以换成p2，只不过它是一个数组)
         * @param theta 三角斜边一直线夹角
         * @param headlen：三角斜边长度
         * @param width 箭头线宽度
         */
        drawArrow(ctx: any, fromX: any, fromY: any, toX: any, toY: any, theta?: number, headlen?: number, width?: number): void;
        drawLineArrow(ctx: any, x1: any, y1: any, x2: any, y2: any): void;
        /**
         * 绘制折线
         * @param ctx 画布
         * @param points 折线上的点数组
         * @param width 宽度
         * @param color 颜色
         */
        drawBrokenLine(ctx: any, points: any[], width?: number, color?: string): void;
        /**
         * 绘制直线
         * @param ctx 画布
         * @param fromX 开始x
         * @param fromY 开始y
         * @param toX 结束x
         * @param toY 结束y
         * @param width 宽度
         * @param color 颜色
         */
        drawLine(ctx: CanvasRenderingContext2D, fromX: any, fromY: any, toX: any, toY: any, width: any, color: any): void;
    };
    static tasks: {
        cleanKeyLoop(tasks: XmppTask[]): void;
        cleanActualKeyLoop(tasks: XmppTask[]): void;
        findActualKeyLoop(tasks: XmppTask[], key: number): void;
        findKeyLoop(Gantt: IXmpp, tasks: XmppTask[], key: number): void;
        updateTaskHandle(Gantt: IXmpp): void;
        getAllTaskAfterFold(Gantt: IXmpp): any[];
        updateLeveInfo(allTasks: any): void;
        levelLoop(allTasks: any, task: any, nextIndex: any): void;
        removeParentID(allTasks: any, children: XmppTask, parentId: number): void;
        addTaskHandle(Gantt: IXmpp, taskParam: XmppTask): void;
        deleteTaskHandle(Gantt: IXmpp, deleteTaskIds: number[]): void;
        depressTaskLevel(Gantt: IXmpp, selectTasks: any[]): void;
        promoteTaskLevel(Gantt: IXmpp, selectTasks: any): void;
        checkSelectNumber(allTasks: any): any[];
        loopAllTasksId(Gantt: IXmpp): void;
    };
    static predecessorLink: {
        parentLoop(allTasks: any, ownPrevRelation: XmppPredecessorLink[], currentTask: XmppTask): void;
        filterDeleteRelation(relation: XmppPredecessorLink[]): XmppPredecessorLink[];
        loopParentMaxMin(allTasks: any, checkTask: any, task: any, laterChildId?: any, earlierChildId?: any): void;
        dealWithPrev(task: IMppTask, allTasks: IMppTask[]): any[];
    };
    static date: {
        dateDeepClone(date: any): Date;
        updateStartDate(Gantt: IXmpp): void;
        updateParentStartDate(allTasks: any): void;
        dealWithExceptDate(Gantt: IXmpp): void;
        datePipe(Gantt: IXmpp, date: any, addDay: number): any;
        handleStartDate(Gantt: IXmpp, startDate: any, duration: any, endDate: any): any;
        handleEndDate(Gantt: IXmpp, startDate: any, duration: any, endDate: any): any;
        getDifferAndPauseDays(Gantt: IXmpp, start: any, end: any): {
            differ: number;
            pauseDaysCount: number;
        };
        isExceptDay(Gantt: IXmpp, dayUnix: any): boolean;
        isPausedDay(Gantt: IXmpp, dayUnix: any): boolean;
    };
    static server: {};
}
