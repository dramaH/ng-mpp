import { NzMessageService } from 'ng-zorro-antd';
import { GanttRequestService } from './gantt-request.service';
import { Xmpp, XmppTask } from '../src/api-public';
export declare class GanttHelperService {
    private message;
    private ganttRequestSev;
    settingVisible: boolean;
    currentTask: XmppTask;
    loading: boolean;
    constructor(message: NzMessageService, ganttRequestSev: GanttRequestService);
    dealwithPredecessorLink(xmpp: Xmpp, tasks: XmppTask[], paramJson: any[]): void;
    showRelation(task: any): string;
    translateNumber(relation: any): "FS" | "SS" | "FF" | "SF";
}
