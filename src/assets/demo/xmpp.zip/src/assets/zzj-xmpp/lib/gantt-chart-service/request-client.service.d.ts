import { HttpClient, HttpHeaders } from '@angular/common/http';
export declare class RequestClientService {
    private http;
    constructor(http: HttpClient);
    get(url: string, params: any, header?: any): Promise<any>;
    post(url: string, params?: any, header?: any): Promise<any>;
    put(url: string, params: any, header?: any): Promise<any>;
    delete(url: string, params: any, header?: any): Promise<any>;
    checkResponeData(res: any): any;
    throwError(error: any): Promise<any>;
    creatHeader(header?: any): HttpHeaders;
    getAPDToken(): string;
    getSSO(url: string, params?: any, header?: any): Promise<any>;
    postSSO(url: string, params: any, header?: any): Promise<any>;
    putSSO(url: string, params: any, header?: any): Promise<any>;
    deleteSSO(url: string, params: any, header?: any): Promise<any>;
    creatSSOHeader(header?: any): HttpHeaders;
    getSSOToken(): string;
}
