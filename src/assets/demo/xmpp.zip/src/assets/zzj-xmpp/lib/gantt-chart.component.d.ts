import { ElementRef, AfterViewInit } from '@angular/core';
import { NzMessageService } from 'ng-zorro-antd';
import { GanttHelperService } from './gantt-chart-service/gantt-helper.service';
import { GanttBoxComponent } from './gantt-box/gantt-box.component';
import { GanttRequestService } from './gantt-chart-service/gantt-request.service';
import { Xmpp, XmppOptions, IMPPProject, XmppTask } from './src/api-public';
export declare class GanttComponent implements AfterViewInit {
    private elementRef;
    ganttHelperService: GanttHelperService;
    private message;
    PREVTYPE: any;
    private ganttRequestSev;
    ele: ElementRef;
    taskbox: ElementRef;
    ganttContainer: ElementRef;
    container: ElementRef;
    ganttPanel: GanttBoxComponent;
    Xmpp: Xmpp;
    leftPanel: any;
    rightPanel: any;
    ganttId: string;
    mppShowBottomPanel: boolean;
    isFold: boolean;
    lastScrollTop: 0;
    scrollListHeight: number;
    resizeBarWith: number;
    scrollBarWith: number;
    rowHeight: number;
    private searchTerms;
    schedulePnlStyleModel: any;
    readonly topPnlStyle: {
        height: string;
    };
    readonly leftPnlStyle: {
        width: string;
    };
    readonly rightPnlStyle: {
        width: string;
    };
    constructor(elementRef: ElementRef, ganttHelperService: GanttHelperService, message: NzMessageService, PREVTYPE: any, ganttRequestSev: GanttRequestService, ele: ElementRef);
    initProject(mppOptions: XmppOptions): Promise<XmppTask[]>;
    outerResizeCallback(e: any): void;
    updateTasks(): void;
    ngOnInit(): void;
    /**
     * 加载表格数据
     * @param ganttId
     */
    initTasks(mppOptions: XmppOptions): Promise<void>;
    /**
     * 下载xml文件
     */
    downloadXML(): Promise<void>;
    /**
     * 获取表格列表
     * @param gantt
     */
    getGanttTaskList(gantt: IMPPProject): Promise<void>;
    resizeCallback($event: any): void;
    readonly schedulePnlStyle: {
        width: string;
        height: string;
    };
    dragstartHandler(e: any, model?: string): void;
    ngAfterViewInit(): void;
    /**
     * 计算进度列表和canvas面板的高度
     * 触发方式：改变窗口大小、关闭底部panel
     */
    refreshViewHeight(): void;
    getScrollHeight(): number;
    windowResize(event: any): void;
    /**
     * 滚动条滚动事件
     * @param e any
     */
    scrollHandler(e: any): void;
    /**
     * 鼠标滚动事件
     * @param e
     * 控制假滚动条滚动
     */
    mousewheelhandler(e: any): void;
    newTaskBlur(e: any): void;
    /**
     * 新建项目
     */
    changeStartDate(group: {
        name: string;
        startDate: any;
        endDate: any;
    }): void;
    /**
     * 获取项目列表
     */
    changeEndDate(group: {
        name: string;
        startDate: any;
        endDate: any;
    }): void;
    deletDate(index: number, exceptDate: any): void;
    addDate(exceptDate: any): void;
    createMessage: (type: any, text: any) => void;
    rulesForNewProject: (newGanttModel: any) => boolean;
}
