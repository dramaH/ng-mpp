export declare class GanttPipeModule {
}
