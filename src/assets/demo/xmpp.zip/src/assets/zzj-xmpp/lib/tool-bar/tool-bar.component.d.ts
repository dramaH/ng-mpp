import { OnInit } from '@angular/core';
import { NzNotificationService, NzModalService, NzMessageService } from 'ng-zorro-antd';
import { Xmpp } from '../src/api-public';
import { GanttHelperService } from '../gantt-chart-service/gantt-helper.service';
import { GanttRequestService } from '../gantt-chart-service/gantt-request.service';
export declare class ToolBarComponent implements OnInit {
    private _notification;
    private confirmServ;
    private message;
    private ganttHelpServ;
    private ganttRequestSev;
    Xmpp: Xmpp;
    ganttChecked: boolean;
    selector: any;
    _percent: number;
    interval: any;
    simulate: boolean;
    playdisabled: boolean;
    pausedisabled: boolean;
    startDate: any;
    showStart: any;
    endDate: any;
    finishDate: any;
    diffDate: any;
    simulateVisible: boolean;
    calenderVisible: boolean;
    perStep: any;
    currentStep: number;
    uuids: any;
    playTasks: any;
    permission: any;
    constructor(_notification: NzNotificationService, confirmServ: NzModalService, message: NzMessageService, ganttHelpServ: GanttHelperService, ganttRequestSev: GanttRequestService);
    createNotification: (type: any, title: any, message: any) => void;
    ngOnInit(): void;
    transformDate(value: any): any;
    calenderShow(): void;
    calenderCancel(): void;
    changeStartDate(group: {
        name: string;
        startDate: any;
        endDate: any;
    }): void;
    changeEndDate(group: {
        name: string;
        startDate: any;
        endDate: any;
    }): void;
    saveTasks(type: string): void;
    ganttTracking(e: any): void;
    addTask(): void;
    deleteTask(): void;
    deleteTaskHandle(): void;
    depressTaskLevel(): void;
    promoteTaskLevel(): void;
    checkSelectNumber(): any[];
    addMilepost(): void;
    /**
     * 绑定构件
     * @param isFirstBind
     */
    /**
     * 解绑构件
     */
    simulateHide(): void;
    refresh(): void;
    compress(): void;
    expand(): void;
    reload(): void;
    increase(): void;
    decline(): void;
    pause(): void;
    remove(): void;
    startValueChange: () => void;
    endValueChange: () => void;
    disabledEndDate: (endValue: any) => boolean;
    showModal: () => void;
    simulateCancel: (e: any) => void;
    getAllplayTasks(): void;
}
