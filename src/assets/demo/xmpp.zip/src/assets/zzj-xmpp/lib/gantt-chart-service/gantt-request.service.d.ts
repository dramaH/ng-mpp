import { RequestClientService } from './request-client.service';
import { IMppTask, IMppExtendAttr, XmppTaskExtendedAttribute } from '../src/api-public';
export declare const PROJECTID = "bf894bfd-80ad-417d-bd31-a8af3200025c";
export declare class GanttRequestService {
    private requestClientService;
    constructor(requestClientService: RequestClientService);
    /**
     * 上传mpp文件，自定义项目title
     * @param uploadForm
     */
    uploadMMP(uploadForm: any): Promise<any>;
    uploadMppWithOutSave(uploadForm: any): Promise<any>;
    updateGantt(id: any, param: any): Promise<any>;
    /**
     * 获取项目列表
     */
    getGanttList(): Promise<any>;
    /**
     * 删除gantt
     * @param ganttId
     */
    deleteGantt(ganttId: any): Promise<void>;
    updateTask(projectId: string, taskId: string, param: any): Promise<any>;
    /**
     * 获取task列表
     * @param ganttId
     */
    getTasksList(ganttId: any): Promise<Array<IMppTask>>;
    /**
     * 获取进度信息
     * @param ganttId
     */
    getGanttInfo(ganttId: string): Promise<any>;
    /**
     * 更新tasks（总）
     * @param ganttId
     * @param param
     */
    putTasks(ganttId: string, param: any): Promise<boolean>;
    /**
     * 新建进度
     * @param param
     */
    postGantt(param: any): Promise<any>;
    /**
     * 创建binding资源并关联project
     * @param ganttId
     */
    postGanttBindingAttr(ganttId: string): Promise<any>;
    /**
     * 获取project所绑定的资源
     * @param ganttId
     */
    getGanttAttrs(ganttId: string): Promise<Array<IMppExtendAttr>>;
    /**
     * 获取task的拓展属性
     * @param ganttId
     * @param taskId
     */
    getTaskAttrs(ganttId: string, taskId: string): Promise<Array<any>>;
    /**
     * 新增task绑定extend
     * @param ganttId
     * @param taskId
     * @param param
     */
    bindTaskExtendedAttribute(ganttId: string, taskId: string, param: {
        FieldID: string;
        Value: string;
    }): Promise<XmppTaskExtendedAttribute>;
    updateExtendedAttrbute(ganttId: string, taskId: string, attrId: string, param: {
        FieldID: string;
        Value: string;
    }): Promise<XmppTaskExtendedAttribute>;
}
