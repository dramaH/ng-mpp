import { OnInit, EventEmitter } from '@angular/core';
export declare class ResizeBarComponent implements OnInit {
    lazyMove: boolean;
    mode: string;
    before: any;
    after: any;
    single: any;
    single_width: any;
    resizeCallback: EventEmitter<{
        x: number;
        y: number;
    }>;
    childResizeLeft: any;
    childOpacity: number;
    readonly resizeChildStyle: {
        left: string;
        opacity: number;
    };
    constructor();
    ngOnInit(): void;
    mousedown(event: any): void;
    /**
     * 懒拖拽
     * 先移动resize-bar，再改变两边的容器宽度
     * @param event any
     */
    lazyMoveMouseDown(event: any): void;
    resizing(moveX: any, moveY: any): void;
    /**
     * 改变两侧容器
     * @param moveX 宽度改变的值
     * @param moveY 高度改变的值
     */
    resizeBoth(moveX: any, moveY: any): void;
    /**
     * 只改变一侧容器
     * @param moveX 宽度改变的值
     * @param moveY 高度改变的值
     */
    resizeSingle(moveX: any, moveY: any): void;
}
