export declare const PREVTYPE: {
    FF: number;
    FS: number;
    SF: number;
    SS: number;
};
export declare const EXTENDATTRS: {
    binding: {
        FieldID: string;
        FieldName: string;
    };
    extraParam: {
        FieldID: string;
        FieldName: string;
    };
};
