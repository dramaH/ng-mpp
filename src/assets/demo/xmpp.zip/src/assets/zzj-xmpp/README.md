# @zzj/zzj-xmpp

## 安装 v0.2.0
- 增加了工作周设置及相关接口
- 增加了例外日期设置及相关接口

### npm (Recommended)

```bash
$ npm install @zzj/zzj-xmpp
```

