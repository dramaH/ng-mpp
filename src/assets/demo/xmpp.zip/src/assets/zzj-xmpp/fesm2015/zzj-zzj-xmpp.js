import { Injectable, ɵɵdefineInjectable, ɵɵinject, Component, ViewChild, Input, ElementRef, Inject, EventEmitter, Output, Pipe, NgModule, ComponentFactoryResolver } from '@angular/core';
import { CommonModule } from '@angular/common';
import { __awaiter } from 'tslib';
import { NzMessageService, NzNotificationService, NzModalService, NgZorroAntdModule } from 'ng-zorro-antd';
import moment from 'moment';
import { HttpHeaders, HttpClient } from '@angular/common/http';
import { isNullOrUndefined, isArray } from 'util';
import { Subject } from 'rxjs';
import { NzMessageService as NzMessageService$1 } from 'ng-zorro-antd/message';
import { debounceTime, distinctUntilChanged } from 'rxjs/operators';
import { FormsModule } from '@angular/forms';

/**
 * @fileoverview added by tsickle
 * Generated from: lib/gantt-chart-service/request-client.service.ts
 * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
class RequestClientService {
    /**
     * @param {?} http
     */
    constructor(http
    // private loginService: LoginService,
    // public jwtHelper: JwtHelperService
    ) {
        this.http = http;
    }
    /**
     * @param {?} url
     * @param {?} params
     * @param {?=} header
     * @return {?}
     */
    get(url, params, header) {
        /** @type {?} */
        const headers = this.creatHeader(header);
        return this.http.get(url, { headers, params })
            .toPromise().then(this.checkResponeData).catch(this.throwError);
    }
    /**
     * @param {?} url
     * @param {?=} params
     * @param {?=} header
     * @return {?}
     */
    post(url, params, header) {
        /** @type {?} */
        const headers = this.creatHeader(header);
        return this.http.post(url, params, { headers })
            .toPromise().then(this.checkResponeData).catch(this.throwError);
    }
    /**
     * @param {?} url
     * @param {?} params
     * @param {?=} header
     * @return {?}
     */
    put(url, params, header) {
        /** @type {?} */
        const headers = this.creatHeader(header);
        return this.http.put(url, params, { headers })
            .toPromise().then(this.checkResponeData).catch(this.throwError);
    }
    /**
     * @param {?} url
     * @param {?} params
     * @param {?=} header
     * @return {?}
     */
    delete(url, params, header) {
        /** @type {?} */
        const headers = this.creatHeader(header);
        return this.http.delete(url, { headers, params })
            .toPromise().then(this.checkResponeData).catch(this.throwError);
    }
    /**
     * @param {?} res
     * @return {?}
     */
    checkResponeData(res) {
        return res;
    }
    /**
     * @param {?} error
     * @return {?}
     */
    throwError(error) {
        return __awaiter(this, void 0, void 0, function* () {
            console.error(error);
            return error.error;
        });
    }
    /**
     * @param {?=} header
     * @return {?}
     */
    creatHeader(header) {
        /** @type {?} */
        const formObj = {
            Authorization: this.getAPDToken()
        };
        for (const key in header) {
            formObj[key] = header[key];
        }
        return new HttpHeaders(formObj);
    }
    /**
     * @return {?}
     */
    getAPDToken() {
        if (!window.localStorage.getItem('APDInfo')) {
            return 'Bearer ' + null;
        }
        /** @type {?} */
        const apdInfo = JSON.parse(window.localStorage.getItem('APDInfo'));
        return 'Bearer ' + apdInfo.accessToken;
    }
    /**
     * @param {?} url
     * @param {?=} params
     * @param {?=} header
     * @return {?}
     */
    getSSO(url, params, header) {
        /** @type {?} */
        const headers = this.creatSSOHeader(header);
        return this.http.get(url, { headers, params })
            .toPromise().then(this.checkResponeData).catch(this.throwError);
    }
    /**
     * @param {?} url
     * @param {?} params
     * @param {?=} header
     * @return {?}
     */
    postSSO(url, params, header) {
        /** @type {?} */
        const headers = this.creatSSOHeader(header);
        return this.http.post(url, params, { headers })
            .toPromise().then(this.checkResponeData).catch(this.throwError);
    }
    /**
     * @param {?} url
     * @param {?} params
     * @param {?=} header
     * @return {?}
     */
    putSSO(url, params, header) {
        /** @type {?} */
        const headers = this.creatSSOHeader(header);
        return this.http.put(url, params, { headers })
            .toPromise().then(this.checkResponeData).catch(this.throwError);
    }
    /**
     * @param {?} url
     * @param {?} params
     * @param {?=} header
     * @return {?}
     */
    deleteSSO(url, params, header) {
        /** @type {?} */
        const headers = this.creatSSOHeader(header);
        return this.http.delete(url, { headers, params })
            .toPromise().then(this.checkResponeData).catch(this.throwError);
    }
    /**
     * @param {?=} header
     * @return {?}
     */
    creatSSOHeader(header) {
        /** @type {?} */
        let formObj = {};
        if (sessionStorage.getItem('access_token')) {
            formObj = {
                Authorization: this.getSSOToken()
            };
        }
        for (const key in header) {
            formObj[key] = header[key];
        }
        return new HttpHeaders(formObj);
    }
    /**
     * @return {?}
     */
    getSSOToken() {
        return 'Bearer ' + sessionStorage.getItem('access_token');
    }
}
RequestClientService.decorators = [
    { type: Injectable, args: [{
                providedIn: 'root'
            },] }
];
/** @nocollapse */
RequestClientService.ctorParameters = () => [
    { type: HttpClient }
];
/** @nocollapse */ RequestClientService.ngInjectableDef = ɵɵdefineInjectable({ factory: function RequestClientService_Factory() { return new RequestClientService(ɵɵinject(HttpClient)); }, token: RequestClientService, providedIn: "root" });
if (false) {
    /**
     * @type {?}
     * @private
     */
    RequestClientService.prototype.http;
}

/**
 * @fileoverview added by tsickle
 * Generated from: lib/src/lib/gantt-interface.ts
 * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
/**
 * @record
 */
function XmppOptions() { }
if (false) {
    /** @type {?} */
    XmppOptions.prototype.mppInfo;
    /** @type {?} */
    XmppOptions.prototype.mppTasks;
    /** @type {?} */
    XmppOptions.prototype.mppExtendAttrs;
    /** @type {?} */
    XmppOptions.prototype.columns;
    /** @type {?} */
    XmppOptions.prototype.color;
    /** @type {?} */
    XmppOptions.prototype.size;
}
/** @enum {number} */
const XmppWeekDayType = {
    '日': 1,
    '一': 2,
    '二': 3,
    '三': 4,
    '四': 5,
    '五': 6,
    '六': 7,
};
XmppWeekDayType[XmppWeekDayType['日']] = '日';
XmppWeekDayType[XmppWeekDayType['一']] = '一';
XmppWeekDayType[XmppWeekDayType['二']] = '二';
XmppWeekDayType[XmppWeekDayType['三']] = '三';
XmppWeekDayType[XmppWeekDayType['四']] = '四';
XmppWeekDayType[XmppWeekDayType['五']] = '五';
XmppWeekDayType[XmppWeekDayType['六']] = '六';
class UInfoModel {
    /**
     * @param {?} param
     */
    constructor(param) {
        this.isFinished = 0;
        (param.isFinished) && (this.isFinished = param.isFinished);
        (param.finishAt) && (this.finishAt = param.finishAt);
        (param.uuid) && (this.uuid = param.uuid);
    }
}
if (false) {
    /** @type {?} */
    UInfoModel.prototype.uuid;
    /** @type {?} */
    UInfoModel.prototype.isFinished;
    /** @type {?} */
    UInfoModel.prototype.finishAt;
}
/**
 * @record
 */
function XmppColumn() { }
if (false) {
    /** @type {?} */
    XmppColumn.prototype.key;
    /** @type {?} */
    XmppColumn.prototype.name;
    /** @type {?} */
    XmppColumn.prototype.width;
    /** @type {?|undefined} */
    XmppColumn.prototype.type;
    /** @type {?|undefined} */
    XmppColumn.prototype.resize;
    /** @type {?|undefined} */
    XmppColumn.prototype.isEdit;
}
/**
 * @record
 */
function IXmpp() { }
if (false) {
    /** @type {?} */
    IXmpp.prototype.allTasks;
    /** @type {?} */
    IXmpp.prototype.globalLoading;
    /** @type {?} */
    IXmpp.prototype.mpp;
    /** @type {?} */
    IXmpp.prototype.task;
    /** @type {?} */
    IXmpp.prototype.calendar;
    /** @type {?} */
    IXmpp.prototype.draw;
    /** @type {?} */
    IXmpp.prototype.column;
    /**
     * @return {?}
     */
    IXmpp.prototype.render = function () { };
    /**
     * @param {?} type
     * @param {?=} cb
     * @return {?}
     */
    IXmpp.prototype.addGanttEventListener = function (type, cb) { };
}
/**
 * @record
 */
function IMPPProject() { }
if (false) {
    /** @type {?} */
    IMPPProject.prototype.actualsInSync;
    /** @type {?} */
    IMPPProject.prototype.adminProject;
    /** @type {?} */
    IMPPProject.prototype.assignments;
    /** @type {?} */
    IMPPProject.prototype.assignmentsUUIDs;
    /** @type {?} */
    IMPPProject.prototype.author;
    /** @type {?} */
    IMPPProject.prototype.autoAddNewResourcesAndTasks;
    /** @type {?} */
    IMPPProject.prototype.autolink;
    /** @type {?} */
    IMPPProject.prototype.baselineForEarnedValue;
    /** @type {?} */
    IMPPProject.prototype.calendarUID;
    /** @type {?} */
    IMPPProject.prototype.calendars;
    /** @type {?} */
    IMPPProject.prototype.calendarsUUIDs;
    /** @type {?} */
    IMPPProject.prototype.category;
    /** @type {?} */
    IMPPProject.prototype.company;
    /** @type {?} */
    IMPPProject.prototype.creationDate;
    /** @type {?} */
    IMPPProject.prototype.criticalSlackLimit;
    /** @type {?} */
    IMPPProject.prototype.currencyCode;
    /** @type {?} */
    IMPPProject.prototype.currencyDigits;
    /** @type {?} */
    IMPPProject.prototype.currencySymbol;
    /** @type {?} */
    IMPPProject.prototype.currencySymbolPosition;
    /** @type {?} */
    IMPPProject.prototype.currentDate;
    /** @type {?} */
    IMPPProject.prototype.daysPerMonth;
    /** @type {?} */
    IMPPProject.prototype.defaultFinishTime;
    /** @type {?} */
    IMPPProject.prototype.defaultFixedCostAccrual;
    /** @type {?} */
    IMPPProject.prototype.defaultOvertimeRate;
    /** @type {?} */
    IMPPProject.prototype.defaultStandardRate;
    /** @type {?} */
    IMPPProject.prototype.defaultStartTime;
    /** @type {?} */
    IMPPProject.prototype.defaultTaskEVMethod;
    /** @type {?} */
    IMPPProject.prototype.defaultTaskType;
    /** @type {?} */
    IMPPProject.prototype.durationFormat;
    /** @type {?} */
    IMPPProject.prototype.earnedValueMethod;
    /** @type {?} */
    IMPPProject.prototype.editableActualCosts;
    /** @type {?} */
    IMPPProject.prototype.enabled;
    /** @type {?} */
    IMPPProject.prototype.extendedAttributes;
    /** @type {?} */
    IMPPProject.prototype.extendedAttributesUUIDs;
    /** @type {?} */
    IMPPProject.prototype.extendedCreationDate;
    /** @type {?} */
    IMPPProject.prototype.finishDate;
    /** @type {?} */
    IMPPProject.prototype.fiscalYearStart;
    /** @type {?} */
    IMPPProject.prototype.fyStartDate;
    /** @type {?} */
    IMPPProject.prototype.honorConstraints;
    /** @type {?} */
    IMPPProject.prototype.id;
    /** @type {?} */
    IMPPProject.prototype.insertedProjectsLikeSummary;
    /** @type {?} */
    IMPPProject.prototype.lastSaved;
    /** @type {?} */
    IMPPProject.prototype.manager;
    /** @type {?} */
    IMPPProject.prototype.microsoftProjectServerURL;
    /** @type {?} */
    IMPPProject.prototype.minutesPerDay;
    /** @type {?} */
    IMPPProject.prototype.minutesPerWeek;
    /** @type {?} */
    IMPPProject.prototype.moveCompletedEndsBack;
    /** @type {?} */
    IMPPProject.prototype.moveCompletedEndsForward;
    /** @type {?} */
    IMPPProject.prototype.moveRemainingStartsBack;
    /** @type {?} */
    IMPPProject.prototype.moveRemainingStartsForward;
    /** @type {?} */
    IMPPProject.prototype.multipleCriticalPaths;
    /** @type {?} */
    IMPPProject.prototype.name;
    /** @type {?} */
    IMPPProject.prototype.newTaskStartDate;
    /** @type {?} */
    IMPPProject.prototype.newTasksEffortDriven;
    /** @type {?} */
    IMPPProject.prototype.newTasksEstimated;
    /** @type {?} */
    IMPPProject.prototype.parentId;
    /** @type {?} */
    IMPPProject.prototype.projectExternallyEdited;
    /** @type {?} */
    IMPPProject.prototype.removeFileProperties;
    /** @type {?} */
    IMPPProject.prototype.resources;
    /** @type {?} */
    IMPPProject.prototype.resourcesUUIDs;
    /** @type {?} */
    IMPPProject.prototype.revision;
    /** @type {?} */
    IMPPProject.prototype.saveVersion;
    /** @type {?} */
    IMPPProject.prototype.scheduleFromStart;
    /** @type {?} */
    IMPPProject.prototype.splitsInProgressTasks;
    /** @type {?} */
    IMPPProject.prototype.spreadActualCost;
    /** @type {?} */
    IMPPProject.prototype.spreadPercentComplete;
    /** @type {?} */
    IMPPProject.prototype.startDate;
    /** @type {?} */
    IMPPProject.prototype.statusDate;
    /** @type {?} */
    IMPPProject.prototype.subject;
    /** @type {?} */
    IMPPProject.prototype.taskUpdatesResource;
    /** @type {?} */
    IMPPProject.prototype.tasks;
    /** @type {?} */
    IMPPProject.prototype.tasksUUIDs;
    /** @type {?} */
    IMPPProject.prototype.title;
    /** @type {?} */
    IMPPProject.prototype.uid;
    /** @type {?} */
    IMPPProject.prototype.weekStartDay;
    /** @type {?} */
    IMPPProject.prototype.workFormat;
    /* Skipping unhandled member: [key: string]: any;*/
}
/**
 * @record
 */
function IMppCalendar() { }
if (false) {
    /** @type {?} */
    IMppCalendar.prototype.uid;
    /** @type {?} */
    IMppCalendar.prototype.name;
    /** @type {?} */
    IMppCalendar.prototype.isBaseCalendar;
    /** @type {?} */
    IMppCalendar.prototype.baseCalendarUID;
    /** @type {?} */
    IMppCalendar.prototype.weekDays;
    /** @type {?} */
    IMppCalendar.prototype.weekDaysUUIDs;
    /** @type {?} */
    IMppCalendar.prototype.exceptions;
    /** @type {?} */
    IMppCalendar.prototype.exceptionsUUIDs;
    /** @type {?} */
    IMppCalendar.prototype.enabled;
    /** @type {?} */
    IMppCalendar.prototype.parentId;
    /** @type {?} */
    IMppCalendar.prototype.id;
}
/**
 * @record
 */
function IMppWeekDay() { }
if (false) {
    /** @type {?} */
    IMppWeekDay.prototype.dayType;
    /** @type {?} */
    IMppWeekDay.prototype.dayWorking;
    /** @type {?} */
    IMppWeekDay.prototype.fromDate;
    /** @type {?} */
    IMppWeekDay.prototype.toDate;
    /** @type {?} */
    IMppWeekDay.prototype.fromTime_0;
    /** @type {?} */
    IMppWeekDay.prototype.toTime_0;
    /** @type {?} */
    IMppWeekDay.prototype.fromTime_1;
    /** @type {?} */
    IMppWeekDay.prototype.toTime_1;
    /** @type {?} */
    IMppWeekDay.prototype.fromTime_2;
    /** @type {?} */
    IMppWeekDay.prototype.toTime_2;
    /** @type {?} */
    IMppWeekDay.prototype.fromTime_3;
    /** @type {?} */
    IMppWeekDay.prototype.toTime_3;
    /** @type {?} */
    IMppWeekDay.prototype.fromTime_4;
    /** @type {?} */
    IMppWeekDay.prototype.toTime_4;
    /** @type {?} */
    IMppWeekDay.prototype.enabled;
    /** @type {?} */
    IMppWeekDay.prototype.parentId;
    /** @type {?} */
    IMppWeekDay.prototype.id;
}
/**
 * @record
 */
function IMppCalendarException() { }
if (false) {
    /** @type {?} */
    IMppCalendarException.prototype.enteredByOccurrences;
    /** @type {?} */
    IMppCalendarException.prototype.fromDate;
    /** @type {?} */
    IMppCalendarException.prototype.toDate;
    /** @type {?} */
    IMppCalendarException.prototype.occurrences;
    /** @type {?} */
    IMppCalendarException.prototype.name;
    /** @type {?} */
    IMppCalendarException.prototype.type;
    /** @type {?} */
    IMppCalendarException.prototype.period;
    /** @type {?} */
    IMppCalendarException.prototype.dasyOfWeek;
    /** @type {?} */
    IMppCalendarException.prototype.monthIten;
    /** @type {?} */
    IMppCalendarException.prototype.monthPosition;
    /** @type {?} */
    IMppCalendarException.prototype.month;
    /** @type {?} */
    IMppCalendarException.prototype.monthDay;
    /** @type {?} */
    IMppCalendarException.prototype.dayWorking;
    /** @type {?} */
    IMppCalendarException.prototype.parentId;
    /** @type {?} */
    IMppCalendarException.prototype.id;
}
/**
 * @record
 */
function IMppTask() { }
if (false) {
    /** @type {?} */
    IMppTask.prototype.active;
    /** @type {?} */
    IMppTask.prototype.actualCost;
    /** @type {?} */
    IMppTask.prototype.actualDuration;
    /** @type {?} */
    IMppTask.prototype.actualFinish;
    /** @type {?} */
    IMppTask.prototype.actualOvertimeCost;
    /** @type {?} */
    IMppTask.prototype.actualOvertimeWork;
    /** @type {?} */
    IMppTask.prototype.actualOvertimeWorkProtected;
    /** @type {?} */
    IMppTask.prototype.actualStart;
    /** @type {?} */
    IMppTask.prototype.actualWork;
    /** @type {?} */
    IMppTask.prototype.actualWorkProtected;
    /** @type {?} */
    IMppTask.prototype.acwp;
    /** @type {?} */
    IMppTask.prototype.baseline;
    /** @type {?} */
    IMppTask.prototype.baselineUUIDs;
    /** @type {?} */
    IMppTask.prototype.bcwp;
    /** @type {?} */
    IMppTask.prototype.bcws;
    /** @type {?} */
    IMppTask.prototype.calendarUID;
    /** @type {?} */
    IMppTask.prototype.commitmentFinish;
    /** @type {?} */
    IMppTask.prototype.commitmentStart;
    /** @type {?} */
    IMppTask.prototype.commitmentType;
    /** @type {?} */
    IMppTask.prototype.constraintDate;
    /** @type {?} */
    IMppTask.prototype.constraintType;
    /** @type {?} */
    IMppTask.prototype.contact;
    /** @type {?} */
    IMppTask.prototype.cost;
    /** @type {?} */
    IMppTask.prototype.createDate;
    /** @type {?} */
    IMppTask.prototype.critical;
    /** @type {?} */
    IMppTask.prototype.cv;
    /** @type {?} */
    IMppTask.prototype.deadline;
    /** @type {?} */
    IMppTask.prototype.duration;
    /** @type {?} */
    IMppTask.prototype.durationFormat;
    /** @type {?} */
    IMppTask.prototype.earlyFinish;
    /** @type {?} */
    IMppTask.prototype.earlyStart;
    /** @type {?} */
    IMppTask.prototype.earnedValueMethod;
    /** @type {?} */
    IMppTask.prototype.effortDriven;
    /** @type {?} */
    IMppTask.prototype.enabled;
    /** @type {?} */
    IMppTask.prototype.estimated;
    /** @type {?} */
    IMppTask.prototype.extendedAttribute;
    /** @type {?} */
    IMppTask.prototype.extendedAttributeUUIDs;
    /** @type {?} */
    IMppTask.prototype.externalTask;
    /** @type {?} */
    IMppTask.prototype.externalTaskProject;
    /** @type {?} */
    IMppTask.prototype.finish;
    /** @type {?} */
    IMppTask.prototype.finishVariance;
    /** @type {?} */
    IMppTask.prototype.fixedCost;
    /** @type {?} */
    IMppTask.prototype.fixedCostAccrual;
    /** @type {?} */
    IMppTask.prototype.freeSlack;
    /** @type {?} */
    IMppTask.prototype.hideBar;
    /** @type {?} */
    IMppTask.prototype.hyperlink;
    /** @type {?} */
    IMppTask.prototype.hyperlinkAddress;
    /** @type {?} */
    IMppTask.prototype.hyperlinkSubAddress;
    /** @type {?} */
    IMppTask.prototype.id;
    /** @type {?} */
    IMppTask.prototype.ignoreResourceCalendar;
    /** @type {?} */
    IMppTask.prototype.isNull;
    /** @type {?} */
    IMppTask.prototype.isPublished;
    /** @type {?} */
    IMppTask.prototype.isSubproject;
    /** @type {?} */
    IMppTask.prototype.isSubprojectReadOnly;
    /** @type {?} */
    IMppTask.prototype.lateFinish;
    /** @type {?} */
    IMppTask.prototype.lateStart;
    /** @type {?} */
    IMppTask.prototype.levelAssignments;
    /** @type {?} */
    IMppTask.prototype.levelingCanSplit;
    /** @type {?} */
    IMppTask.prototype.levelingDelay;
    /** @type {?} */
    IMppTask.prototype.levelingDelayFormat;
    /** @type {?} */
    IMppTask.prototype.manual;
    /** @type {?} */
    IMppTask.prototype.milestone;
    /** @type {?} */
    IMppTask.prototype.name;
    /** @type {?} */
    IMppTask.prototype.notes;
    /** @type {?} */
    IMppTask.prototype.outlineLevel;
    /** @type {?} */
    IMppTask.prototype.outlineNumber;
    /** @type {?} */
    IMppTask.prototype.overAllocated;
    /** @type {?} */
    IMppTask.prototype.overtimeCost;
    /** @type {?} */
    IMppTask.prototype.overtimeWork;
    /** @type {?} */
    IMppTask.prototype.parentId;
    /** @type {?} */
    IMppTask.prototype.percentComplete;
    /** @type {?} */
    IMppTask.prototype.percentWorkComplete;
    /** @type {?} */
    IMppTask.prototype.physicalPercentComplete;
    /** @type {?} */
    IMppTask.prototype.preLeveledFinish;
    /** @type {?} */
    IMppTask.prototype.preLeveledStart;
    /** @type {?} */
    IMppTask.prototype.predecessorLink;
    /** @type {?} */
    IMppTask.prototype.predecessorLinkUUIDs;
    /** @type {?} */
    IMppTask.prototype.priority;
    /** @type {?} */
    IMppTask.prototype.recurring;
    /** @type {?} */
    IMppTask.prototype.regularWork;
    /** @type {?} */
    IMppTask.prototype.remainingCost;
    /** @type {?} */
    IMppTask.prototype.remainingDuration;
    /** @type {?} */
    IMppTask.prototype.remainingOvertimeCost;
    /** @type {?} */
    IMppTask.prototype.remainingOvertimeWork;
    /** @type {?} */
    IMppTask.prototype.remainingWork;
    /** @type {?} */
    IMppTask.prototype.resume;
    /** @type {?} */
    IMppTask.prototype.resumeValid;
    /** @type {?} */
    IMppTask.prototype.rollup;
    /** @type {?} */
    IMppTask.prototype.starVariance;
    /** @type {?} */
    IMppTask.prototype.start;
    /** @type {?} */
    IMppTask.prototype.statusmanager;
    /** @type {?} */
    IMppTask.prototype.stop;
    /** @type {?} */
    IMppTask.prototype.subprojectName;
    /** @type {?} */
    IMppTask.prototype.summary;
    /** @type {?} */
    IMppTask.prototype.totalSlack;
    /** @type {?} */
    IMppTask.prototype.type;
    /** @type {?} */
    IMppTask.prototype.uid;
    /** @type {?} */
    IMppTask.prototype.wbs;
    /** @type {?} */
    IMppTask.prototype.wbsLevel;
    /** @type {?} */
    IMppTask.prototype.work;
    /** @type {?} */
    IMppTask.prototype.workVariance;
    /** @type {?} */
    IMppTask.prototype._ID;
    /** @type {?} */
    IMppTask.prototype.customAttrs;
}
/**
 * @record
 */
function IMppExtendAttr() { }
if (false) {
    /** @type {?} */
    IMppExtendAttr.prototype.alias;
    /** @type {?} */
    IMppExtendAttr.prototype.appendNewValues;
    /** @type {?} */
    IMppExtendAttr.prototype.autoRollDown;
    /** @type {?} */
    IMppExtendAttr.prototype.calculationType;
    /** @type {?} */
    IMppExtendAttr.prototype.cfType;
    /** @type {?} */
    IMppExtendAttr.prototype.default;
    /** @type {?} */
    IMppExtendAttr.prototype.defaultGuid;
    /** @type {?} */
    IMppExtendAttr.prototype.elemType;
    /** @type {?} */
    IMppExtendAttr.prototype.enabled;
    /** @type {?} */
    IMppExtendAttr.prototype.fieldID;
    /** @type {?} */
    IMppExtendAttr.prototype.fieldName;
    /** @type {?} */
    IMppExtendAttr.prototype.formula;
    /** @type {?} */
    IMppExtendAttr.prototype.id;
    /** @type {?} */
    IMppExtendAttr.prototype.ltuid;
    /** @type {?} */
    IMppExtendAttr.prototype.maxMultiValues;
    /** @type {?} */
    IMppExtendAttr.prototype.parentId;
    /** @type {?} */
    IMppExtendAttr.prototype.phoneticAlias;
    /** @type {?} */
    IMppExtendAttr.prototype.restrictValues;
    /** @type {?} */
    IMppExtendAttr.prototype.rollupType;
    /** @type {?} */
    IMppExtendAttr.prototype.secondaryPID;
    /** @type {?} */
    IMppExtendAttr.prototype.userDef;
    /** @type {?} */
    IMppExtendAttr.prototype.valuelistSortOrder;
    /** @type {?} */
    IMppExtendAttr.prototype._Guid;
}
/**
 * @record
 */
function XmppTaskExtendedAttribute() { }
if (false) {
    /** @type {?} */
    XmppTaskExtendedAttribute.prototype.fieldID;
    /** @type {?} */
    XmppTaskExtendedAttribute.prototype.value;
    /** @type {?} */
    XmppTaskExtendedAttribute.prototype.valueGUID;
    /** @type {?} */
    XmppTaskExtendedAttribute.prototype.durationFormat;
    /** @type {?} */
    XmppTaskExtendedAttribute.prototype.enabled;
    /** @type {?} */
    XmppTaskExtendedAttribute.prototype.parentId;
    /** @type {?} */
    XmppTaskExtendedAttribute.prototype.id;
}
/**
 * @record
 */
function XmppResource() { }
if (false) {
    /** @type {?} */
    XmppResource.prototype.uid;
    /** @type {?} */
    XmppResource.prototype.name;
    /** @type {?} */
    XmppResource.prototype.start;
    /** @type {?} */
    XmppResource.prototype.finish;
    /** @type {?} */
    XmppResource.prototype.work;
}
/**
 * @record
 */
function XmppWeekDay() { }
if (false) {
    /** @type {?} */
    XmppWeekDay.prototype.id;
    /** @type {?} */
    XmppWeekDay.prototype.dayType;
    /** @type {?} */
    XmppWeekDay.prototype.dayWorking;
    /** @type {?} */
    XmppWeekDay.prototype.fromDate;
    /** @type {?} */
    XmppWeekDay.prototype.toDate;
    /** @type {?} */
    XmppWeekDay.prototype.dayText;
}
/**
 * @record
 */
function XmppExceptDate() { }
if (false) {
    /** @type {?|undefined} */
    XmppExceptDate.prototype.id;
    /** @type {?} */
    XmppExceptDate.prototype.name;
    /** @type {?} */
    XmppExceptDate.prototype.fromDate;
    /** @type {?} */
    XmppExceptDate.prototype.toDate;
    /** @type {?|undefined} */
    XmppExceptDate.prototype.parentId;
}
// export class EditModel {
//     public relations: PredecessorLinkModel[];
//     public taskName: string;
//     public showDuration: number;
//     public constructor(param) {
//         (param.relations) && (this.relations = param.relations);
//         (param.taskName) && (this.taskName = param.taskName);
//         (param.showDuration) && (this.showDuration = param.showDuration);
//     }
// }
// export interface IAddTask {
//     id?: number;
//     taskName?: string;
//     isMilepost?: boolean;
//     startDate?: any;
//     endDate?: any;
// }
class XmppTask {
    /**
     * @param {?} param
     */
    constructor(param) {
        this.isSelected = false;
        this.step = 0;
        this.childTaskID = [];
        this.parentTaskID = null;
        this.level = 1;
        this.isFold = false;
        this.defaultData = null;
        this.bindings = [];
        this.allFinished = false;
        this.isMilepost = false;
        this._exceptDuration = 0;
        this._exceptActualDuration = 0;
        this._finishRate = 0;
        this.isKey = false;
        this.laterChildId = null;
        this.earlierChildId = null;
        this._startDate = null;
        this._endDate = null;
        this.isActualKey = false;
        this.acLaterChildId = null;
        this.acEarlierChildId = null;
        this._actualStartDate = null;
        this._actualDuration = null;
        this._actualEndDate = null;
        this.tags = [];
        this.resources = [];
        this.firstSet = false;
        this.firstSet = true;
        (param.Xmpp) && (this.Xmpp = param.Xmpp);
        // 任务自定义的属性集合
        (param.CustomAttrs) && (this.CustomAttrs = param.CustomAttrs);
        // 任务所有的extendedAttribute
        (param.extendedAttribute) && (this.extendedAttribute = param.extendedAttribute);
        // xmpp自定义extendedAttribute，即FildId为'188744016'的
        (param.customExtendAttr) && (this.customExtendAttr = param.customExtendAttr);
        // 数据库id
        (param.sqId) && (this.sqId = param.sqId);
        // UID
        (param.uid) && (this.uid = param.uid);
        // 标识符--orderId
        (param.id) && (this.id = param.id);
        // 标识符--对接模型
        (param.symbol) && (this.symbol = param.symbol);
        // 所属甘特图id
        (param.ganttChartId) && (this.ganttChartId = param.ganttChartId);
        // 所属甘特图id
        (param.wbs) && (this.wbs = param.wbs);
        // 任务名称
        (param.taskName) && (this.taskName = param.taskName);
        // 是否被选中
        (param.isSelected) && (this.isSelected = param.isSelected);
        // 计划工期
        (!isNullOrUndefined(param.duration)) && (this.duration = param.duration);
        // 计划开始时间
        (param.startDate) && (this.startDate = param.startDate);
        // 计划完成时间
        (param.endDate) && (this.endDate = param.endDate);
        // 实际工期
        (!isNullOrUndefined(param.actualDuration)) && (this.actualDuration = param.actualDuration);
        // 实际开始时间
        (param.actualStartDate) && (this.actualStartDate = param.actualStartDate);
        // 实际完成时间
        (param.actualEndDate) && (this.actualEndDate = param.actualEndDate);
        // 前置任务（已废弃）
        // (param.prevTask) && (this.prevTask = param.prevTask);
        // 紧前任务
        (param.truePrevTaskID) && (this.truePrevTaskID = param.truePrevTaskID);
        // 是否是关键任务
        (param.isKey) && (this.isKey = param.isKey);
        // 子任务id
        (param.childTaskID) && (this.childTaskID = param.childTaskID);
        // 父任务id
        (param.parentTaskID) && (this.parentTaskID = param.parentTaskID);
        // 级别
        (param.level) && (this.level = param.level);
        // 绑定的构件
        (param.bindings) && (this.bindings = param.bindings);
        // 是否是里程碑
        (param.isMilepost) && (this.isMilepost = param.isMilepost);
        // 完成率
        (param.finishRate !== null) && (this.finishRate = param.finishRate);
        // 前置任务
        (param.prevRelation) && (this.prevRelation = param.prevRelation);
        // 目前的状态
        (param.step) && (this.step = param.step);
        // 摘要任务下,影响摘要任务结束时间时间的任务
        (param.laterChildId) && (this.laterChildId = param.laterChildId);
        // 摘要任务下,影响摘要任务开始时间的任务
        (param.earlierChildId) && (this.earlierChildId = param.earlierChildId);
        // 摘要任务下,影响摘要任务结束时间时间的任务
        (param.acLaterChildId) && (this.acLaterChildId = param.acLaterChildId);
        // 摘要任务下,影响摘要任务开始时间的任务
        (param.acEarlierChildId) && (this.acEarlierChildId = param.acEarlierChildId);
        // 任务中的额外日期工期
        (param.exceptDuration) && (this.exceptDuration = param.exceptDuration);
        // 任务中的额外日期工期
        (param.exceptActualDuration) && (this.exceptActualDuration = param.exceptActualDuration);
        // 任务显示的工期
        (param.showDuration) && (this.showDuration = param.showDuration);
        // 任务显示的实际工期
        (param.showActualDuration) && (this.showActualDuration = param.showActualDuration);
        (param.tags) && (this.tags = param.tags);
        (param.resources) && (this.resources = param.resources);
        // this.defaultData = this;
        /** @type {?} */
        const defaultData = {
            startDate: this.startDate,
            duration: this.duration,
            endDate: this.endDate,
            taskName: this.taskName,
            parentTaskID: this.parentTaskID,
            actualDuration: this.actualDuration,
            actualStart: this.actualStartDate,
            actualEndDate: this.actualEndDate,
            level: this.level,
            wbs: this.wbs,
            tags: this.tags,
            resources: this.resources
        };
        this.firstSet = false;
        this.defaultData = JSON.parse(JSON.stringify(defaultData));
    }
    /**
     * @return {?}
     */
    get exceptDuration() {
        return this._exceptDuration;
    }
    /**
     * @param {?} value
     * @return {?}
     */
    set exceptDuration(value) {
        this._exceptDuration = value;
    }
    /**
     * @return {?}
     */
    get exceptActualDuration() {
        return this._exceptActualDuration;
    }
    /**
     * @param {?} value
     * @return {?}
     */
    set exceptActualDuration(value) {
        // 实际时间
        if (this._actualDuration) {
            this.showActualDuration = this._actualDuration - value;
        }
        else {
            if (this._actualStartDate && this._actualEndDate) {
                /** @type {?} */
                const num = moment(this._actualEndDate).clone().diff(moment(this._actualStartDate), 'days');
                this.showActualDuration = num + 1;
            }
        }
        this._exceptActualDuration = value;
    }
    /**
     * @return {?}
     */
    get finishRate() {
        /** @type {?} */
        const finish = [];
        if (this.bindings.length > 0) {
            this.bindings.forEach((/**
             * @param {?} element
             * @return {?}
             */
            (element) => {
                if (element.isFinished) {
                    finish.push(element);
                }
            }));
            if (finish.length > 0) {
                this._finishRate = finish.length / this.bindings.length;
            }
            else {
                this._finishRate = 0;
            }
        }
        if (this._finishRate === 1) {
            this.allFinished = true;
        }
        return this._finishRate;
    }
    /**
     * @param {?} value
     * @return {?}
     */
    set finishRate(value) {
        if (value === 1) {
            this.allFinished = true;
        }
        this._finishRate = value;
    }
    /**
     * @return {?}
     */
    get startDate() {
        return this._startDate;
    }
    /**
     * @param {?} value
     * @return {?}
     */
    set startDate(value) {
        if (!this.firstSet && this.childTaskID.length <= 0 && value) {
            // value = this.handleStartDate(value);
            value = this.Xmpp.task.nextDatePipe(value);
            /** @type {?} */
            let endDate = this._endDate;
            if (this._duration !== 0) {
                endDate = moment(value).add(this._duration - 1, 'days').toDate();
            }
            else {
                endDate = value;
            }
            this._endDate = this.Xmpp.task.getEndDateWithExcept(value, this._duration, endDate);
        }
        this._startDate = value;
    }
    /**
     * @return {?}
     */
    get duration() {
        // if (this._startDate && this._endDate) {
        //     const num = moment(this._endDate).clone().diff(moment(this._startDate), 'days');
        //     this._duration = num + 1;
        // }
        return !isNullOrUndefined(this._duration) ? this._duration : 0;
    }
    /**
     * @param {?} value
     * @return {?}
     */
    set duration(value) {
        // value = this.handleDuration(parseInt(value));
        // if (this.childTaskID.length === 0 && value) {
        //     value = this.handleDuration(parseInt(value));
        // } else {
        //     value = moment(this._endDate).clone().diff(moment(this._startDate), 'days') + 1;
        // }
        this._duration = value;
    }
    /**
     * @return {?}
     */
    get endDate() {
        return this._endDate;
    }
    /**
     * @param {?} value
     * @return {?}
     */
    set endDate(value) {
        if (!this.firstSet && this.childTaskID.length === 0 && value) {
            value = this.Xmpp.task.lastDatePipe(value);
            /** @type {?} */
            let startDate = this._startDate;
            if (!this.duration) {
                startDate = value;
            }
            this._startDate = this.Xmpp.task.getStartDateWithExcept(startDate, this._duration, value);
        }
        this._endDate = value;
    }
    /**
     * @return {?}
     */
    get showDuration() {
        return this._showDuration ? this._showDuration : 0;
    }
    /**
     * @param {?} value
     * @return {?}
     */
    set showDuration(value) {
        this._showDuration = value;
    }
    /**
     * @return {?}
     */
    get actualStartDate() {
        return this._actualStartDate;
    }
    /**
     * @param {?} value
     * @return {?}
     */
    set actualStartDate(value) {
        if (this.childTaskID.length === 0 && value) {
            value = this.handleActualStartDate(value);
        }
        this._actualStartDate = value;
    }
    /**
     * @return {?}
     */
    get actualDuration() {
        if (this._actualStartDate && this._actualEndDate) {
            /** @type {?} */
            const num = moment(this._actualEndDate).clone().diff(moment(this._actualStartDate), 'days');
            this._actualDuration = num + 1;
        }
        return this._actualDuration;
    }
    /**
     * @param {?} value
     * @return {?}
     */
    set actualDuration(value) {
        if (this.childTaskID.length === 0) {
            value = this.handleActualDuration(value);
        }
        this._actualDuration = value;
    }
    /**
     * @return {?}
     */
    get actualEndDate() {
        return this._actualEndDate;
    }
    /**
     * @param {?} value
     * @return {?}
     */
    set actualEndDate(value) {
        // if (this.childTaskID.length == 0 && value) {
        //   value = this.handleActualEndDate(value)
        // }
        this._endDate = value;
        this._actualEndDate = value;
    }
    /**
     * @return {?}
     */
    toJson() {
        return {
            orderId: this.id,
            ganttChartId: this.ganttChartId,
            taskName: this.taskName,
            startAt: this.startDate ? moment(this.startDate).unix() : null,
            finishAt: this.endDate ? moment(this.endDate).unix() : null,
            duration: this.duration,
            actualStartAt: this.actualStartDate ? moment(this.actualStartDate).unix() : null,
            actualFinishAt: this.actualEndDate === 1 ? moment(this.actualEndDate).unix() : null,
            parentTaskId: this.parentTaskID,
            preTask: JSON.stringify(this.prevRelation),
            childTaskID: this.childTaskID,
            level: this.level,
            bindings: this.bindings,
            milestone: this.isMilepost ? 1 : 0,
            finishRate: this.finishRate,
            step: this.step
            // sqlStartDate: this.sqlStartDate ? moment(this.sqlStartDate).unix() : null,
            // sqlEndDate: this.sqlEndDate ? moment(this.sqlEndDate).unix() : null,
            // sqlDuration: this.sqlDuration,
            // sqlActualStartDate: this.sqlActualStartDate,
            // sqlActualEndDate: this.sqlActualEndDate,
            // sqlActualDuration: this.sqlActualDuration,
        };
    }
    /**
     * @return {?}
     */
    toEditJson() {
        return {
            id: this.sqId,
            orderId: this.id,
            ganttChartId: this.ganttChartId,
            taskName: this.taskName,
            startAt: this.startDate ? moment(this.startDate).unix() : null,
            finishAt: this.endDate ? moment(this.endDate).unix() : null,
            duration: this.duration,
            actualStartAt: this.actualStartDate ? moment(this.actualStartDate).unix() : null,
            actualFinishAt: this.actualEndDate ? moment(this.actualEndDate).unix() : null,
            parentTaskId: this.parentTaskID,
            preTask: JSON.stringify(this.prevRelation),
            childTaskID: this.childTaskID,
            level: this.level,
            bindings: this.bindings,
            milestone: this.isMilepost ? 1 : 0,
            finishRate: this.finishRate,
            step: this.step
            // sqlStartDate: this.sqlStartDate ? moment(this.sqlStartDate).unix() : null,
            // sqlEndDate: this.sqlEndDate ? moment(this.sqlEndDate).unix() : null,
            // sqlDuration: this.sqlDuration,
            // sqlActualStartDate: this.sqlActualStartDate ? moment(this.sqlActualStartDate).unix() : null,
            // sqlActualEndDate: this.sqlActualEndDate ? moment(this.sqlActualEndDate).unix() : null,
            // sqlActualDuration: this.sqlActualDuration ? moment(this.sqlActualDuration).unix() : null,
        };
    }
    /**
     * @return {?}
     */
    toMpp() {
        /** @type {?} */
        const CustomAttrs = new Object();
        CustomAttrs.tags = this.tags;
        return {
            Id: this.sqId,
            // 数据库id
            _ID: this.id,
            // orderid
            UID: this.uid,
            ParentId: this.ganttChartId,
            Name: this.taskName,
            Start: this.startDate ? moment(this.startDate).format('YYYY-MM-DD') : null,
            Finish: this.endDate ? moment(this.endDate).format('YYYY-MM-DD') : null,
            Duration: `PT${this.duration * 8}H0M0S`,
            ActualStart: this.actualStartDate ? moment(this.actualStartDate).format('YYYY-MM-DD') : null,
            ActualFinish: this.actualEndDate ? moment(this.actualEndDate).format('YYYY-MM-DD') : null,
            WBS: this.wbs,
            Milestone: this.isMilepost,
            CustomAttrs: JSON.stringify(CustomAttrs)
        };
    }
    /**
     * @param {?} date
     * @return {?}
     */
    getMomentStart(date) {
        /** @type {?} */
        const format = moment(date).format('YYYY-MM-DD');
        return moment(format).format();
    }
    /**
     * @param {?} startDate
     * @return {?}
     */
    handleStartDate(startDate) {
        startDate = this.getMomentStart(startDate);
        /** @type {?} */
        const duration = this._duration;
        /** @type {?} */
        let correctDate = startDate;
        // if (this.exceptDate && this.exceptDate.length > 0) {
        //     this.exceptDate.forEach((item) => {
        //         if (unix <= item.endDate && unix >= item.startDate) {
        //             // 如果所选s在额外日期之间，d不变，e=s+d
        //             // let errorDate = moment(startDate).format('MM/DD');
        //             const correct = moment.unix(item.endDate).clone().add(1, 'days').toDate();
        //             // GanttModel.message.confirm('warning', `任务${this.id}的计划开始时间${errorDate}为非工作日，将移动该任务开始时间到下一工作日${correct.format('MM/DD')}。`, 10000);
        //             startDate = correct;
        //         }
        //     });
        // }
        /** @type {?} */
        const getStartDateFromWeekDay = (/**
         * @param {?} startDateInput
         * @return {?}
         */
        (startDateInput) => {
            /** @type {?} */
            const dayWeekType = new Date(moment(startDateInput).unix() * 1000).getDay();
            if (this.Xmpp.calendar.pauseWeekDayTypes.indexOf(dayWeekType + 1) !== -1) {
                /** @type {?} */
                const nextDate = moment(startDateInput).clone().add(1, 'days').toDate();
                startDateInput = nextDate;
                getStartDateFromWeekDay(startDateInput);
            }
            else {
                correctDate = startDateInput;
                return;
            }
        });
        /** @type {?} */
        const startUnix = startDate ? moment(startDate).unix() : null;
        if (this.Xmpp.calendar.exceptDate) {
            this.Xmpp.calendar.exceptDate.forEach((/**
             * @param {?} exceptDate
             * @return {?}
             */
            (exceptDate) => {
                // 任务开始时间在例外日期之间
                /** @type {?} */
                const exceptDateStart = moment(exceptDate.fromDate).unix();
                /** @type {?} */
                const exceptDateEnd = moment(exceptDate.toDate).unix();
                if (startUnix <= exceptDateEnd && startUnix >= exceptDateStart) {
                    /** @type {?} */
                    const nextDate = moment.unix(exceptDateEnd).clone().add(1, 'days').toDate();
                    if (moment(nextDate).clone().isAfter(moment(startDate))) {
                        correctDate = correctDate;
                        // maxStartDate = correctDate;
                    }
                }
                // // 任务结束时间在例外日期之间
                // if (endUnix <= exceptDateEnd && endUnix >= exceptDateStart) {
                //     const correctDate = moment.unix(exceptDateEnd).clone().add(1, 'days').toDate();
                //     task.endDate = correctDate;
                // }
            }));
        }
        getStartDateFromWeekDay(startDate);
        startDate = correctDate;
        return startDate;
    }
    /**
     * @param {?} endDate
     * @return {?}
     */
    handleEndDate(endDate) {
        endDate = this.getMomentStart(endDate);
        // const unix = endDate ? moment(endDate).unix() : null;
        /** @type {?} */
        const duration = this._duration;
        /** @type {?} */
        let correctDate = endDate;
        // const startUnix = moment(this._startDate).unix();
        // if (this.exceptDate && this.exceptDate.length > 0) {
        //     // 有额外日期
        //     this.exceptDate.forEach((item) => {
        //         if (unix <= item.endDate && unix >= item.startDate) {
        //             // 所选endDate在额外日期之间，e自动延至额外日期结束后一天，s不变，d=e-s
        //             const errorDate = moment(endDate).format('MM/DD');
        //             const correct = moment.unix(item.endDate).clone().add(1, 'days');
        //             // GanttModel.message.confirm('warning', `任务${this.id}的计划结束时间${errorDate}为非工作日，将移动该任务结束时间到下一工作日${correct.format('MM/DD')}。`, 10000);
        //             this._exceptDuration = moment.unix(item.endDate).clone().diff(moment.unix(item.startDate), 'days') + 1;
        //             endDate = correct;
        //         }
        //     });
        // }
        /** @type {?} */
        const getEndDateFromWeekDay = (/**
         * @param {?} dateInput
         * @return {?}
         */
        (dateInput) => {
            /** @type {?} */
            const dayWeekType = new Date(moment(dateInput).unix() * 1000).getDay();
            if (this.Xmpp.calendar.pauseWeekDayTypes.indexOf(dayWeekType + 1) !== -1) {
                /** @type {?} */
                const nextDate = moment(dateInput).clone().add(1, 'days').toDate();
                dateInput = nextDate;
                getEndDateFromWeekDay(dateInput);
            }
            else {
                correctDate = dateInput;
                return;
            }
        });
        if (this.Xmpp.calendar.exceptDate) {
            /** @type {?} */
            const endUnix = endDate ? moment(endDate).unix() : null;
            this.Xmpp.calendar.exceptDate.forEach((/**
             * @param {?} exceptDate
             * @return {?}
             */
            (exceptDate) => {
                /** @type {?} */
                const exceptDateStart = moment(exceptDate.fromDate).unix();
                /** @type {?} */
                const exceptDateEnd = moment(exceptDate.toDate).unix();
                // 任务结束时间在例外日期之间
                if (endUnix <= exceptDateEnd && endUnix >= exceptDateStart) {
                    /** @type {?} */
                    const nextDate = moment.unix(exceptDateEnd).clone().add(1, 'days').toDate();
                    correctDate = nextDate;
                }
            }));
        }
        getEndDateFromWeekDay(endDate);
        endDate = correctDate;
        // if (!startDate) {
        //     if (duration && duration > 0) {
        //         // 没s，有d
        //         this._startDate = moment(endDate).clone().subtract(duration - 1, 'days').toDate();
        //     } else {
        //         // 没s，没d
        //         this._startDate = endDate;
        //     }
        // } else {
        //     if (moment(endDate).isBefore(moment(startDate))) {
        //         this._startDate = moment(endDate).subtract(duration - 1, 'days').toDate();
        //     }
        // }
        return endDate;
    }
    /**
     * @param {?} duration
     * @return {?}
     */
    handleDuration(duration) {
        if (this._startDate && this._endDate) {
            if (duration) {
                /** @type {?} */
                const endDate = moment(this._startDate).add(duration - 1, 'days').toDate();
                // const endUnix = moment(endDate).unix();
                // const startUnix = moment(this._startDate).unix();
                // if (this.exceptDate && this.exceptDate.length > 0) {
                //     this.exceptDate.forEach((item) => {
                //         if (endUnix <= item.endDate && endUnix >= item.startDate) {
                //             // 结束时间在额外日期之间
                //             const errorDate = moment(endDate).format('MM/DD');
                //             const correct = moment.unix(item.endDate).clone().add(1, 'days');
                //             // GanttModel.message.confirm('warning', `所选日期${errorDate}为非工作日，将移动该任务结束时间到下一工作日${correct.format('MM/DD')}。`, 10000);
                //             this._exceptDuration = moment.unix(item.endDate).clone().diff(moment.unix(item.startDate), 'days') + 1;
                //             this._endDate = correct;
                //         } else {
                //             this._endDate = endDate;
                //         }
                //         // else if (startUnix <= item.startDate && endUnix >= item.endDate){
                //         //   // 如果任务中间有额外日期
                //         //   let exceptDuration = moment.unix(item.endDate).clone().diff(moment.unix(item.startDate), 'days') + 1;
                //         //   this._exceptDuration = exceptDuration;
                //         //   this._endDate = moment(this._startDate).add(duration + exceptDuration, 'days');
                //         // }
                //     });
                // } else {
                //     this._endDate = endDate;
                // }
                this.endDate = endDate;
            }
            else if (duration === 0) {
                this.endDate = this._startDate;
            }
        }
        return duration;
    }
    /**
     * @param {?} startDate
     * @return {?}
     */
    handleActualStartDate(startDate) {
        /** @type {?} */
        const unix = startDate ? moment(startDate).unix() : null;
        /** @type {?} */
        const actualEndDate = this._actualEndDate;
        /** @type {?} */
        const duration = this._actualDuration;
        if (this.exceptDate && this.exceptDate.length > 0) {
            this.exceptDate.forEach((/**
             * @param {?} item
             * @return {?}
             */
            (item) => {
                if (unix <= item.endDate && unix >= item.startDate) {
                    // 如果所选s在额外日期之间，d不变，e=s+d
                    /** @type {?} */
                    const errorDate = moment(startDate).format('MM/DD');
                    /** @type {?} */
                    const correct = moment.unix(item.endDate).clone().add(1, 'days').toDate();
                    // GanttModel.message.confirm('warning', `任务${this.id}的计划开始时间${errorDate}为非工作日，将移动该任务开始时间到下一工作日${correct.format('MM/DD')}。`, 10000);
                    startDate = correct;
                }
            }));
        }
        if (!actualEndDate) {
            if (duration && duration > 0) {
                // 没有endDate,有duration
                this.actualEndDate = moment(startDate).add(duration - 1, 'days').toDate();
            }
            else {
                // 没有duration
                this._actualEndDate = startDate;
            }
        }
        else {
            this.actualEndDate = moment(startDate).add(duration - 1, 'days').toDate();
        }
        return startDate;
    }
    /**
     * @param {?} endDate
     * @return {?}
     */
    handleActualEndDate(endDate) {
        /** @type {?} */
        const unix = endDate ? moment(endDate).unix() : null;
        /** @type {?} */
        const startDate = this._actualStartDate;
        /** @type {?} */
        const duration = this._actualDuration;
        /** @type {?} */
        const startUnix = moment(this._actualStartDate).unix();
        if (this.exceptDate && this.exceptDate.length > 0) {
            // 有额外日期
            this.exceptDate.forEach((/**
             * @param {?} item
             * @return {?}
             */
            (item) => {
                if (unix <= item.endDate && unix >= item.startDate) {
                    // 所选endDate在额外日期之间，e自动延至额外日期结束后一天，s不变，d=e-s
                    /** @type {?} */
                    const errorDate = moment(endDate).format('MM/DD');
                    /** @type {?} */
                    const correct = moment.unix(item.endDate).clone().add(1, 'days').toDate();
                    // GanttModel.message.confirm('warning', `任务${this.id}的计划结束时间${errorDate}为非工作日，将移动该任务结束时间到下一工作日${correct.format('MM/DD')}。`, 10000);
                    this._exceptDuration = moment.unix(item.endDate).clone().diff(moment.unix(item.startDate), 'days') + 1;
                    endDate = correct;
                }
            }));
        }
        if (!startDate) {
            if (duration && duration > 0) {
                // 没s，有d
                this._actualStartDate = moment(endDate).clone().subtract(duration - 1, 'days').toDate();
            }
            else {
                // 没s，没d
                this._actualStartDate = endDate;
            }
        }
        else {
            if (moment(endDate).isBefore(moment(startDate))) {
                this._actualStartDate = moment(endDate).subtract(duration - 1, 'days').toDate();
            }
            else {
                this._actualDuration = moment(endDate).clone().diff(moment(startDate), 'days') + 1;
            }
        }
        return endDate;
    }
    /**
     * @param {?} duration
     * @return {?}
     */
    handleActualDuration(duration) {
        if (this._actualStartDate && this._actualEndDate) {
            if (duration) {
                /** @type {?} */
                const endDate = moment(this._actualStartDate).add(duration - 1, 'days').toDate();
                this._actualEndDate = endDate;
            }
            else if (duration === 0) {
                this._actualEndDate = this._actualStartDate;
            }
        }
        return duration;
    }
}
if (false) {
    /**
     * 公用参数
     * @type {?}
     */
    XmppTask.prototype.extendedAttribute;
    /** @type {?} */
    XmppTask.prototype.customExtendAttr;
    /** @type {?} */
    XmppTask.prototype.id;
    /** @type {?} */
    XmppTask.prototype.symbol;
    /** @type {?} */
    XmppTask.prototype.sqId;
    /** @type {?} */
    XmppTask.prototype.uid;
    /** @type {?} */
    XmppTask.prototype.wbs;
    /** @type {?} */
    XmppTask.prototype.taskName;
    /** @type {?} */
    XmppTask.prototype.isSelected;
    /** @type {?} */
    XmppTask.prototype.step;
    /** @type {?} */
    XmppTask.prototype.childTaskID;
    /** @type {?} */
    XmppTask.prototype.parentTaskID;
    /** @type {?} */
    XmppTask.prototype.level;
    /** @type {?} */
    XmppTask.prototype.isFold;
    /** @type {?} */
    XmppTask.prototype.ganttChartId;
    /** @type {?} */
    XmppTask.prototype.defaultData;
    /** @type {?} */
    XmppTask.prototype.bindings;
    /** @type {?} */
    XmppTask.prototype.allFinished;
    /** @type {?} */
    XmppTask.prototype.isMilepost;
    /** @type {?} */
    XmppTask.prototype.prevRelation;
    /**
     * @type {?}
     * @private
     */
    XmppTask.prototype._exceptDuration;
    /**
     * @type {?}
     * @private
     */
    XmppTask.prototype._exceptActualDuration;
    /**
     * @type {?}
     * @private
     */
    XmppTask.prototype._finishRate;
    /**
     * 计划参数
     * @type {?}
     */
    XmppTask.prototype.truePrevTaskID;
    /** @type {?} */
    XmppTask.prototype.isKey;
    /** @type {?} */
    XmppTask.prototype.laterChildId;
    /** @type {?} */
    XmppTask.prototype.earlierChildId;
    /**
     * @type {?}
     * @private
     */
    XmppTask.prototype._startDate;
    /**
     * @type {?}
     * @private
     */
    XmppTask.prototype._duration;
    /**
     * @type {?}
     * @private
     */
    XmppTask.prototype._endDate;
    /**
     * @type {?}
     * @private
     */
    XmppTask.prototype._showDuration;
    /** @type {?} */
    XmppTask.prototype.showActualDuration;
    /**
     * 实际参数
     * @type {?}
     */
    XmppTask.prototype.actulaTruePrevTaskID;
    /** @type {?} */
    XmppTask.prototype.isActualKey;
    /** @type {?} */
    XmppTask.prototype.acLaterChildId;
    /** @type {?} */
    XmppTask.prototype.acEarlierChildId;
    /**
     * @type {?}
     * @private
     */
    XmppTask.prototype._actualStartDate;
    /**
     * @type {?}
     * @private
     */
    XmppTask.prototype._actualDuration;
    /**
     * @type {?}
     * @private
     */
    XmppTask.prototype._actualEndDate;
    /** @type {?} */
    XmppTask.prototype.tags;
    /** @type {?} */
    XmppTask.prototype.CustomAttrs;
    /** @type {?} */
    XmppTask.prototype.Xmpp;
    /** @type {?} */
    XmppTask.prototype.resources;
    /** @type {?} */
    XmppTask.prototype.firstSet;
    /* Skipping unhandled member: [key: string]: any;*/
}
class XmppPredecessorLink {
    /**
     * @param {?} param
     */
    constructor(param) {
        this.delay = 0;
        this.isDelete = 0;
        (param.id) && (this.id = param.id);
        (param.prevId) && (this.prevId = param.prevId);
        (!isNullOrUndefined(param.relation)) && (this.relation = param.relation);
        (param.delay) && (this.delay = param.delay);
        (param.predecessorLink) && (this.predecessorLink = param.predecessorLink);
        (param.defaultPerv) && (this.defaultPerv = param.defaultPerv);
        (param.isDelete) && (this.isDelete = param.isDelete);
        (param.parentId) && (this.parentId = param.parentId);
    }
}
if (false) {
    /** @type {?} */
    XmppPredecessorLink.prototype.id;
    /** @type {?} */
    XmppPredecessorLink.prototype.prevId;
    /** @type {?} */
    XmppPredecessorLink.prototype.relation;
    /** @type {?} */
    XmppPredecessorLink.prototype.delay;
    /** @type {?} */
    XmppPredecessorLink.prototype.predecessorLink;
    /** @type {?} */
    XmppPredecessorLink.prototype.defaultPerv;
    /** @type {?} */
    XmppPredecessorLink.prototype.isDelete;
    /** @type {?} */
    XmppPredecessorLink.prototype.parentId;
}

/**
 * @fileoverview added by tsickle
 * Generated from: lib/src/lib/gantt.config.ts
 * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
/** @type {?} */
const PREVTYPE = {
    FF: 0,
    FS: 1,
    SF: 2,
    SS: 3
};
/** @type {?} */
const EXTENDATTRS = {
    binding: {
        FieldID: '188744016',
        FieldName: 'ARCHGL_BINDING_COMPONENTS'
    },
    extraParam: {
        FieldID: '188744017',
        FieldName: 'ARCHGL_EXTRA_PARAM'
    }
};

/**
 * @fileoverview added by tsickle
 * Generated from: lib/src/lib/gantt.method.ts
 * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
class GanttMethod {
}
GanttMethod.mpp = {
    /**
     * @param {?} Gantt
     * @param {?} ganttInfo
     * @return {?}
     */
    dealWithProject(Gantt, ganttInfo) {
        Gantt.mpp.mppInfo = ganttInfo;
        // 处理例外日期
        Gantt.calendar.exceptDate = [];
        for (const calendar of ganttInfo.calendars) {
            if (calendar.exceptions.length > 0) {
                for (const except of calendar.exceptions) {
                    Gantt.calendar.exceptDate.push({
                        name: except.name,
                        fromDate: moment(except.fromDate).format('YYYY-MM-DD'),
                        toDate: moment(except.toDate).format('YYYY-MM-DD'),
                        id: except.id,
                        parentId: except.parentId
                    });
                }
            }
        }
        // 处理工作周， 每周休假的日期：周日：1，周一：2
        // const pauseWeekDayTypes = [];
        /** @type {?} */
        let weekDays = [];
        /** @type {?} */
        let dayType = ganttInfo.weekStartDay + 1;
        if (ganttInfo.calendars.length > 0) {
            for (const calendar of ganttInfo.calendars) {
                // 查找standard
                if (calendar.weekDays.length > 0 && calendar.uid === 1) {
                    // weekDays = calendar.weekDays;
                    Gantt.calendar.calendarId = calendar.id;
                    for (let i = 0; i < 7; i++) {
                        /** @type {?} */
                        let fidner = calendar.weekDays.find((/**
                         * @param {?} wd
                         * @return {?}
                         */
                        wd => wd.dayType == dayType));
                        weekDays.push({
                            dayType: fidner.dayType,
                            dayText: XmppWeekDayType[fidner.dayType],
                            dayWorking: fidner.dayWorking,
                            id: fidner.id,
                            fromDate: fidner.fromDate,
                            toDate: fidner.toDate
                        });
                        if (dayType == 7) {
                            dayType = 1;
                        }
                        else {
                            dayType++;
                        }
                    }
                }
            }
        }
        // Gantt.calendar.pauseWeekDayTypes = pauseWeekDayTypes;
        Gantt.calendar.weekDays = weekDays;
    },
    /**
     * @param {?} Gantt
     * @param {?} mppTasks
     * @return {?}
     */
    dealWithMPPTasks(Gantt, mppTasks) {
        /** @type {?} */
        const allTasks = [];
        /** @type {?} */
        const maxUID = 0;
        /** @type {?} */
        const assignments = Gantt.mpp.mppInfo.assignments;
        /** @type {?} */
        const resources = Gantt.mpp.mppInfo.resources;
        /** @type {?} */
        const resourcesMap = new Map();
        resources.forEach((/**
         * @param {?} rs
         * @return {?}
         */
        rs => {
            if (rs.name) {
                resourcesMap.set(rs.uid, rs.name);
            }
        }));
        /** @type {?} */
        const findCustomExtendAttr = (/**
         * @param {?} ExtendedAttribute
         * @return {?}
         */
        (ExtendedAttribute) => {
            /** @type {?} */
            const finder = ExtendedAttribute.find((/**
             * @param {?} attr
             * @return {?}
             */
            (attr) => {
                return attr.fieldID === EXTENDATTRS.binding.FieldID;
            }));
            if (finder) {
                return finder;
            }
            else {
                return null;
            }
        });
        /** @type {?} */
        const findAssignments = (/**
         * @param {?} uid
         * @return {?}
         */
        (uid) => {
            /** @type {?} */
            const taskResources = [];
            for (const ag of assignments) {
                if (ag.taskUID === uid) {
                    /** @type {?} */
                    const resource = resourcesMap.get(ag.resourceUID);
                    if (resource) {
                        /** @type {?} */
                        const find = taskResources.find((/**
                         * @param {?} taskRs
                         * @return {?}
                         */
                        taskRs => {
                            return taskRs === resource;
                        }));
                        if (!find) {
                            taskResources.push(resource);
                        }
                    }
                }
            }
            return taskResources;
            // return assignments.find(ag => {
            //     return ag.taskUID == uid;
            // })
        });
        mppTasks.forEach((/**
         * @param {?} element
         * @param {?} index
         * @return {?}
         */
        (element, index) => {
            if (element._ID) {
                /** @type {?} */
                const symbol = index + 1000;
                /** @type {?} */
                let customAttrs = {};
                if (element.customAttrs) {
                    customAttrs = JSON.parse(element.customAttrs);
                }
                /** @type {?} */
                const defaultData = {
                    Xmpp: Gantt,
                    sqId: element.id,
                    // exceptDate: Gantt.calendar.exceptDate ? Gantt.calendar.exceptDate : [],
                    uid: element.uid,
                    id: element._ID,
                    symbol,
                    wbs: element.wbs,
                    taskName: element.name,
                    duration: GanttMethod.mpp.PT2Duration(element.duration),
                    startDate: element.start ? GanttMethod.date.dateDeepClone(element.start) : null,
                    endDate: element.finish ? GanttMethod.date.dateDeepClone(element.finish) : null,
                    actualStartDate: element.actualStart ? GanttMethod.date.dateDeepClone(element.actualStart) : null,
                    actualDuration: 0,
                    actualEndDate: element.actualFinish ? GanttMethod.date.dateDeepClone(element.actualFinish) : null,
                    childTaskID: GanttMethod.mpp.WBS2ParentId(element, mppTasks).childId,
                    parentTaskID: GanttMethod.mpp.WBS2ParentId(element, mppTasks).parentId,
                    level: GanttMethod.mpp.WBS2ParentId(element, mppTasks).level,
                    isMilepost: element.milestone,
                    prevRelation: GanttMethod.predecessorLink.dealWithPrev(element, mppTasks),
                    extendedAttribute: element.extendedAttribute,
                    customExtendAttr: findCustomExtendAttr(element.extendedAttribute),
                    ganttChartId: element.parentId,
                    tags: customAttrs.tags,
                    resources: findAssignments(element.uid)
                };
                /** @type {?} */
                const task = new XmppTask(defaultData);
                // if (bindings && bindings.length > 0) {
                //     let extendAttrs = Gantt.mpp.extraAttrMap.get(symbol);
                //     if (extendAttrs) {
                //         extendAttrs.bindings = bindings;
                //         Gantt.mpp.extraAttrMap.set(symbol, extendAttrs);
                //     } else {
                //         Gantt.mpp.extraAttrMap.set(symbol, {bindings});
                //     }
                // }
                allTasks.push(task);
            }
            if (element.uid > maxUID) {
                Gantt.task.maxUID = element.uid;
            }
        }));
        return allTasks;
    },
    /**
     * @param {?} str
     * @return {?}
     */
    PT2Duration(str) {
        if (!str) {
            return 0;
        }
        /** @type {?} */
        const number = str.match(/PT(\S*)H/)[1];
        if (isNaN(number)) {
            return 0;
        }
        else {
            return Number(number) / 8;
        }
    },
    /**
     * @param {?} task
     * @param {?} allTasks
     * @return {?}
     */
    WBS2ParentId(task, allTasks) {
        /** @type {?} */
        let level = 1;
        /** @type {?} */
        const findParentId = (/**
         * @param {?} ptask
         * @return {?}
         */
        (ptask) => {
            if (ptask.wbs) {
                /** @type {?} */
                const array = ptask.wbs.split('.');
                level = array.length;
                if (array.length === 1) {
                    return null;
                }
                array.pop();
                /** @type {?} */
                const newStr = array.join('.');
                /** @type {?} */
                const finder = allTasks.find((/**
                 * @param {?} element
                 * @return {?}
                 */
                (element) => {
                    return element.wbs === newStr;
                }));
                if (finder) {
                    return finder._ID;
                }
                else {
                    return null;
                }
            }
            return null;
        });
        /** @type {?} */
        const childId = [];
        /** @type {?} */
        const findChildId = (/**
         * @param {?} ctask
         * @return {?}
         */
        (ctask) => {
            for (let i = parseInt(ctask._ID.toString(), 0); i < allTasks.length; i++) {
                /** @type {?} */
                const element = allTasks[i];
                if (element.wbs) {
                    /** @type {?} */
                    const array = element.wbs.split('.');
                    array.pop();
                    /** @type {?} */
                    const newStr = array.join('.');
                    if (newStr === ctask.wbs) {
                        childId.push(element._ID);
                    }
                }
            }
        });
        findChildId(task);
        return {
            parentId: findParentId(task),
            childId,
            level
        };
    },
    /**
     * @param {?} Gantt
     * @return {?}
     */
    ParentId2WBS(Gantt) {
        /** @type {?} */
        const loopChild = (/**
         * @param {?} allTasks
         * @param {?} level
         * @return {?}
         */
        (allTasks, level) => {
            /** @type {?} */
            let index = 1;
            for (const element of allTasks) {
                if (element.level === level) {
                    /** @type {?} */
                    const array = new Array();
                    /** @type {?} */
                    const parentTaskWBS = element.parentTaskID ? Gantt.allTasks[element.parentTaskID - 1].wbs : [];
                    parentTaskWBS.forEach((/**
                     * @param {?} wbs
                     * @return {?}
                     */
                    (wbs) => {
                        array.push(wbs);
                    }));
                    array.push(index.toString());
                    element.wbs = array;
                    index++;
                    if (element.childTaskID.length > 0) {
                        /** @type {?} */
                        const childTask = [];
                        element.childTaskID.forEach((/**
                         * @param {?} chidId
                         * @return {?}
                         */
                        (chidId) => {
                            childTask.push(Gantt.allTasks[chidId - 1]);
                        }));
                        loopChild(childTask, level + 1);
                    }
                }
            }
        });
        loopChild(Gantt.allTasks, 1);
        Gantt.allTasks.forEach((/**
         * @param {?} ele
         * @return {?}
         */
        (ele) => {
            if (isArray(ele.wbs)) {
                ele.wbs = ele.wbs.join('.');
            }
        }));
    }
};
GanttMethod.canvas = {
    /**
     * @param {?} Gantt
     * @return {?}
     */
    updateCanvasInfo(Gantt) {
        if (Gantt.allTasks.length === 0) {
            return;
        }
        /** @type {?} */
        const allTasks = Gantt.allTasks;
        /** @type {?} */
        const calenderArry = [];
        /** @type {?} */
        let lastFinishTask = 0;
        /** @type {?} */
        let lastActualFinishTask = 0;
        /** @type {?} */
        let lastFinishDay = allTasks[0].endDate;
        /** @type {?} */
        let lastActualFinishDay = allTasks[0].actualEndDate;
        /** @type {?} */
        const baseWidth = Gantt.calendar.baseCellWidth;
        for (const task of allTasks) {
            /** @type {?} */
            const endDate = task.endDate;
            /** @type {?} */
            const startDate = task.startDate;
            /** @type {?} */
            const actualEndDate = task.actualEndDate;
            /** @type {?} */
            const actualStartDate = task.actualStartDate;
            if (endDate && startDate) {
                calenderArry.push(moment(task.startDate));
                calenderArry.push(moment(task.endDate));
                if (moment(endDate).clone().diff(moment(lastFinishDay), 'days') >= 0) {
                    // 找到日期最后一天对应的任务id
                    lastFinishTask = task.id;
                    lastFinishDay = task.endDate;
                }
            }
            if (actualEndDate && actualStartDate) {
                calenderArry.push(moment(task.actualStartDate));
                calenderArry.push(moment(task.actualEndDate));
                if (!lastActualFinishDay) {
                    lastActualFinishTask = task.id;
                    lastActualFinishDay = actualEndDate;
                }
                else {
                    if (moment(actualEndDate).clone().diff(moment(lastActualFinishDay), 'days') >= 0) {
                        // 找到日期最后一天对应的任务id
                        lastActualFinishTask = task.id;
                        lastActualFinishDay = task.actualEndDate;
                    }
                }
            }
        }
        // showTask最早开始/最晚结束日期
        /** @type {?} */
        const minDay = moment.min(calenderArry);
        /** @type {?} */
        const maxDay = moment.max(calenderArry);
        // 项目日历设置：自然周从周几开始 0：周日，1：周一
        // const weekStartDay = Gantt.mpp.mppInfo.weekStartDay;
        /** @type {?} */
        const weekStartDay = Number(Gantt.calendar.weekDays[0].dayType) - 1;
        // 最早/最晚日期对应的周几
        /** @type {?} */
        const minWeekDay = new Date(minDay.unix() * 1000).getDay();
        /** @type {?} */
        const maxWeekDay = new Date(maxDay.unix() * 1000).getDay();
        // 日历开始/结束日期
        /** @type {?} */
        const oneDayLong = 24 * 60 * 60;
        /** @type {?} */
        let minDayDiffer = minWeekDay - weekStartDay;
        if (minDayDiffer < 0) {
            minDayDiffer = 7 + minDayDiffer;
        }
        /** @type {?} */
        let maxDayDiffer = maxWeekDay - weekStartDay;
        if (maxDayDiffer < 0) {
            maxDayDiffer = 7 + maxDayDiffer;
        }
        /** @type {?} */
        const minLineDay = moment.unix(minDay.unix() - minDayDiffer * oneDayLong);
        /** @type {?} */
        const maxLineDay = moment.unix(maxDay.unix() - maxDayDiffer * oneDayLong);
        // 计算每周开始那天 数组
        /** @type {?} */
        const weekCount = Math.ceil(maxLineDay.clone().diff(minLineDay.clone(), 'days') / 7) + 1;
        /** @type {?} */
        const weeksArry = [];
        /** @type {?} */
        const weekExceptDays = [];
        /** @type {?} */
        const pauseWeekDays = [];
        /** @type {?} */
        const pauseWeekDayTypes = [];
        Gantt.calendar.weekDays.forEach((/**
         * @param {?} wd
         * @return {?}
         */
        wd => {
            if (!wd.dayWorking) {
                pauseWeekDayTypes.push(wd.dayType);
            }
        }));
        Gantt.calendar.pauseWeekDayTypes = pauseWeekDayTypes;
        for (let i = 0; i < weekCount; i++) {
            /** @type {?} */
            const preWeekStartDay = minLineDay.clone().day(7 * i + weekStartDay);
            /** @type {?} */
            const preWeekStartDayFormat = preWeekStartDay.format('YYYY-MM-DD');
            weeksArry.push(preWeekStartDayFormat);
            for (let i = 0; i < 7; i++) {
                /** @type {?} */
                const day = moment.unix(preWeekStartDay.unix() + i * oneDayLong);
                // 当前日期是周几
                /** @type {?} */
                const dayWeekType = new Date(day.unix() * 1000).getDay();
                if (Gantt.calendar.pauseWeekDayTypes.indexOf(dayWeekType + 1) !== -1) {
                    pauseWeekDays.push(day.format('YYYY-MM-DD'));
                }
            }
        }
        Gantt.calendar.pauseWeekDays = pauseWeekDays;
        if (calenderArry.length === 0) {
            Gantt.calendar.calenderWidth = 0;
        }
        else {
            Gantt.calendar.weeksArry = weeksArry;
            Gantt.calendar.calenderWidth = weeksArry.length * 7 * baseWidth;
        }
        // 计算canvasInfo
        if (lastFinishTask) {
            // 清空关键线路
            GanttMethod.tasks.cleanKeyLoop(allTasks);
            // 重新计算关键线路
            GanttMethod.tasks.findKeyLoop(Gantt, allTasks, lastFinishTask);
        }
        GanttMethod.canvas.positionCalculate(Gantt, minLineDay);
        // 计算 actualCanvasInfo
        if (lastActualFinishTask) {
            GanttMethod.tasks.cleanActualKeyLoop(allTasks);
            GanttMethod.tasks.findActualKeyLoop(allTasks, lastActualFinishTask);
        }
        GanttMethod.canvas.positionCalculate(Gantt, minLineDay, 'actual');
    },
    /**
     * @param {?} Gantt
     * @param {?} minLineDay
     * @param {?=} dateType
     * @return {?}
     */
    positionCalculate(Gantt, minLineDay, dateType) {
        // 默认画轴起点坐标（0，0）
        // let tasks = this.showTask;
        /** @type {?} */
        const tasks = Gantt.allTasks;
        /** @type {?} */
        const canvasInfo = [];
        /** @type {?} */
        const baseWidth = Gantt.calendar.baseCellWidth;
        /** @type {?} */
        let posYadd = (Gantt.task.taskHeight - Gantt.draw.lineHeight) / 2;
        // 计算
        for (let i = 0; i < tasks.length; i++) {
            /** @type {?} */
            let isActive = false;
            /** @type {?} */
            const isKey = tasks[i].isKey;
            /** @type {?} */
            let startDate = moment(tasks[i].startDate);
            /** @type {?} */
            let endDate = moment(tasks[i].endDate);
            /** @type {?} */
            let duration = tasks[i].duration;
            /** @type {?} */
            let color = isKey ? Gantt.draw.color.planKeyColor : Gantt.draw.color.planColor;
            /** @type {?} */
            let lineHeight = Gantt.draw.lineHeight;
            // 计算实际时间的canvas信息
            if (dateType === 'actual') {
                startDate = moment(tasks[i].actualStartDate);
                endDate = moment(tasks[i].actualEndDate);
                duration = tasks[i].actualDuration;
                posYadd = (Gantt.task.taskHeight - Gantt.draw.actualLineHeight) / 2;
                color = isKey ? Gantt.draw.color.ActualkeyColor : Gantt.draw.color.Actualcolor;
                lineHeight = Gantt.draw.actualLineHeight;
            }
            if (Gantt.task.activeTaskId && Gantt.task.activeTaskId === tasks[i].id) {
                isActive = true;
            }
            /** @type {?} */
            const childTaskID = tasks[i].childTaskID;
            /** @type {?} */
            const taskHeight = Gantt.task.taskHeight;
            /** @type {?} */
            const isMilepost = tasks[i].isMilepost;
            // 找出task[i]之前fold的task个数
            /** @type {?} */
            const foldBefore = [];
            Gantt.task.hideTasksIds.forEach((/**
             * @param {?} element
             * @return {?}
             */
            (element) => {
                if (element < i + 1) {
                    foldBefore.push(element);
                }
            }));
            // const pre = moment(startDate.format('YYYY-MM-DD'));
            // const minLineDayUnix = moment(minLineDay.format('YYYY-MM-DD'));
            /** @type {?} */
            const diff = startDate.clone().diff(minLineDay, 'days');
            // 里程碑width为0
            /** @type {?} */
            let positionX = diff * baseWidth;
            /** @type {?} */
            let width = (endDate.diff(startDate, 'days') + 1) * baseWidth;
            /** @type {?} */
            let type = 'normal';
            if (isMilepost && duration === 0) {
                width = 0;
                positionX = (diff + 1) * baseWidth;
                type = 'milepost';
            }
            if (childTaskID.length > 0) {
                type = 'parentType';
            }
            // 资源文本
            /** @type {?} */
            let resourceText = '';
            if (tasks[i].resources.length > 0) {
                resourceText = tasks[i].resources.join(',');
            }
            canvasInfo.push({
                // task起点x坐标
                positionX,
                // task起点y坐标
                positionY: taskHeight * i + posYadd - Gantt.task.startTaskIndex * taskHeight - foldBefore.length * taskHeight,
                // positionY: taskHeight * i + 10,
                // 根据工期算出来的task宽度
                width,
                // 横道图颜色
                color,
                arrowColor: isKey ? Gantt.draw.color.arrowKeyColor : Gantt.draw.color.arrowColor,
                // 是否是关键任务
                isKey,
                // 图形样式
                type,
                // 是否选中
                isActive,
                // 横道图高度
                lineHeight,
                resourceText
            });
        }
        if (dateType === 'actual') {
            Gantt.draw.actualCanvasInfo = canvasInfo;
        }
        else {
            // 例外日期区域
            /** @type {?} */
            const exceptDate = Gantt.calendar.exceptDate;
            /** @type {?} */
            const exceptCanvasInfo = [];
            exceptDate.forEach((/**
             * @param {?} element
             * @return {?}
             */
            (element) => {
                /** @type {?} */
                const positionX = (moment(element.fromDate).clone().diff(moment(minLineDay).clone(), 'days')) * baseWidth;
                /** @type {?} */
                const width = (moment(element.toDate).diff(moment(element.fromDate), 'days') + 1) * baseWidth;
                exceptCanvasInfo.push({
                    positionX,
                    width
                });
            }));
            /**
             * 工作周中休息的日期
             * @type {?}
             */
            const pauseWeekDays = Gantt.calendar.pauseWeekDays;
            pauseWeekDays.forEach((/**
             * @param {?} pwd
             * @return {?}
             */
            pwd => {
                /** @type {?} */
                let positionX = (moment(pwd).diff(moment(minLineDay).clone(), 'days')) * baseWidth;
                if (moment(minLineDay).format('YYYY-MM-DD') === pwd) {
                    positionX = 0;
                }
                /** @type {?} */
                const width = baseWidth;
                exceptCanvasInfo.push({
                    positionX,
                    width
                });
            }));
            Gantt.draw.exceptCanvasInfo = exceptCanvasInfo;
            Gantt.draw.canvasInfo = canvasInfo;
        }
    },
    /**
     * 绘制额外日期区域
     * @param {?} Gantt IXmpp
     * @param {?} ctx 画布
     * @return {?}
     */
    drawExceptArea(Gantt, ctx) {
        /** @type {?} */
        const exceptCanvasInfo = Gantt.draw.exceptCanvasInfo;
        for (const element of exceptCanvasInfo) {
            /** @type {?} */
            const fromX = element.positionX - Gantt.draw.canvasLeftHide;
            /** @type {?} */
            const width = element.width;
            ctx.beginPath();
            ctx.fillStyle = Gantt.draw.color.exceptDateColor;
            ctx.fillRect(fromX, 0, width, Gantt.draw.canvasHeight);
            ctx.fill();
            ctx.closePath();
        }
    },
    /**
     * 绘制任务举行
     * @param {?} Gantt
     * @param {?} ctx
     * @param {?=} isActual
     * @return {?}
     */
    drawTasks(Gantt, ctx, isActual) {
        /** @type {?} */
        const hideTasksId = Gantt.task.hideTasksIds;
        /** @type {?} */
        let canvasInfo = Gantt.draw.canvasInfo;
        if (isActual) {
            canvasInfo = Gantt.draw.actualCanvasInfo;
        }
        for (let i = 0; i < Gantt.task.showTask.length; i++) {
            /** @type {?} */
            const currentTask = Gantt.task.showTask[i];
            /** @type {?} */
            const index = currentTask.id - 1;
            if (!canvasInfo[index]) {
                continue;
            }
            /** @type {?} */
            const mileStoneText = moment(currentTask.endDate).format('DD/MM');
            /** @type {?} */
            const fromX = canvasInfo[index].positionX - Gantt.draw.canvasLeftHide;
            /** @type {?} */
            const fromY = canvasInfo[index].positionY;
            /** @type {?} */
            const width = canvasInfo[index].width;
            /** @type {?} */
            const isKey = canvasInfo[index].isKey;
            /** @type {?} */
            const type = canvasInfo[index].type;
            /** @type {?} */
            const color = canvasInfo[index].color;
            /** @type {?} */
            const arrowColor = canvasInfo[index].arrowColor;
            /** @type {?} */
            const lineHeight = canvasInfo[index].lineHeight;
            /** @type {?} */
            const isActive = canvasInfo[index].isActive;
            /** @type {?} */
            const resourceText = canvasInfo[index].resourceText;
            if (isNaN(fromX)) {
                continue;
            }
            ctx.beginPath();
            if (currentTask.truePrevTaskID && !isActual) {
                /** @type {?} */
                const relations = currentTask.prevRelation;
                /** @type {?} */
                const shortLine = 5;
                relations.forEach((/**
                 * @param {?} relation
                 * @return {?}
                 */
                (relation) => {
                    if (!relation.isDelete) {
                        /** @type {?} */
                        const number = relation.relation;
                        /** @type {?} */
                        const prevId = relation.prevId;
                        /** @type {?} */
                        const prevX = canvasInfo[prevId - 1].positionX - Gantt.draw.canvasLeftHide;
                        /** @type {?} */
                        const prevY = canvasInfo[prevId - 1].positionY;
                        /** @type {?} */
                        const prevWith = canvasInfo[prevId - 1].width;
                        /** @type {?} */
                        const conectColor = arrowColor;
                        /** @type {?} */
                        const helfLineHeight = lineHeight / 2;
                        if (hideTasksId.indexOf(prevId) === -1) {
                            if (number === PREVTYPE.FS) {
                                // 完成-开始(FS)
                                /** @type {?} */
                                const points = [
                                    { x: prevX + prevWith, y: prevY + helfLineHeight },
                                    { x: fromX + shortLine, y: prevY + helfLineHeight }
                                ];
                                GanttMethod.canvas.drawBrokenLine(ctx, points, 1, conectColor);
                                GanttMethod.canvas.drawArrow(ctx, fromX + shortLine, prevY + helfLineHeight, fromX + shortLine, fromY);
                                // GanttMethod.canvas.drawLineArrow(ctx, fromX + shortLine, prevY + helfLineHeight, fromX + shortLine, fromY - 4)
                            }
                            if (number === PREVTYPE.SS) {
                                // 开始-开始(SS)
                                /** @type {?} */
                                const points = [
                                    { x: prevX, y: prevY + helfLineHeight },
                                    { x: prevX - shortLine, y: prevY + helfLineHeight },
                                    { x: prevX - shortLine, y: fromY + helfLineHeight }
                                ];
                                GanttMethod.canvas.drawBrokenLine(ctx, points, 1, conectColor);
                                GanttMethod.canvas.drawArrow(ctx, prevX - shortLine, fromY + helfLineHeight, fromX, fromY + helfLineHeight);
                            }
                            if (number === PREVTYPE.FF) {
                                // 完成-完成(FF)
                                /** @type {?} */
                                const points = [
                                    { x: prevX + prevWith, y: prevY + helfLineHeight },
                                    { x: fromX + width + shortLine, y: prevY + helfLineHeight },
                                    { x: fromX + width + shortLine, y: fromY + helfLineHeight }
                                ];
                                GanttMethod.canvas.drawBrokenLine(ctx, points, 1, conectColor);
                                GanttMethod.canvas.drawArrow(ctx, fromX + width + shortLine, fromY + helfLineHeight, fromX + width, fromY + helfLineHeight);
                            }
                            if (number === PREVTYPE.SF) {
                                // 开始-完成(SF)
                                /** @type {?} */
                                const points = [
                                    { x: prevX, y: prevY + helfLineHeight },
                                    { x: prevX - shortLine, y: prevY + helfLineHeight },
                                    { x: prevX - shortLine, y: prevY + lineHeight + 5 },
                                    { x: fromX + width + shortLine, y: prevY + lineHeight + 5 },
                                    { x: fromX + width + shortLine, y: fromY + helfLineHeight }
                                ];
                                GanttMethod.canvas.drawBrokenLine(ctx, points, 1, conectColor);
                                GanttMethod.canvas.drawArrow(ctx, fromX + width + shortLine, fromY + helfLineHeight, fromX + width, fromY + helfLineHeight);
                            }
                        }
                    }
                }));
            }
            if (type === 'parentType') {
                if (!isActual) {
                    // 父任务
                    /** @type {?} */
                    const toX = fromX + width;
                    /** @type {?} */
                    const toY = fromY;
                    GanttMethod.canvas.drawSenior(ctx, fromX, fromY, toX, toY);
                }
            }
            else if (type === 'milepost') {
                // 里程碑
                GanttMethod.canvas.drawPolygon(ctx, {
                    x: fromX,
                    y: fromY + 5,
                    num: 4,
                    r: 6,
                    width: 1,
                    fillStyle: '#0e77ca'
                });
                GanttMethod.canvas.drawText(ctx, mileStoneText, fromX + 5, fromY + 5, 12);
            }
            else {
                // 普通任务
                ctx.fillStyle = color;
                ctx.fillRect(fromX, fromY, width, lineHeight);
                ctx.fill();
                if (!isActual) {
                    // tslint:disable-next-line:max-line-length
                    /** @type {?} */
                    const planfromX = Gantt.draw.canvasInfo[index].positionX - Gantt.draw.canvasLeftHide + Gantt.draw.canvasInfo[index].width + 5;
                    // tslint:disable-next-line:max-line-length
                    /** @type {?} */
                    const actualfromX = Gantt.draw.actualCanvasInfo[index].positionX - Gantt.draw.canvasLeftHide + Gantt.draw.actualCanvasInfo[index].width + 5;
                    /** @type {?} */
                    let textFromX = planfromX;
                    if (actualfromX > planfromX) {
                        textFromX = actualfromX;
                    }
                    GanttMethod.canvas.drawText(ctx, resourceText, textFromX, fromY + 5, 12, '#000000');
                }
            }
            ctx.closePath();
            // 选中任务
            // if (isActive) {
            //     const startY = fromY - (Gantt.task.taskHeight - lineHeight) / 2;
            //     const endY = fromY + Gantt.task.taskHeight - (Gantt.task.taskHeight - lineHeight) / 2;
            //     GanttMethod.canvas.drawLine(ctxMask, 0, startY + 1, canvasWidth, startY, 1, '#ccc');
            //     GanttMethod.canvas.drawLine(ctxMask, 0, endY - 1, canvasWidth, endY, 1, '#ccc');
            // }
            // 前置任务到自己的箭头
        }
    },
    /**
     * 在mask canvas上绘制选中任务的线
     * @param {?} Gantt
     * @param {?} taskId
     * @return {?}
     */
    drawSelectTask(Gantt, taskId) {
        Gantt.draw.selectedTaskId = taskId;
        /** @type {?} */
        const c = (/** @type {?} */ ((document.getElementById('maskCanvas'))));
        /** @type {?} */
        const ctxMask = c.getContext('2d');
        // ctxMask.clearRect(0, 0, Gantt.draw.canvasWidth, Gantt.draw.canvasHeight);
        /** @type {?} */
        const index = taskId - 1;
        if (index !== -1) {
            /** @type {?} */
            const canvasWidth = Gantt.draw.canvasWidth;
            /** @type {?} */
            const canvasInfo = Gantt.draw.canvasInfo;
            /** @type {?} */
            const fromY = canvasInfo[index].positionY;
            /** @type {?} */
            const lineHeight = canvasInfo[index].lineHeight;
            /** @type {?} */
            const startY = fromY - (Gantt.task.taskHeight - lineHeight) / 2;
            /** @type {?} */
            const endY = fromY + Gantt.task.taskHeight - (Gantt.task.taskHeight - lineHeight) / 2;
            GanttMethod.canvas.drawLine(ctxMask, 0, startY + 1, canvasWidth, startY, 1, '#ccc');
            GanttMethod.canvas.drawLine(ctxMask, 0, endY - 1, canvasWidth, endY, 1, '#ccc');
        }
    },
    /**
     * 绘制圆角矩形
     * @param {?} cxt 画布
     * @param {?} x 位置x
     * @param {?} y 位置y
     * @param {?} width 宽度
     * @param {?} height 高度
     * @param {?} radius 圆角
     * @return {?}
     */
    drawRoundRect(cxt, x, y, width, height, radius) {
        cxt.beginPath();
        cxt.arc(x + radius, y + radius, radius, Math.PI, Math.PI * 3 / 2);
        cxt.lineTo(width - radius + x, y);
        cxt.arc(width - radius + x, radius + y, radius, Math.PI * 3 / 2, Math.PI * 2);
        cxt.lineTo(width + x, height + y - radius);
        cxt.arc(width - radius + x, height - radius + y, radius, 0, Math.PI * 1 / 2);
        cxt.lineTo(radius + x, height + y);
        cxt.arc(radius + x, height - radius + y, radius, Math.PI * 1 / 2, Math.PI);
        cxt.closePath();
    },
    /**
     * 绘制文本
     * @param {?} ctx 画布
     * @param {?} text 文本内容
     * @param {?} x 位置x
     * @param {?} y 位置y
     * @param {?} fontSize 字体大小
     * @param {?=} fillStyle
     * @return {?}
     */
    drawText(ctx, text, x, y, fontSize, fillStyle) {
        ctx.beginPath();
        ctx.font = `normal normal bold ${fontSize}px arial`;
        ctx.textBaseline = 'middle';
        if (fillStyle) {
            ctx.fillStyle = fillStyle;
            ctx.fill();
        }
        ctx.fillText(text, x, y);
        ctx.closePath();
    },
    /**
     * 绘制里程碑
     * @param {?} ctx 画布
     * @param {?} conf 配置
     * @return {?}
     */
    drawPolygon(ctx, conf) {
        /** @type {?} */
        const x = conf && conf.x || 0;
        // 中心点x坐标
        /** @type {?} */
        const y = conf && conf.y || 0;
        // 中心点y坐标
        /** @type {?} */
        const num = conf && conf.num || 3;
        // 图形边的个数
        /** @type {?} */
        const r = conf && conf.r || 6;
        // 图形的半径
        /** @type {?} */
        const width = conf && conf.width || 1;
        /** @type {?} */
        const strokeStyle = conf && conf.strokeStyle;
        /** @type {?} */
        const fillStyle = conf && conf.fillStyle;
        // 开始路径
        ctx.beginPath();
        /** @type {?} */
        const startX = x + r * Math.cos(2 * Math.PI * 0 / num);
        /** @type {?} */
        const startY = y + r * Math.sin(2 * Math.PI * 0 / num);
        ctx.moveTo(startX, startY);
        for (let i = 1; i <= num; i++) {
            /** @type {?} */
            const newX = x + r * Math.cos(2 * Math.PI * i / num);
            /** @type {?} */
            const newY = y + r * Math.sin(2 * Math.PI * i / num);
            ctx.lineTo(newX, newY);
        }
        ctx.closePath();
        // 路径闭合
        if (strokeStyle) {
            ctx.strokeStyle = strokeStyle;
            ctx.lineWidth = width;
            ctx.lineJoin = 'round';
            ctx.stroke();
        }
        if (fillStyle) {
            ctx.fillStyle = fillStyle;
            ctx.fill();
        }
    },
    /**
     * 绘制父任务的括号
     * @param {?} ctx 画布
     * @param {?} fromX 开始x
     * @param {?} fromY 开始y
     * @param {?} toX 结束x
     * @param {?} toY 结束y
     * @return {?}
     */
    drawSenior(ctx, fromX, fromY, toX, toY) {
        /** @type {?} */
        const width = 2;
        /** @type {?} */
        const color = '#707070';
        GanttMethod.canvas.drawLine(ctx, fromX, fromY + 10, fromX, toY, width, color);
        GanttMethod.canvas.drawLine(ctx, fromX, fromY, toX, toY, width, color);
        GanttMethod.canvas.drawLine(ctx, toX, toY, toX, toY + 10, width, color);
    },
    /**
     * @param {?} ctx Canvas绘图环境
     * @param {?} fromX fromY：起点坐标（也可以换成p1，只不过它是一个数组）
     * @param {?} fromY
     * @param {?} toX toY：终点坐标 (也可以换成p2，只不过它是一个数组)
     * @param {?} toY
     * @param {?=} theta 三角斜边一直线夹角
     * @param {?=} headlen
     * @param {?=} width 箭头线宽度
     * @return {?}
     */
    drawArrow(ctx, fromX, fromY, toX, toY, theta, headlen, width) {
        theta = theta ? theta : 30;
        headlen = headlen ? headlen : 5;
        width = width ? width : 1;
        // 计算各角度和对应的p2,p3坐标
        /** @type {?} */
        const angle = Math.atan2(fromY - toY, fromX - toX) * 180 / Math.PI;
        /** @type {?} */
        const angle1 = (angle + theta) * Math.PI / 180;
        /** @type {?} */
        const angle2 = (angle - theta) * Math.PI / 180;
        /** @type {?} */
        const topX = headlen * Math.cos(angle1);
        /** @type {?} */
        const topY = headlen * Math.sin(angle1);
        /** @type {?} */
        const botX = headlen * Math.cos(angle2);
        /** @type {?} */
        const botY = headlen * Math.sin(angle2);
        ctx.save();
        ctx.beginPath();
        /** @type {?} */
        let arrowX = fromX - topX;
        /** @type {?} */
        let arrowY = fromY - topY;
        ctx.moveTo(arrowX, arrowY);
        ctx.moveTo(fromX, fromY);
        ctx.lineTo(toX, toY);
        arrowX = toX + topX;
        arrowY = toY + topY;
        ctx.moveTo(arrowX, arrowY);
        ctx.lineTo(toX, toY);
        arrowX = toX + botX;
        arrowY = toY + botY;
        ctx.lineTo(toX, toY);
        arrowX = toX + botX;
        arrowY = toY + botY;
        ctx.lineTo(arrowX, arrowY);
        ctx.lineWidth = width;
        ctx.stroke();
        ctx.closePath();
    },
    /**
     * @param {?} ctx
     * @param {?} x1
     * @param {?} y1
     * @param {?} x2
     * @param {?} y2
     * @return {?}
     */
    drawLineArrow(ctx, x1, y1, x2, y2) {
        /** @type {?} */
        var arrow = [
            [2, 0],
            [-8, -5],
            [-8, 5]
        ];
        /** @type {?} */
        let drawFilledPolygon = (/**
         * @param {?} shape
         * @return {?}
         */
        (shape) => {
            ctx.beginPath();
            ctx.moveTo(shape[0][0], shape[0][1]);
            for (var p in shape) {
                if (Number(p) > 0)
                    ctx.lineTo(shape[p][0], shape[p][1]);
            }
            ctx.lineTo(shape[0][0], shape[0][1]);
        });
        /** @type {?} */
        let translateShape = (/**
         * @param {?} shape
         * @param {?} x
         * @param {?} y
         * @return {?}
         */
        (shape, x, y) => {
            /** @type {?} */
            var rv = [];
            for (let p in shape)
                rv.push([shape[p][0] + x, shape[p][1] + y]);
            return rv;
        });
        /** @type {?} */
        let rotateShape = (/**
         * @param {?} shape
         * @param {?} ang
         * @return {?}
         */
        (shape, ang) => {
            /** @type {?} */
            var rv = [];
            for (let p in shape)
                rv.push(rotatePoint(ang, shape[p][0], shape[p][1]));
            return rv;
        });
        /** @type {?} */
        let rotatePoint = (/**
         * @param {?} ang
         * @param {?} x
         * @param {?} y
         * @return {?}
         */
        (ang, x, y) => {
            return [
                (x * Math.cos(ang)) - (y * Math.sin(ang)),
                (x * Math.sin(ang)) + (y * Math.cos(ang))
            ];
        });
        ctx.beginPath();
        ctx.moveTo(x1, y1);
        ctx.lineTo(x2, y2);
        ctx.stroke();
        /** @type {?} */
        var ang = Math.atan2(y2 - y1, x2 - x1);
        drawFilledPolygon(translateShape(rotateShape(arrow, ang), x2, y2));
    },
    /**
     * 绘制折线
     * @param {?} ctx 画布
     * @param {?} points 折线上的点数组
     * @param {?=} width 宽度
     * @param {?=} color 颜色
     * @return {?}
     */
    drawBrokenLine(ctx, points, width, color) {
        // 绘制直线
        ctx.beginPath();
        ctx.strokeStyle = color;
        // 设置线条的宽度
        ctx.lineWidth = width ? width : 1;
        // 起点
        ctx.moveTo(points[0].x, points[0].y);
        // 路径
        for (const point of points) {
            ctx.lineTo(point.x, point.y);
        }
        ctx.stroke();
    },
    /**
     * 绘制直线
     * @param {?} ctx 画布
     * @param {?} fromX 开始x
     * @param {?} fromY 开始y
     * @param {?} toX 结束x
     * @param {?} toY 结束y
     * @param {?} width 宽度
     * @param {?} color 颜色
     * @return {?}
     */
    drawLine(ctx, fromX, fromY, toX, toY, width, color) {
        color = typeof (color) !== 'undefined' ? color : '#000';
        ctx.save();
        ctx.beginPath();
        ctx.strokeStyle = color;
        ctx.lineWidth = width;
        ctx.moveTo(fromX - 0.5, fromY - 0.5);
        ctx.lineTo(toX - 0.5, toY - 0.5);
        ctx.stroke();
        ctx.restore();
    }
};
GanttMethod.tasks = {
    // 初始化关键线路isKey = false
    /**
     * @param {?} tasks
     * @return {?}
     */
    cleanKeyLoop(tasks) {
        for (const element of tasks) {
            element.isKey = false;
        }
    },
    /**
     * @param {?} tasks
     * @return {?}
     */
    cleanActualKeyLoop(tasks) {
        for (const element of tasks) {
            element.isActualKey = false;
        }
    },
    /**
     * @param {?} tasks
     * @param {?} key
     * @return {?}
     */
    findActualKeyLoop(tasks, key) {
        tasks[key - 1].isActualKey = true;
        /** @type {?} */
        const keyWork = tasks[key - 1].actulaTruePrevTaskID;
        if (keyWork) {
            GanttMethod.tasks.findActualKeyLoop(tasks, keyWork);
        }
        else {
            return;
        }
    },
    // 循环查找关键线路
    /**
     * @param {?} Gantt
     * @param {?} tasks
     * @param {?} key
     * @return {?}
     */
    findKeyLoop(Gantt, tasks, key) {
        tasks[key - 1].isKey = true;
        if (tasks[key - 1].childTaskID.length > 0) {
            /** @type {?} */
            const childTaskID = tasks[key - 1].childTaskID;
            /** @type {?} */
            const allTasks = Gantt.allTasks;
            childTaskID.forEach((/**
             * @param {?} id
             * @return {?}
             */
            (id) => {
                if (allTasks[id - 1].endDate === tasks[key - 1].endDate) {
                    allTasks[id - 1].isKey = true;
                }
            }));
        }
        /** @type {?} */
        const keyWork = tasks[key - 1].truePrevTaskID;
        if (keyWork) {
            GanttMethod.tasks.findKeyLoop(Gantt, tasks, keyWork);
        }
        else {
            return;
        }
    },
    /**
     * @param {?} Gantt
     * @return {?}
     */
    updateTaskHandle(Gantt) {
        /** @type {?} */
        const startIndex = Gantt.task.startTaskIndex;
        /** @type {?} */
        const endIndex = Gantt.task.startTaskIndex + Gantt.task.showTaskLength;
        if (Gantt.allTasks && Gantt.allTasks.length > 0) {
            /** @type {?} */
            const allTasks = GanttMethod.tasks.getAllTaskAfterFold(Gantt);
            Gantt.task.showTask = allTasks.slice(startIndex, endIndex);
        }
        else {
            Gantt.task.showTask = [];
        }
    },
    /**
     * @param {?} Gantt
     * @return {?}
     */
    getAllTaskAfterFold(Gantt) {
        /** @type {?} */
        const allTasks = Gantt.allTasks;
        /** @type {?} */
        const newAllTasks = [];
        /** @type {?} */
        const hideTasksId = [];
        allTasks.forEach((/**
         * @param {?} task
         * @param {?} index
         * @return {?}
         */
        (task, index) => {
            if (task.isFold) {
                for (let m = index + 1; m < allTasks.length; m++) {
                    /** @type {?} */
                    const element = allTasks[m];
                    if (element.level > allTasks[index].level) {
                        if (hideTasksId.indexOf(m + 1) === -1) {
                            hideTasksId.push(element.id);
                        }
                        else {
                            return;
                        }
                    }
                    else {
                        break;
                    }
                }
            }
        }));
        Gantt.task.hideTasksIds = hideTasksId;
        for (const element of allTasks) {
            if (hideTasksId.indexOf(element.id) === -1) {
                newAllTasks.push(element);
            }
        }
        return newAllTasks;
    },
    /*
            * 更新levelInfo
            * 根据level计算childTaskID和parentTaskID
            * major fuction
            */
    /**
     * @param {?} allTasks
     * @return {?}
     */
    updateLeveInfo(allTasks) {
        allTasks.forEach((/**
         * @param {?} element
         * @return {?}
         */
        (element) => {
            element.childTaskID = [];
            element.parentTaskID = null;
        }));
        // 计算所有任务的childTaskID和parentTaskID
        allTasks.forEach((/**
         * @param {?} task
         * @param {?} index
         * @return {?}
         */
        (task, index) => {
            /** @type {?} */
            const nextIndex = index + 1;
            GanttMethod.tasks.levelLoop(allTasks, task, nextIndex);
        }));
        // 降级后，子任务的前置任务变成了它的父任务，则移除该前置任务
        for (const element of allTasks) {
            /** @type {?} */
            const childrenId = element.childTaskID;
            childrenId.forEach((/**
             * @param {?} id
             * @return {?}
             */
            (id) => {
                if (!allTasks[id - 1]) {
                    console.log(id);
                }
                GanttMethod.tasks.removeParentID(allTasks, allTasks[id - 1], element.id);
            }));
        }
    },
    /**
     * @param {?} allTasks
     * @param {?} task
     * @param {?} nextIndex
     * @return {?}
     */
    levelLoop(allTasks, task, nextIndex) {
        /** @type {?} */
        const level = task.level;
        if (allTasks[nextIndex] && allTasks[nextIndex].level > level) {
            if (allTasks[nextIndex].level === level + 1) {
                task.childTaskID.push(allTasks[nextIndex].id);
                allTasks[nextIndex].parentTaskID = task.id;
            }
            nextIndex++;
            GanttMethod.tasks.levelLoop(allTasks, task, nextIndex);
        }
        else {
            return;
        }
    },
    /**
     * @param {?} allTasks
     * @param {?} children
     * @param {?} parentId
     * @return {?}
     */
    removeParentID(allTasks, children, parentId) {
        /** @type {?} */
        const childArray = children.prevRelation;
        if (childArray && childArray.length > 0) {
            /** @type {?} */
            const check = childArray.findIndex((/**
             * @param {?} relation
             * @return {?}
             */
            (relation) => {
                return relation.prevId === parentId;
            }));
            if (check !== -1) {
                childArray.splice(check, 1);
            }
            if (children.childTaskID.length !== 0) {
                for (const child of children.childTaskID) {
                    /** @type {?} */
                    const element = allTasks[child - 1];
                    GanttMethod.tasks.removeParentID(allTasks, element, parentId);
                }
            }
        }
        else {
            return;
        }
    },
    /**
     * @param {?} Gantt
     * @param {?} taskParam
     * @return {?}
     */
    addTaskHandle(Gantt, taskParam) {
        /** @type {?} */
        const allTasks = Gantt.allTasks;
        // const firstSelectTask = allTasks.find((task) => {
        //     return task.isSelected === true;
        // });
        if (taskParam && taskParam.isMilepost) {
            taskParam.taskName = '里程碑';
        }
        /** @type {?} */
        const activeTask = Gantt.task.activeTaskId ? allTasks[Gantt.task.activeTaskId - 1] : null;
        if (!activeTask) {
            /** @type {?} */
            const newTask = new XmppTask({
                Xmpp: Gantt,
                id: allTasks.length + 1,
                symbol: allTasks.length + 1000,
                ganttChartId: Gantt.mpp.mppInfo.id,
                taskName: taskParam && taskParam.taskName ? taskParam.taskName : '新建任务',
                isSelected: false,
                startDate: taskParam && taskParam.startDate ? taskParam.startDate : null,
                duration: 1,
                endDate: taskParam && taskParam.endDate ? taskParam.endDate : null,
                actualStartDate: null,
                actualDuration: 0,
                actualEndDate: null,
                childTaskID: [],
                parentTaskID: null,
                isMilepost: taskParam && taskParam.isMilepost ? taskParam.isMilepost : false,
                level: 1,
                bindings: [],
                prevRelation: [],
                finishRate: 0,
                exceptDate: Gantt.calendar.exceptDate ? Gantt.calendar.exceptDate : []
            });
            allTasks.push(newTask);
        }
        else {
            /** @type {?} */
            const firstSelectIndex = activeTask.id - 1;
            /** @type {?} */
            const newTask = new XmppTask({
                Xmpp: Gantt,
                id: firstSelectIndex + 1,
                symbol: allTasks.length + 1000,
                ganttChartId: Gantt.mpp.mppInfo.id,
                taskName: taskParam && taskParam.taskName ? taskParam.taskName : '新建任务',
                isSelected: false,
                startDate: taskParam && taskParam.startDate ? taskParam.startDate : null,
                duration: 1,
                endDate: taskParam && taskParam.endDate ? taskParam.endDate : null,
                actualStartDate: null,
                actualDuration: 0,
                actualEndDate: null,
                childTaskID: [],
                parentTaskID: null,
                isMilepost: taskParam && taskParam.isMilepost ? taskParam.isMilepost : false,
                level: activeTask.level,
                bindings: [],
                prevRelation: [],
                finishRate: 0,
                exceptDate: Gantt.calendar.exceptDate ? Gantt.calendar.exceptDate : []
            });
            allTasks.splice(firstSelectIndex, 0, newTask);
            for (const task of allTasks) {
                /** @type {?} */
                const relation = task.prevRelation;
                relation.forEach((/**
                 * @param {?} element
                 * @return {?}
                 */
                (element) => {
                    if (element.prevId > firstSelectIndex) {
                        element.prevId = element.prevId + 1;
                    }
                }));
            }
        }
        GanttMethod.tasks.loopAllTasksId(Gantt);
        // 涉及到两个数组
    },
    /**
     * @param {?} Gantt
     * @param {?} deleteTaskIds
     * @return {?}
     */
    deleteTaskHandle(Gantt, deleteTaskIds) {
        /** @type {?} */
        const allTasks = Gantt.allTasks;
        // const deleteTasks = [];
        // const search = (element) => {
        //     if (element.childTaskID && element.childTaskID.length > 0) {
        //         element.childTaskID.forEach((childID) => {
        //             if (deleteTasks.indexOf(childID) === -1) {
        //                 deleteTasks.push(childID);
        //             }
        //             search(allTasks[childID - 1]);
        //         });
        //     } else {
        //         return;
        //     }
        // };
        // // 拼装deleteTasks
        // for (const element of allTasks) {
        //     const id = element.id;
        //     if (element.isSelected) {
        //         deleteTasks.push(id);
        //         search(element);
        //         // allTasks.splice(id - 1, 1)
        //     }
        // }
        // // 将删除的task放在this.alreadyDeleteTasks中
        // for (const id of deleteTasks) {
        //     const finder = allTasks.find((task) => {
        //         return task.id === id;
        //     });
        //     if (finder.sqId) {
        //         this.alreadyDeleteTasks.push(finder.sqId);
        //     }
        // }
        // 将选中的tasks从allTasks移除
        for (let i = allTasks.length - 1; i >= 0; i--) {
            /** @type {?} */
            const id = allTasks[i].id;
            /** @type {?} */
            const findId = deleteTaskIds.find((/**
             * @param {?} task
             * @param {?} index
             * @return {?}
             */
            (task, index) => {
                return task === id;
            }));
            if (findId) {
                /** @type {?} */
                const task = allTasks[findId - 1];
                if (task.sqId) {
                    Gantt.task.deleteTasksSqlIdStore.push(task.sqId);
                }
                allTasks.splice(findId - 1, 1);
            }
        }
        // 循环删除任务的id数组
        for (const task of allTasks) {
            // 第一次循环，删除relation中已删除的任务对应的relation
            /** @type {?} */
            const prevRelation = task.prevRelation;
            prevRelation.forEach((/**
             * @param {?} relation
             * @param {?} index
             * @return {?}
             */
            (relation, index) => {
                if (deleteTaskIds.indexOf(relation.prevId) !== -1) {
                    prevRelation.splice(index, 1);
                }
            }));
            // 第二次循环,比删除任务id大的prevId-1
            for (const relation of prevRelation) {
                /** @type {?} */
                let prevId = relation.prevId;
                /** @type {?} */
                const smallprev = [];
                deleteTaskIds.forEach((/**
                 * @param {?} id
                 * @return {?}
                 */
                (id) => {
                    if (id < prevId) {
                        smallprev.push(id);
                    }
                }));
                if (smallprev.length > 0) {
                    prevId = prevId - smallprev.length;
                    relation.prevId = prevId;
                }
            }
        }
        GanttMethod.tasks.loopAllTasksId(Gantt);
    },
    /**
     * @param {?} Gantt
     * @param {?} selectTasks
     * @return {?}
     */
    depressTaskLevel(Gantt, selectTasks) {
        // const selectTasks = GanttMethod.tasks.checkSelectNumber(Gantt.allTasks);
        if (selectTasks && selectTasks.length > 0) {
            // 拼装depressTasksId
            /** @type {?} */
            const search = (/**
             * @param {?} element
             * @param {?} depressTasksId
             * @return {?}
             */
            (element, depressTasksId) => {
                if (element.childTaskID && element.childTaskID.length > 0) {
                    element.childTaskID.forEach((/**
                     * @param {?} childID
                     * @return {?}
                     */
                    (childID) => {
                        if (depressTasksId.indexOf(childID) === -1) {
                            depressTasksId.push(childID);
                        }
                        search(Gantt.allTasks[childID - 1], depressTasksId);
                    }));
                }
                else {
                    return;
                }
            });
            selectTasks.forEach((/**
             * @param {?} task
             * @return {?}
             */
            (task) => {
                // 任务leve + 1
                /** @type {?} */
                const depressTasksId = [];
                depressTasksId.push(task.id);
                search(task, depressTasksId);
                depressTasksId.forEach((/**
                 * @param {?} id
                 * @return {?}
                 */
                (id) => {
                    /** @type {?} */
                    const upperTask = Gantt.allTasks[id - 2];
                    if (Gantt.allTasks[id - 1].level > upperTask.level) {
                        return;
                    }
                    else {
                        Gantt.allTasks[id - 1].level = Gantt.allTasks[id - 1].level + 1;
                    }
                }));
            }));
            Gantt.render();
        }
    },
    /**
     * @param {?} Gantt
     * @param {?} selectTasks
     * @return {?}
     */
    promoteTaskLevel(Gantt, selectTasks) {
        // const selectTasks = GanttMethod.tasks.checkSelectNumber(Gantt.allTasks);
        if (selectTasks) {
            // 拼装promoteTasksId
            /** @type {?} */
            const search = (/**
             * @param {?} element
             * @param {?} promoteTasksId
             * @return {?}
             */
            (element, promoteTasksId) => {
                if (element.childTaskID && element.childTaskID.length > 0) {
                    element.childTaskID.forEach((/**
                     * @param {?} childID
                     * @return {?}
                     */
                    (childID) => {
                        if (promoteTasksId.indexOf(childID) === -1) {
                            promoteTasksId.push(childID);
                        }
                        search(Gantt.allTasks[childID - 1], promoteTasksId);
                    }));
                }
                else {
                    return;
                }
            });
            selectTasks.forEach((/**
             * @param {?} task
             * @return {?}
             */
            (task) => {
                /** @type {?} */
                const promoteTasksId = [];
                // 任务leve + 1
                promoteTasksId.push(task.id);
                search(task, promoteTasksId);
                promoteTasksId.forEach((/**
                 * @param {?} id
                 * @return {?}
                 */
                (id) => {
                    if (Gantt.allTasks[id - 1].level > 1) {
                        Gantt.allTasks[id - 1].level = Gantt.allTasks[id - 1].level - 1;
                    }
                }));
            }));
            Gantt.render();
        }
    },
    /**
     * @param {?} allTasks
     * @return {?}
     */
    checkSelectNumber(allTasks) {
        /** @type {?} */
        const selectNumber = [];
        allTasks.forEach((/**
         * @param {?} element
         * @return {?}
         */
        (element) => {
            if (element.isSelected) {
                selectNumber.push(element);
            }
        }));
        return selectNumber;
    },
    /**
     * @param {?} Gantt
     * @return {?}
     */
    loopAllTasksId(Gantt) {
        for (let i = 0; i < Gantt.allTasks.length; i++) {
            /** @type {?} */
            const element = Gantt.allTasks[i];
            element.id = i + 1;
        }
        Gantt.render();
    }
};
GanttMethod.predecessorLink = {
    /**
     * @param {?} allTasks
     * @param {?} ownPrevRelation
     * @param {?} currentTask
     * @return {?}
     */
    parentLoop(allTasks, ownPrevRelation, currentTask) {
        /** @type {?} */
        const parentIndex = currentTask.parentTaskID - 1;
        /** @type {?} */
        const parentPrev = allTasks[parentIndex].prevRelation;
        for (const prev of parentPrev) {
            if (ownPrevRelation.indexOf(prev) === -1) {
                ownPrevRelation.push(prev);
            }
        }
        if (allTasks[parentIndex].parentTaskID) {
            GanttMethod.predecessorLink.parentLoop(allTasks, ownPrevRelation, allTasks[parentIndex]);
        }
    },
    /**
     * @param {?} relation
     * @return {?}
     */
    filterDeleteRelation(relation) {
        /** @type {?} */
        const newArray = [];
        relation.forEach((/**
         * @param {?} element
         * @return {?}
         */
        (element) => {
            if (!element.isDelete) {
                newArray.push(element);
            }
        }));
        return newArray;
    },
    /**
     * @param {?} allTasks
     * @param {?} checkTask
     * @param {?} task
     * @param {?=} laterChildId
     * @param {?=} earlierChildId
     * @return {?}
     */
    loopParentMaxMin(allTasks, checkTask, task, laterChildId, earlierChildId) {
        if (task.childTaskID.length > 0) {
            if (!laterChildId) {
                laterChildId = task.childTaskID[0];
            }
            if (!earlierChildId) {
                earlierChildId = task.childTaskID[0];
            }
            task.childTaskID.forEach((/**
             * @param {?} id
             * @return {?}
             */
            (id) => {
                /** @type {?} */
                const child = allTasks[id - 1];
                /** @type {?} */
                const maxEndDate = allTasks[laterChildId - 1].endDate;
                /** @type {?} */
                const minStartDate = allTasks[earlierChildId - 1].startDate;
                if (child.childTaskID.length === 0) {
                    if (moment(child.endDate).isAfter(maxEndDate)) {
                        laterChildId = child.id;
                    }
                    if (moment(child.startDate).isBefore(minStartDate)) {
                        earlierChildId = child.id;
                    }
                    checkTask.laterChildId = laterChildId;
                    checkTask.earlierChildId = earlierChildId;
                }
                else {
                    GanttMethod.predecessorLink.loopParentMaxMin(allTasks, checkTask, child, laterChildId, earlierChildId);
                }
            }));
        }
    },
    /**
     * @param {?} task
     * @param {?} allTasks
     * @return {?}
     */
    dealWithPrev(task, allTasks) {
        /** @type {?} */
        const PredecessorLink = task.predecessorLink;
        /** @type {?} */
        const preTask = [];
        /** @type {?} */
        const finderId = (/**
         * @param {?} PredecessorUID
         * @return {?}
         */
        (PredecessorUID) => {
            /** @type {?} */
            const finder = allTasks.find((/**
             * @param {?} ele
             * @return {?}
             */
            (ele) => {
                return ele.uid === PredecessorUID;
            }));
            if (finder) {
                return finder._ID;
            }
        });
        if (PredecessorLink && PredecessorLink.length > 0) {
            PredecessorLink.forEach((/**
             * @param {?} element
             * @return {?}
             */
            (element) => {
                /** @type {?} */
                const prevTask = new XmppPredecessorLink({
                    prevId: finderId(element.predecessorUID),
                    relation: element.type,
                    delay: element.linkLag ? element.linkLag / 600 / 8 : 0,
                    id: element.id,
                    defaultPrev: element
                });
                preTask.push(prevTask);
            }));
        }
        return preTask;
    }
};
GanttMethod.date = {
    /**
     * @param {?} date
     * @return {?}
     */
    dateDeepClone(date) {
        return moment(moment(date).format('YYYY-MM-DD')).toDate();
    },
    /*
            *  根据前置任务计算allTasks的startDate
            */
    /**
     * @param {?} Gantt
     * @return {?}
     */
    updateStartDate(Gantt) {
        /** @type {?} */
        const allTasks = Gantt.allTasks;
        for (let i = 0; i < Gantt.allTasks.length; i++) {
            /** @type {?} */
            const relation = Gantt.allTasks[i].prevRelation;
            /** @type {?} */
            const task = allTasks[i];
            /** @type {?} */
            let ownPrevRelation = [];
            // 自己的前置任务relation
            relation.forEach((/**
             * @param {?} element
             * @return {?}
             */
            (element) => {
                ownPrevRelation.push(element);
            }));
            // 如果有父任务，加入父任务的relation
            if (task.parentTaskID) {
                GanttMethod.predecessorLink.parentLoop(Gantt.allTasks, ownPrevRelation, task);
            }
            // 计算最大的startDate
            /** @type {?} */
            let maxStartDate;
            // 筛选掉isDelete的relation
            ownPrevRelation = GanttMethod.predecessorLink.filterDeleteRelation(ownPrevRelation);
            if (ownPrevRelation.length > 0) {
                /** @type {?} */
                let truePrevTaskID;
                for (const relationInfo of ownPrevRelation) {
                    /** @type {?} */
                    const preTaskIndex = relationInfo.prevId - 1;
                    /** @type {?} */
                    const preTask = allTasks[preTaskIndex];
                    /** @type {?} */
                    const delay = relationInfo.delay;
                    /** @type {?} */
                    const duration = task.duration;
                    /** @type {?} */
                    let startDate;
                    /** @type {?} */
                    let prevType = 1;
                    if (!preTask) {
                        continue;
                    }
                    try {
                        if (preTask && preTask.childTaskID.length > 0) {
                            // 前置任务是摘要任务
                            GanttMethod.predecessorLink.loopParentMaxMin(Gantt.allTasks, preTask, preTask);
                            prevType = 2;
                            /** @type {?} */
                            const prevEndDate = allTasks[preTask.laterChildId - 1].endDate;
                            /** @type {?} */
                            const prevStartDate = allTasks[preTask.earlierChildId - 1].startDate;
                            switch (relationInfo.relation) {
                                // 完成-开始(FS)
                                case PREVTYPE.FS:
                                    startDate = prevEndDate ? moment(prevEndDate).clone().add(1, 'days').toDate() : null;
                                    break;
                                // 开始-开始(SS)
                                case PREVTYPE.SS:
                                    startDate = prevStartDate ? moment(prevStartDate).clone().add(1, 'days').toDate() : null;
                                    break;
                                // 完成-完成(FF)
                                case PREVTYPE.FF:
                                    startDate = prevEndDate ? moment(prevEndDate).clone().subtract(duration - 1, 'days').toDate() : null;
                                    break;
                                // 开始-完成(SF)
                                case PREVTYPE.SF:
                                    startDate = prevStartDate ? moment(prevStartDate).clone().subtract(duration - 1, 'days').toDate() : null;
                                    break;
                                default:
                                    return;
                            }
                        }
                        else {
                            prevType = 1;
                            switch (relationInfo.relation) {
                                // 完成-开始(FS)
                                case PREVTYPE.FS:
                                    if (task.isMilepost && task.duration === 0) {
                                        // 前置任务是里程碑,则startDate不加1
                                        startDate = preTask.endDate ? moment(preTask.endDate).clone().add(delay, 'days').toDate() : null;
                                    }
                                    else {
                                        // 前置任务是普通任务,则startDate加1
                                        startDate = preTask.endDate ? moment(preTask.endDate).clone().add(delay + 1, 'days').toDate() : null;
                                    }
                                    break;
                                // 开始-开始(SS)
                                case PREVTYPE.SS:
                                    startDate = preTask.startDate ? moment(preTask.startDate).clone().add(delay, 'days').toDate() : null;
                                    break;
                                // 完成-完成(FF)
                                case PREVTYPE.FF:
                                    startDate = preTask.endDate ?
                                        moment(preTask.endDate).clone().add(delay, 'days').subtract(duration - 1, 'days').toDate() : null;
                                    break;
                                // 开始-完成(SF)
                                case PREVTYPE.SF:
                                    startDate = preTask.startDate ?
                                        moment(preTask.startDate).clone().add(delay, 'days').subtract(duration - 1, 'days').toDate() : null;
                                    break;
                                default:
                                    return;
                            }
                        }
                        // 第一次maxStartDate为null, 默认为第一个计算的startDate
                        if (!maxStartDate) {
                            maxStartDate = startDate;
                            truePrevTaskID = prevType === 2 ? preTask.laterChildId : relationInfo.prevId;
                        }
                        else {
                            if (moment(startDate).isAfter(maxStartDate)) {
                                maxStartDate = startDate;
                                truePrevTaskID = prevType === 2 ? preTask.laterChildId : relationInfo.prevId;
                            }
                        }
                    }
                    catch (error) {
                    }
                }
                task.truePrevTaskID = truePrevTaskID;
            }
            else {
                task.truePrevTaskID = null;
            }
            // 判断有没有受例外日期的影响
            // const correctStartDate = GanttMethod.date.datePipe(Gantt, maxStartDate);
            // task.startDate = correctStartDate;
            // task.startDate = maxStartDate;
            if (maxStartDate && !moment(task.startDate).isAfter(maxStartDate)) {
                task.startDate = maxStartDate;
            }
            // const startUnix = task.startDate ? moment(task.startDate).unix() : null;
            // const endUnix = task.endDate ? moment(task.endDate).unix() : null;
            // // 先根据例外日期，改变任务的开始时间和结束时间
            // console.log(Gantt.calendar.exceptDate)
            // Gantt.calendar.exceptDate.forEach((exceptDate) => {
            //     // 任务开始时间在例外日期之间
            //     let exceptDateStart = moment(exceptDate.startDate).unix();
            //     let exceptDateEnd = moment(exceptDate.endDate).unix()
            //     if (startUnix <= exceptDateEnd && startUnix >= exceptDateStart) {
            //         const correctDate = moment.unix(exceptDateEnd).clone().add(1, 'days').toDate();
            //         if (moment(correctDate).clone().isAfter(moment(maxStartDate))) {
            //             task.startDate = correctDate;
            //             // maxStartDate = correctDate;
            //         }
            //     }
            //     // 任务结束时间在例外日期之间
            //     if (endUnix <= exceptDateEnd && endUnix >= exceptDateStart) {
            //         const correctDate = moment.unix(exceptDateEnd).clone().add(1, 'days').toDate();
            //         task.endDate = correctDate;
            //     }
            // });
        }
    },
    /**
     * @param {?} allTasks
     * @return {?}
     */
    updateParentStartDate(allTasks) {
        for (let i = allTasks.length - 1; i >= 0; i--) {
            if (allTasks[i].childTaskID.length > 0) {
                /** @type {?} */
                const parentTask = allTasks[i];
                GanttMethod.predecessorLink.loopParentMaxMin(allTasks, parentTask, parentTask);
                /** @type {?} */
                const minStartDate = allTasks[parentTask.earlierChildId - 1].startDate;
                /** @type {?} */
                const maxEndDate = allTasks[parentTask.laterChildId - 1].endDate;
                allTasks[i].startDate = minStartDate;
                allTasks[i].endDate = maxEndDate;
            }
        }
    },
    /**
     * @param {?} Gantt
     * @return {?}
     */
    dealWithExceptDate(Gantt) {
        /** @type {?} */
        const allTasks = Gantt.allTasks;
        for (const task of allTasks) {
            /** @type {?} */
            const startUnix2 = task.startDate ? moment(task.startDate).unix() : null;
            /** @type {?} */
            const endUnix2 = task.endDate ? moment(task.endDate).unix() : null;
            /** @type {?} */
            let allExcept = 0;
            // 再统计任务中所有的例外日期工期
            Gantt.calendar.exceptDate.forEach((/**
             * @param {?} item
             * @return {?}
             */
            (item) => {
                /** @type {?} */
                let fromDateUnix = moment(item.fromDate).unix();
                /** @type {?} */
                let toDateUnix = moment(item.toDate).unix();
                // 例外日期在任务的开始时间和结束时间之间
                if (startUnix2 <= fromDateUnix && endUnix2 >= toDateUnix) {
                    /** @type {?} */
                    const exceptDuration = moment(item.toDate).clone().diff(moment(item.fromDate), 'days') + 1;
                    allExcept = allExcept + exceptDuration;
                }
            }));
            task.exceptDuration = allExcept;
            // 计算showDuration
            if (task.duration) {
                task.showDuration = task.duration - allExcept;
            }
            else {
                if (task.startDate && task.endDate) {
                    /** @type {?} */
                    const num = moment(task.endDate).clone().diff(moment(task.startDate), 'days');
                    task.showDuration = num + 1;
                }
            }
        }
    },
    /**
     * @param {?} Gantt
     * @param {?} date
     * @param {?} addDay
     * @return {?}
     */
    datePipe(Gantt, date, addDay) {
        /** @type {?} */
        const getStartDateFromWeekDay = (/**
         * @return {?}
         */
        () => {
            /** @type {?} */
            const dateUnix = date ? moment(date).unix() : null;
            /** @type {?} */
            const dayWeekType = new Date(dateUnix * 1000).getDay();
            if (Gantt.calendar.pauseWeekDayTypes.indexOf(dayWeekType + 1) !== -1) {
                // 时间是周末
                /** @type {?} */
                const nextDate = moment(date).clone().add(addDay, 'days').toDate();
                date = nextDate;
                getStartDateFromWeekDay();
            }
            else if (Gantt.calendar.exceptDate) {
                // 时间在例外日期之间
                Gantt.calendar.exceptDate.forEach((/**
                 * @param {?} exceptDate
                 * @return {?}
                 */
                (exceptDate) => {
                    /** @type {?} */
                    const exceptDateStart = moment(exceptDate.fromDate).unix();
                    /** @type {?} */
                    const exceptDateEnd = moment(exceptDate.toDate).unix();
                    if (dateUnix <= exceptDateEnd && dateUnix >= exceptDateStart) {
                        /** @type {?} */
                        const nextDate = moment.unix(exceptDateEnd).clone().add(addDay, 'days').toDate();
                        date = nextDate;
                        getStartDateFromWeekDay();
                    }
                }));
            }
        });
        /** @type {?} */
        const dateUnix = moment(date).unix();
        if (GanttMethod.date.isPausedDay(Gantt, dateUnix)) {
            getStartDateFromWeekDay();
        }
        return date;
    },
    /**
     * @param {?} Gantt
     * @param {?} startDate
     * @param {?} duration
     * @param {?} endDate
     * @return {?}
     */
    handleStartDate(Gantt, startDate, duration, endDate) {
        if (!duration) {
            duration = 1;
        }
        /** @type {?} */
        const getCorrectDate = (/**
         * @return {?}
         */
        () => {
            /** @type {?} */
            const differAndPauseDays = GanttMethod.date.getDifferAndPauseDays(Gantt, startDate, endDate);
            /** @type {?} */
            const pauseDaysCount = differAndPauseDays.pauseDaysCount;
            /** @type {?} */
            const differ = differAndPauseDays.differ;
            if (pauseDaysCount !== 0) {
                if ((pauseDaysCount + duration) !== differ) {
                    startDate = moment(endDate).clone().add(-(pauseDaysCount + duration - 1), 'days').toDate();
                    getCorrectDate();
                }
            }
        });
        getCorrectDate();
        return startDate;
    },
    /**
     * @param {?} Gantt
     * @param {?} startDate
     * @param {?} duration
     * @param {?} endDate
     * @return {?}
     */
    handleEndDate(Gantt, startDate, duration, endDate) {
        if (!duration) {
            duration = 1;
        }
        /** @type {?} */
        const getCorrectDate = (/**
         * @return {?}
         */
        () => {
            /** @type {?} */
            const differAndPauseDays = GanttMethod.date.getDifferAndPauseDays(Gantt, startDate, endDate);
            /** @type {?} */
            const pauseDaysCount = differAndPauseDays.pauseDaysCount;
            /** @type {?} */
            const differ = differAndPauseDays.differ;
            if (pauseDaysCount !== 0) {
                if ((pauseDaysCount + duration) !== differ) {
                    endDate = moment(startDate).clone().add(pauseDaysCount + duration - 1, 'days').toDate();
                    getCorrectDate();
                }
            }
        });
        getCorrectDate();
        return endDate;
    },
    /**
     * @param {?} Gantt
     * @param {?} start
     * @param {?} end
     * @return {?}
     */
    getDifferAndPauseDays(Gantt, start, end) {
        /** @type {?} */
        const startUnix = moment(start).unix();
        /** @type {?} */
        const endUnix = moment(end).unix();
        /** @type {?} */
        const oneDayLong = 24 * 60 * 60;
        /** @type {?} */
        const differ = (endUnix - startUnix) / oneDayLong;
        /** @type {?} */
        let pauseDays = 0;
        for (let i = 0; i <= differ; i++) {
            /** @type {?} */
            const currentDayUnix = startUnix + i * oneDayLong;
            /** @type {?} */
            const currentDayType = new Date(currentDayUnix * 1000).getDay();
            if (Gantt.calendar.pauseWeekDayTypes.indexOf(currentDayType + 1) !== -1) {
                pauseDays++;
            }
            if (GanttMethod.date.isExceptDay(Gantt, currentDayUnix)) {
                pauseDays++;
            }
        }
        return {
            differ: differ + 1,
            pauseDaysCount: pauseDays,
        };
    },
    /**
     * @param {?} Gantt
     * @param {?} dayUnix
     * @return {?}
     */
    isExceptDay(Gantt, dayUnix) {
        for (const exceptDate of Gantt.calendar.exceptDate) {
            /** @type {?} */
            const exceptDateStart = moment(exceptDate.fromDate).unix();
            /** @type {?} */
            const exceptDateEnd = moment(exceptDate.toDate).unix();
            // 任务结束时间在例外日期之间
            if (dayUnix <= exceptDateEnd && dayUnix >= exceptDateStart) {
                return true;
            }
        }
        return false;
    },
    /**
     * @param {?} Gantt
     * @param {?} dayUnix
     * @return {?}
     */
    isPausedDay(Gantt, dayUnix) {
        for (const exceptDate of Gantt.calendar.exceptDate) {
            /** @type {?} */
            const exceptDateStart = moment(exceptDate.fromDate).unix();
            /** @type {?} */
            const exceptDateEnd = moment(exceptDate.toDate).unix();
            // 任务结束时间在例外日期之间
            if (dayUnix <= exceptDateEnd && dayUnix >= exceptDateStart) {
                return true;
            }
        }
        /** @type {?} */
        const dayWeekType = new Date(dayUnix * 1000).getDay();
        if (Gantt.calendar.pauseWeekDayTypes.indexOf(dayWeekType + 1) !== -1) {
            return true;
        }
    }
};
GanttMethod.server = {};
if (false) {
    /** @type {?} */
    GanttMethod.mpp;
    /** @type {?} */
    GanttMethod.canvas;
    /** @type {?} */
    GanttMethod.tasks;
    /** @type {?} */
    GanttMethod.predecessorLink;
    /** @type {?} */
    GanttMethod.date;
    /** @type {?} */
    GanttMethod.server;
}

/**
 * @fileoverview added by tsickle
 * Generated from: lib/src/lib/gantt.api.ts
 * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
class Xmpp {
    constructor() {
        this.globalLoading = false;
        /** @type {?} */
        const currentMpp = this;
        this.task = {
            isAllSelect: false,
            activeTaskId: null,
            selectedTasks: [],
            /**
             * 任务列表可视任务数量
             */
            showTaskLength: 0,
            /**
             * 日历绘制监听事件
             */
            canvasInfoListener: new Subject(),
            /**
             * 降级折叠后，隐层的任务ids
             */
            hideTasksIds: [],
            /**
             * 默认的任务列表高度
             */
            taskHeight: 36,
            /**
             * 任务列表可视区域开始index
             */
            startTaskIndex: 0,
            /**
             * 任务列表可视区域的任务组
             */
            showTask: [],
            maxUID: 0,
            deleteTasksSqlIdStore: [],
            /**
             * 操作后，更新任务关联关系
             * @return {?}
             */
            updateTaskHandle() {
                GanttMethod.tasks.updateTaskHandle(currentMpp);
            },
            /**
             * 获取折叠之后的可视任务
             * @return {?}
             */
            getAllTaskAfterFold() {
                return GanttMethod.tasks.getAllTaskAfterFold(currentMpp);
            },
            /**
             * 升降机操作后，更新任务的层级
             * @return {?}
             */
            updateLeveInfo() {
                GanttMethod.tasks.updateLeveInfo(currentMpp.allTasks);
            },
            /**
             * 更新任务时间
             * @return {?}
             */
            updateStartDate() {
                GanttMethod.date.updateStartDate(currentMpp);
            },
            /**
             * 更新父任务时间
             * @return {?}
             */
            updateParentStartDate() {
                GanttMethod.date.updateParentStartDate(currentMpp.allTasks);
            },
            /**
             * 前端添加任务
             * @param {?} taskParam
             * @return {?}
             */
            addTaskHandle(taskParam) {
                GanttMethod.tasks.addTaskHandle(currentMpp, taskParam);
            },
            /**
             * 前端删除任务
             * @param {?} taskIds
             * @return {?}
             */
            deleteTaskHandle(taskIds) {
                GanttMethod.tasks.deleteTaskHandle(currentMpp, taskIds);
            },
            /**
             * 降级任务
             * @param {?} tasks
             * @return {?}
             */
            depressTaskLevel(tasks) {
                GanttMethod.tasks.depressTaskLevel(currentMpp, tasks);
            },
            /**
             * 升级任务
             * @param {?} tasks
             * @return {?}
             */
            promoteTaskLevel(tasks) {
                GanttMethod.tasks.promoteTaskLevel(currentMpp, tasks);
            },
            /**
             * @param {?} startDate
             * @return {?}
             */
            nextDatePipe(startDate) {
                return GanttMethod.date.datePipe(currentMpp, startDate, 1);
            },
            /**
             * @param {?} startDate
             * @return {?}
             */
            lastDatePipe(startDate) {
                return GanttMethod.date.datePipe(currentMpp, startDate, -1);
            },
            /**
             * @param {?} startDate
             * @param {?} duration
             * @param {?} endDate
             * @return {?}
             */
            getStartDateWithExcept(startDate, duration, endDate) {
                return GanttMethod.date.handleStartDate(currentMpp, startDate, duration, endDate);
            },
            /**
             * @param {?} startDate
             * @param {?} duration
             * @param {?} endDate
             * @return {?}
             */
            getEndDateWithExcept(startDate, duration, endDate) {
                return GanttMethod.date.handleEndDate(currentMpp, startDate, duration, endDate);
            },
            /**
             * @return {?}
             */
            loopAllTasksId() {
                for (let i = 0; i < currentMpp.allTasks.length; i++) {
                    /** @type {?} */
                    const element = currentMpp.allTasks[i];
                    element.id = i + 1;
                }
                currentMpp.render();
            }
        };
        this.mpp = {
            mppInfo: null,
            mppTasks: [],
            mppExtendAttrs: [],
            extraAttrMap: new Map(),
            /**
             * 处理后台的文件格式
             * @param {?} mppProject
             * @param {?} mppTasks ITask[]
             * @return {?}
             */
            dealWithMPP(mppProject, mppTasks) {
                currentMpp.task.showTask = [];
            },
            /**
             * @param {?} mppProject
             * @return {?}
             */
            setMppInfo(mppProject) {
                GanttMethod.mpp.dealWithProject(currentMpp, mppProject);
            },
            /**
             * @param {?} mppTasks
             * @return {?}
             */
            setMppTasks(mppTasks) {
                /** @type {?} */
                const allTasks = GanttMethod.mpp.dealWithMPPTasks(currentMpp, mppTasks);
                currentMpp.allTasks = allTasks;
            },
            /**
             * 将parentId关系结构处理成wbs层级
             * @return {?}
             */
            ParentId2WBS() {
                GanttMethod.mpp.ParentId2WBS(currentMpp);
            }
        };
        this.draw = {
            selectedTaskId: null,
            showTooltip: true,
            canvasInfo: [],
            exceptCanvasInfo: [],
            canvasHeight: 0,
            actualCanvasInfo: [],
            mouseoverListener: new Subject(),
            mouseupListener: new Subject(),
            mousedownListener: new Subject(),
            contextmenuListener: new Subject(),
            color: {
                /**
                 * 计划时间颜色
                 */
                planColor: 'rgba(65,159,229, 0.2)',
                /**
                 * 任务为关键线路时，计划时间颜色
                 */
                planKeyColor: 'rgba(255, 128, 128, 0.2)',
                /**
                 * 实际时间颜色
                 */
                Actualcolor: '#419fe8',
                /**
                 * 任务为关键线路时，实际时间颜色
                 */
                ActualkeyColor: '#ff8080',
                /**
                 * 箭头及连线颜色
                 */
                arrowColor: 'rgba(65,159,229, 0.2)',
                /**
                 * 任务为关键线路时，箭头及连线颜色
                 */
                arrowKeyColor: 'rgba(255, 128, 128, 0.2)',
                exceptDateColor: '#ff8080'
            },
            lineHeight: 26,
            actualLineHeight: 10,
            canvasWidth: 0,
            /**
             * @param {?} width
             * @return {?}
             */
            setCanvasWidth(width) {
                if (!currentMpp.draw.canvasWidth || currentMpp.draw.canvasWidth !== width) {
                    currentMpp.draw.canvasWidth = width;
                    currentMpp.task.canvasInfoListener.next();
                }
            },
            canvasLeftHide: 0,
            /**
             * @return {?}
             */
            updateCanvasInfo() {
                GanttMethod.canvas.updateCanvasInfo(currentMpp);
                currentMpp.task.canvasInfoListener.next();
            },
            /**
             * @param {?} ctx
             * @return {?}
             */
            drawExceptArea(ctx) {
                GanttMethod.canvas.drawExceptArea(currentMpp, ctx);
            },
            /**
             * @param {?} ctx
             * @param {?=} isActual
             * @return {?}
             */
            drawTasks(ctx, isActual) {
                GanttMethod.canvas.drawTasks(currentMpp, ctx, isActual);
            },
            /**
             * @param {?} taskId
             * @return {?}
             */
            drawSelectTask(taskId) {
                GanttMethod.canvas.drawSelectTask(currentMpp, taskId);
            },
            /**
             * @return {?}
             */
            canvasMouseEventListen() {
                /** @type {?} */
                const windowToCanvas = (/**
                 * @param {?} canvas
                 * @param {?} x
                 * @param {?} y
                 * @return {?}
                 */
                (canvas, x, y) => {
                    /** @type {?} */
                    const rect = canvas.getBoundingClientRect();
                    return {
                        x: x - rect.left * (canvas.width / rect.width),
                        y: y - rect.top * (canvas.height / rect.height)
                    };
                });
                /** @type {?} */
                const canvas = document.getElementById('maskCanvas');
                /** @type {?} */
                const isTask = (/**
                 * @param {?} ele
                 * @return {?}
                 */
                (ele) => {
                    /** @type {?} */
                    const planIndex = currentMpp.draw.canvasInfo.findIndex((/**
                     * @param {?} item
                     * @return {?}
                     */
                    item => {
                        return ele.x > item.positionX && ele.x < item.positionX + item.width &&
                            ele.y > item.positionY && ele.y < item.positionY + item.lineHeight;
                    }));
                    /** @type {?} */
                    const actualIndex = currentMpp.draw.actualCanvasInfo.findIndex((/**
                     * @param {?} item
                     * @return {?}
                     */
                    item => {
                        return ele.x > item.positionX && ele.x < item.positionX + item.width &&
                            ele.y > item.positionY && ele.y < item.positionY + item.lineHeight;
                    }));
                    /** @type {?} */
                    let task;
                    if (planIndex !== -1) {
                        task = currentMpp.allTasks[planIndex];
                    }
                    if (actualIndex !== -1) {
                        task = currentMpp.allTasks[actualIndex];
                    }
                    return task;
                });
                canvas.onmousemove = (/**
                 * @param {?} e
                 * @return {?}
                 */
                (e) => {
                    /** @type {?} */
                    const ele = windowToCanvas(canvas, e.clientX, e.clientY);
                    /** @type {?} */
                    const task = isTask(ele);
                    currentMpp.draw.mouseoverListener.next({ event: e, task, position: ele });
                    if (currentMpp.draw.showTooltip) {
                        currentMpp.draw.drawTooltip(ele, task);
                        if (currentMpp.draw.selectedTaskId) {
                            currentMpp.draw.drawSelectTask(currentMpp.draw.selectedTaskId);
                        }
                    }
                });
                canvas.onmouseup = (/**
                 * @param {?} e
                 * @return {?}
                 */
                (e) => {
                    /** @type {?} */
                    const ele = windowToCanvas(canvas, e.clientX, e.clientY);
                    /** @type {?} */
                    const task = isTask(ele);
                    currentMpp.draw.mouseupListener.next({ event: e, task, position: ele });
                });
                canvas.onmousedown = (/**
                 * @param {?} e
                 * @return {?}
                 */
                (e) => {
                    /** @type {?} */
                    const ele = windowToCanvas(canvas, e.clientX, e.clientY);
                    /** @type {?} */
                    const task = isTask(ele);
                    currentMpp.draw.mousedownListener.next({ event: e, task, position: ele });
                });
                canvas.oncontextmenu = (/**
                 * @param {?} e
                 * @return {?}
                 */
                (e) => {
                    /** @type {?} */
                    const ele = windowToCanvas(canvas, e.clientX, e.clientY);
                    /** @type {?} */
                    const task = isTask(ele);
                    currentMpp.draw.contextmenuListener.next({ event: e, task, position: ele });
                });
            },
            /**
             * @param {?} ele
             * @param {?} task
             * @return {?}
             */
            drawTooltip(ele, task) {
                /** @type {?} */
                const c = (/** @type {?} */ ((document.getElementById('maskCanvas'))));
                /** @type {?} */
                const ctxMask = c.getContext('2d');
                /** @type {?} */
                const panelWidth = document.getElementById('maskCanvas').clientWidth;
                /** @type {?} */
                const tipWidth = 220;
                /** @type {?} */
                let tipX = ele.x + 10;
                /** @type {?} */
                const tipY = ele.y + 5;
                if (tipX + tipWidth > panelWidth) {
                    tipX = ele.x - 220;
                }
                if (task) {
                    document.getElementById('maskCanvas').setAttribute('style', `cursor: pointer`);
                    ctxMask.clearRect(0, 0, panelWidth, currentMpp.draw.canvasHeight);
                    ctxMask.fillStyle = 'rgba(0,0,0,0.6)';
                    GanttMethod.canvas.drawRoundRect(ctxMask, tipX, tipY, tipWidth, 60, 5);
                    ctxMask.fill();
                    ctxMask.fillStyle = '#fff';
                    /** @type {?} */
                    const planText = task.startDate ?
                        '计划时间：' + moment(task.startDate).format('YYYY.MM.DD') + '-' + moment(task.endDate).format('YYYY.MM.DD') :
                        '计划时间：暂无';
                    /** @type {?} */
                    const actualText = task.actualStartDate ?
                        '实际时间：' + moment(task.actualStartDate).format('YYYY.MM.DD') + '-' + moment(task.actualEndDate).format('YYYY.MM.DD') :
                        '实际时间：暂无';
                    GanttMethod.canvas.drawText(ctxMask, planText, tipX + 15, tipY + 23, 12);
                    GanttMethod.canvas.drawText(ctxMask, actualText, tipX + 15, tipY + 42, 12);
                }
                else {
                    document.getElementById('maskCanvas').setAttribute('style', `cursor: default`);
                    ctxMask.clearRect(0, 0, panelWidth, currentMpp.draw.canvasHeight);
                }
            }
        };
        this.column = {
            columnNames: [],
            totalWidth: 0,
            setColumn: (/**
             * @param {?} param
             * @return {?}
             */
            (param) => {
                currentMpp.column.totalWidth = 0;
                for (const cv of param) {
                    if (!cv.type) {
                        cv.type = 'text';
                    }
                    /** @type {?} */
                    let resizeBarWidth = 0;
                    if (cv.resize) {
                        resizeBarWidth = 2;
                    }
                    currentMpp.column.totalWidth = currentMpp.column.totalWidth + cv.width + resizeBarWidth + 5;
                }
                currentMpp.column.columnNames = param;
            })
        };
        this.calendar = {
            calendarId: null,
            /**
             * 日历周数组
             */
            weeksArry: [],
            /**
             * 日历总宽度
             */
            calenderWidth: 0,
            /**
             * 单元格日历（天）的宽度
             */
            baseCellWidth: 25,
            /**
             * 例外日期
             */
            exceptDate: [],
            /**
             * 处理例外日期
             * @return {?}
             */
            dealWithExceptDate() {
                GanttMethod.date.dealWithExceptDate(currentMpp);
            },
            /**
             * 工作周
             */
            weekDays: [],
            // 日历中放假的所有日期
            pauseWeekDays: [],
            pauseWeekDayTypes: []
        };
        this.render = (/**
         * @return {?}
         */
        () => {
            // 清空canvas
            currentMpp.draw.canvasInfo = [];
            currentMpp.draw.actualCanvasInfo = [];
            if (currentMpp.allTasks.length > 0) {
                // 升级降级
                currentMpp.task.updateLeveInfo();
                // 根据前置任务的时间更新startDate
                currentMpp.task.updateStartDate();
                // 更新parent的startDate
                currentMpp.task.updateParentStartDate();
                // 计算showDuration
                currentMpp.calendar.dealWithExceptDate();
                // // 更新实际startDate
                // this.updateActualStartDate();
                // // 更新parent的actualStartDate
                // this.updateParentActualStartDate();
                // // 计算showDuration
                // this.dealWithActualExceptDate()
                // 计算showTask
                currentMpp.task.updateTaskHandle();
                // 最后更新 canvas和日历(update canvas)
                currentMpp.draw.updateCanvasInfo();
                // 画布鼠标事件的监听
                currentMpp.draw.canvasMouseEventListen();
            }
            else {
                // this.showTask = [];
                currentMpp.calendar.weeksArry = [];
            }
        });
        /**
         * canvas区域任务的鼠标事件
         */
        this.addGanttEventListener = (/**
         * @param {?} type
         * @param {?=} cb
         * @return {?}
         */
        (type, cb) => {
            if (type === 'mouseoverListener') {
                currentMpp.draw.mouseoverListener.subscribe((/**
                 * @param {?} __0
                 * @return {?}
                 */
                ({ event: e, task, position: ele }) => {
                    cb({ event: e, task, position: ele });
                }));
            }
            if (type === 'mouseupListener') {
                currentMpp.draw.mouseupListener.subscribe((/**
                 * @param {?} __0
                 * @return {?}
                 */
                ({ event: e, task, position: ele }) => {
                    cb({ event: e, task, position: ele });
                }));
            }
            if (type === 'mousedownListener') {
                currentMpp.draw.mousedownListener.subscribe((/**
                 * @param {?} __0
                 * @return {?}
                 */
                ({ event: e, task, position: ele }) => {
                    cb({ event: e, task, position: ele });
                }));
            }
            if (type === 'contextmenuListener') {
                currentMpp.draw.contextmenuListener.subscribe((/**
                 * @param {?} __0
                 * @return {?}
                 */
                ({ event: e, task, position: ele }) => {
                    cb({ event: e, task, position: ele });
                }));
            }
        });
    }
}
if (false) {
    /** @type {?} */
    Xmpp.prototype.allTasks;
    /** @type {?} */
    Xmpp.prototype.globalLoading;
    /** @type {?} */
    Xmpp.prototype.mpp;
    /** @type {?} */
    Xmpp.prototype.task;
    /** @type {?} */
    Xmpp.prototype.draw;
    /** @type {?} */
    Xmpp.prototype.column;
    /** @type {?} */
    Xmpp.prototype.calendar;
    /** @type {?} */
    Xmpp.prototype.render;
    /** @type {?} */
    Xmpp.prototype.addGanttEventListener;
}

/**
 * @fileoverview added by tsickle
 * Generated from: lib/src/api-public.ts
 * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */

/**
 * @fileoverview added by tsickle
 * Generated from: lib/gantt-chart-service/gantt-request.service.ts
 * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
/** @type {?} */
const GANTTURL = 'http://localhost:5004';
// const GANTTURL = 'http://kzzbim.spddemo.com:88'
/** @type {?} */
const PROJECTID = 'bf894bfd-80ad-417d-bd31-a8af3200025c';
class GanttRequestService {
    /**
     * @param {?} requestClientService
     */
    constructor(requestClientService) {
        this.requestClientService = requestClientService;
        // this.http = injector.get(Http);
        // this.httpClient = injector.get(HttpClient);
    }
    /**
     * 上传mpp文件，自定义项目title
     * @param {?} uploadForm
     * @return {?}
     */
    uploadMMP(uploadForm) {
        return __awaiter(this, void 0, void 0, function* () {
            /** @type {?} */
            const projectId = PROJECTID;
            // let projectId = this.modelService.modelId;
            /** @type {?} */
            const formdata = new FormData();
            formdata.set('file', uploadForm.uploadMMP);
            /** @type {?} */
            const res = yield this.requestClientService.postSSO(GANTTURL + `/mpp/api/v1/mpp/import/${projectId}`, formdata);
            if (res.success) {
                /** @type {?} */
                const data = res.item;
                /** @type {?} */
                const id = res.item.id;
                /** @type {?} */
                const param = {
                    Title: uploadForm.uploadTitle
                };
                /** @type {?} */
                const res2 = yield this.updateGantt(id, param);
                // console.log(res2);
                // res.item.title == res2.data.Title;
                return res.item;
            }
            else {
                return false;
            }
        });
    }
    /**
     * @param {?} uploadForm
     * @return {?}
     */
    uploadMppWithOutSave(uploadForm) {
        return __awaiter(this, void 0, void 0, function* () {
            /** @type {?} */
            const projectId = PROJECTID;
            // let projectId = this.modelService.modelId;
            /** @type {?} */
            const formdata = new FormData();
            formdata.set('file', uploadForm.uploadMMP);
            /** @type {?} */
            const res = yield this.requestClientService.postSSO(GANTTURL + `/mpp/api/v1/mpp/importWidthoutSave/${projectId}`, formdata);
            if (res.success) {
                /** @type {?} */
                const data = res.item;
                /** @type {?} */
                const id = res.item.id;
                /** @type {?} */
                const param = {
                    Title: uploadForm.uploadTitle
                };
                /** @type {?} */
                const res2 = yield this.updateGantt(id, param);
                // console.log(res2);
                // res.item.title == res2.data.Title;
                return res.item;
            }
            else {
                return false;
            }
        });
    }
    /**
     * @param {?} id
     * @param {?} param
     * @return {?}
     */
    updateGantt(id, param) {
        return __awaiter(this, void 0, void 0, function* () {
            return this.requestClientService.putSSO(GANTTURL + `/mpp/api/v1/mpp/project/${id}`, JSON.stringify(param), { 'Content-Type': 'application/json' });
        });
    }
    /**
     * 获取项目列表
     * @return {?}
     */
    getGanttList() {
        return __awaiter(this, void 0, void 0, function* () {
            /** @type {?} */
            const projectId = PROJECTID;
            /** @type {?} */
            const res = yield this.requestClientService.getSSO(GANTTURL + `/mpp/api/v1/mpp/${projectId}/projects`, {});
            if (res.success) {
                return res.items;
            }
            else {
                return [];
            }
        });
    }
    /**
     * 删除gantt
     * @param {?} ganttId
     * @return {?}
     */
    deleteGantt(ganttId) {
        return __awaiter(this, void 0, void 0, function* () {
            yield this.requestClientService.deleteSSO(GANTTURL + `/mpp/api/v1/mpp/project/${ganttId}`, {});
        });
    }
    /**
     * @param {?} projectId
     * @param {?} taskId
     * @param {?} param
     * @return {?}
     */
    updateTask(projectId, taskId, param) {
        return __awaiter(this, void 0, void 0, function* () {
            /** @type {?} */
            const res = yield this.requestClientService.putSSO(GANTTURL + `/mpp/api/v1/mpp/project/${projectId}/task/${taskId}`, param);
            return res;
        });
    }
    /**
     * 获取task列表
     * @param {?} ganttId
     * @return {?}
     */
    getTasksList(ganttId) {
        return __awaiter(this, void 0, void 0, function* () {
            /** @type {?} */
            const res = yield this.requestClientService.getSSO(GANTTURL + `/mpp/api/v1/mpp/project/${ganttId}/tasks`, {});
            if (res.success) {
                return res.items;
            }
            else {
                return [];
            }
        });
    }
    /**
     * 获取进度信息
     * @param {?} ganttId
     * @return {?}
     */
    getGanttInfo(ganttId) {
        return __awaiter(this, void 0, void 0, function* () {
            /** @type {?} */
            const res = yield this.requestClientService.getSSO(GANTTURL + `/mpp/api/v1/mpp/project/${ganttId}`, {});
            if (res.success) {
                return res.item;
            }
            else {
                return null;
            }
        });
    }
    /**
     * 更新tasks（总）
     * @param {?} ganttId
     * @param {?} param
     * @return {?}
     */
    putTasks(ganttId, param) {
        return __awaiter(this, void 0, void 0, function* () {
            /** @type {?} */
            const res = yield this.requestClientService.putSSO(GANTTURL + `/mpp/api/v1/mpp/project/${ganttId}/batch`, param);
            if (res.success) {
                return true;
            }
            else {
                return false;
            }
        });
    }
    /**
     * 新建进度
     * @param {?} param
     * @return {?}
     */
    postGantt(param) {
        return __awaiter(this, void 0, void 0, function* () {
            // let projectId = this.modelService.modelId;
            /** @type {?} */
            const projectId = PROJECTID;
            /** @type {?} */
            const res = yield this.requestClientService.postSSO(GANTTURL + `/mpp/api/v1/mpp/project/${projectId}`, param);
            console.log(res);
            if (res.success) {
                return res.item.id;
            }
            else {
                return null;
            }
        });
    }
    /**
     * 创建binding资源并关联project
     * @param {?} ganttId
     * @return {?}
     */
    postGanttBindingAttr(ganttId) {
        return __awaiter(this, void 0, void 0, function* () {
            /** @type {?} */
            const res = yield this.requestClientService.postSSO(GANTTURL + `/mpp/api/v1/mpp/project/${ganttId}/extendedattribute`, EXTENDATTRS.binding);
            return res;
        });
    }
    /**
     * 获取project所绑定的资源
     * @param {?} ganttId
     * @return {?}
     */
    getGanttAttrs(ganttId) {
        return __awaiter(this, void 0, void 0, function* () {
            /** @type {?} */
            const res = yield this.requestClientService.getSSO(GANTTURL + `/mpp/api/v1/mpp/project/${ganttId}/extendedattributes`, {});
            return res.items;
        });
    }
    /**
     * 获取task的拓展属性
     * @param {?} ganttId
     * @param {?} taskId
     * @return {?}
     */
    getTaskAttrs(ganttId, taskId) {
        return __awaiter(this, void 0, void 0, function* () {
            /** @type {?} */
            const res = yield this.requestClientService.getSSO(GANTTURL + `/mpp/api/v1/mpp/project/${ganttId}/task/${taskId}`, {});
            if (res.success) {
                return res.item.extendedAttribute;
            }
            else {
                return [];
            }
        });
    }
    /**
     * 新增task绑定extend
     * @param {?} ganttId
     * @param {?} taskId
     * @param {?} param
     * @return {?}
     */
    bindTaskExtendedAttribute(ganttId, taskId, param) {
        return __awaiter(this, void 0, void 0, function* () {
            // tslint:disable-next-line: max-line-length
            /** @type {?} */
            const res = yield this.requestClientService.postSSO(GANTTURL + `/mpp/api/v1/mpp/project/${ganttId}/task/${taskId}/extendedattribute`, JSON.stringify(param), { 'Content-Type': 'application/json' });
            return res;
        });
    }
    /**
     * @param {?} ganttId
     * @param {?} taskId
     * @param {?} attrId
     * @param {?} param
     * @return {?}
     */
    updateExtendedAttrbute(ganttId, taskId, attrId, param) {
        return __awaiter(this, void 0, void 0, function* () {
            // tslint:disable-next-line: max-line-length
            /** @type {?} */
            const res = yield this.requestClientService.putSSO(GANTTURL + `/mpp/api/v1/mpp/project/${ganttId}/task/${taskId}/extendedattribute/${attrId}`, JSON.stringify(param), { 'Content-Type': 'application/json' });
            return res;
        });
    }
}
GanttRequestService.decorators = [
    { type: Injectable, args: [{
                providedIn: 'root'
            },] }
];
/** @nocollapse */
GanttRequestService.ctorParameters = () => [
    { type: RequestClientService }
];
/** @nocollapse */ GanttRequestService.ngInjectableDef = ɵɵdefineInjectable({ factory: function GanttRequestService_Factory() { return new GanttRequestService(ɵɵinject(RequestClientService)); }, token: GanttRequestService, providedIn: "root" });
if (false) {
    /**
     * @type {?}
     * @private
     */
    GanttRequestService.prototype.requestClientService;
}

/**
 * @fileoverview added by tsickle
 * Generated from: lib/gantt-chart-service/gantt-helper.service.ts
 * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
class GanttHelperService {
    /**
     * @param {?} message
     * @param {?} ganttRequestSev
     */
    constructor(message, ganttRequestSev) {
        this.message = message;
        this.ganttRequestSev = ganttRequestSev;
        this.settingVisible = false;
        // relations: any = [];
        // alreadyDeleteTasks: any[] = [];
        this.loading = false;
    }
    // public async saveTasksHanle(xmpp: Xmpp, type: string) {
    //   const getGuid = () => {
    //     const s = [];
    //     const hexDigits = '0123456789abcdef';
    //     for (let i = 0; i < 36; i++) {
    //       s[i] = hexDigits.substr(Math.floor(Math.random() * 0x10), 1);
    //     }
    //     s[14] = '4'; // bits 12-15 of the time_hi_and_version field to 0010
    //     s[19] = hexDigits.substr((s[19] & 0x3) | 0x8, 1); // bits 6-7 of the clock_seq_hi_and_reserved to 01
    //     s[8] = s[13] = s[18] = s[23] = '-';
    //     const uuid = s.join('');
    //     return uuid;
    //   };
    //   const allTasks = xmpp.allTasks;
    //   const taskHasSqlId = [];
    //   const alreadyAddTasks: XmppTask[] = [];
    //   const alreadyEditTasks: XmppTask[] = [];
    //   const alreadyDeleteTasks: XmppTask[] = this.alreadyDeleteTasks;
    //   this.loading = true;
    //   xmpp.mpp.ParentId2WBS();
    //   // 组装 alreadyEditTasks
    //   for (const task of allTasks) {
    //     if (task.defaultData) {
    //       taskHasSqlId.push(task);
    //     } else {
    //       xmpp.task.maxUID = xmpp.task.maxUID + 1;
    //       task.uid = xmpp.task.maxUID;
    //       alreadyAddTasks.push(task);
    //     }
    //   }
    //   // 组装 alreadyEditTasks
    //   for (const element of taskHasSqlId) {
    //     const defaultData = element.defaultData;
    //     const dateKey = ['startDate', 'endDate', 'actualStartDate', 'actualEndDate'];
    //     const arrayKey = ['bindings', 'childTaskID', 'prevRelation'];
    //     for (const itemKey in defaultData) {
    //       // 工期变化不考虑，再次获取tasklist会重新计算工期
    //       if (itemKey === 'duration' || itemKey === 'actualDuration') {
    //         continue;
    //       }
    //       // 时间参数变化
    //       if (dateKey.indexOf(itemKey) !== -1) {
    //         const elementDate = moment(element[itemKey]).format('YYYY MM DD');
    //         const defaultDate = moment(defaultData[itemKey]).format('YYYY MM DD');
    //         if (elementDate !== defaultDate) {
    //           const datefinder = alreadyEditTasks.findIndex((task) => {
    //             return task.sqId === element.sqId;
    //           });
    //           if (datefinder === -1) {
    //             alreadyEditTasks.push(element);
    //           }
    //         }
    //         continue;
    //       }
    //       // 数组类型参数变化
    //       if (arrayKey.indexOf(itemKey) !== -1) {
    //         const elementArray = element[itemKey].toString();
    //         const defaultArray = defaultData[itemKey].toString();
    //         if (elementArray !== defaultArray) {
    //           const arrayfinder = alreadyEditTasks.findIndex((task) => {
    //             return task.sqId === element.sqId;
    //           });
    //           if (arrayfinder === -1) {
    //             alreadyEditTasks.push(element);
    //           }
    //         }
    //         continue;
    //       }
    //       // 普通参数变化
    //       if (element[itemKey] !== defaultData[itemKey]) {
    //         const normalfinder = alreadyEditTasks.findIndex((task) => {
    //           return task.sqId === element.sqId;
    //         });
    //         if (normalfinder === -1) {
    //           alreadyEditTasks.push(element);
    //         }
    //       }
    //     }
    //   }
    //   // 查询id是否连续
    //   const finder = allTasks.find((task, index) => {
    //     return task.id !== index + 1;
    //   });
    //   if (finder) {
    //     // 有错乱
    //     console.warn(finder);
    //     this.message.error('orderId重复');
    //   } else {
    //     const tasks = alreadyAddTasks.concat(alreadyEditTasks);
    //     // 整理
    //     const paramJson = [];
    //     alreadyAddTasks.forEach((task) => {
    //       task.sqId = getGuid();
    //       paramJson.push({
    //         op: 'create',
    //         type: 'task',
    //         data: task.toMpp()
    //       });
    //     });
    //     alreadyEditTasks.forEach((task) => {
    //       paramJson.push({
    //         op: 'update',
    //         type: 'task',
    //         data: task.toMpp()
    //       });
    //     });
    //     alreadyDeleteTasks.forEach((sqid) => {
    //       paramJson.push({
    //         op: 'delete',
    //         type: 'task',
    //         data: { Id: sqid }
    //       });
    //     });
    //     console.log(paramJson);
    //     this.dealwithPredecessorLink(xmpp, tasks, paramJson);
    //     const res = await this.ganttRequestSev.putTasks(xmpp.mpp.mppInfo.id, paramJson);
    //     if (res) {
    //       this.message.success('提交成功');
    //     } else {
    //       this.message.success('提交成功');
    //     }
    //     this.loading = false;
    //   }
    // }
    /**
     * @param {?} xmpp
     * @param {?} tasks
     * @param {?} paramJson
     * @return {?}
     */
    dealwithPredecessorLink(xmpp, tasks, paramJson) {
        for (const element of tasks) {
            /** @type {?} */
            const relation = element.prevRelation;
            relation.forEach((/**
             * @param {?} prev
             * @return {?}
             */
            (prev) => {
                // 处理PredecessorLink
                if (prev.id && !prev.isDelete) {
                    paramJson.push({
                        op: 'update',
                        type: 'link',
                        data: {
                            PredecessorUID: xmpp.allTasks[prev.prevId - 1].uid,
                            ParentId: element.sqId,
                            Type: prev.relation,
                            LinkLag: prev.delay * 8 * 600,
                            Id: prev.id
                        }
                    });
                }
                else if (prev.id && prev.isDelete) {
                    paramJson.push({
                        op: 'delete',
                        type: 'link',
                        data: {
                            Id: prev.id
                        }
                    });
                }
                else if (!prev.id && !prev.isDelete) {
                    paramJson.push({
                        op: 'create',
                        type: 'link',
                        data: {
                            PredecessorUID: xmpp.allTasks[prev.prevId - 1].uid,
                            ParentId: element.sqId,
                            Type: prev.relation,
                            LinkLag: prev.delay ? prev.delay * 8 * 600 : 0
                        }
                    });
                }
            }));
        }
    }
    /**
     * @param {?} task
     * @return {?}
     */
    showRelation(task) {
        this.currentTask = task;
        /** @type {?} */
        const showRelation = [];
        if (task.prevRelation.length > 0) {
            task.prevRelation.forEach((/**
             * @param {?} item
             * @return {?}
             */
            (item) => {
                /** @type {?} */
                const relation = this.translateNumber(item.relation);
                /** @type {?} */
                const delay = item.delay ? `+${item.delay}` : '';
                if (item.prevId && !item.isDelete) {
                    /** @type {?} */
                    const string = `${item.prevId}${relation}${delay}`;
                    showRelation.push(string);
                }
            }));
        }
        if (showRelation.length === 0) {
            return '请选择';
        }
        return showRelation.join(',');
    }
    /**
     * @param {?} relation
     * @return {?}
     */
    translateNumber(relation) {
        if (relation === PREVTYPE.FS) {
            return 'FS';
        }
        if (relation === PREVTYPE.SS) {
            return 'SS';
        }
        if (relation === PREVTYPE.FF) {
            return 'FF';
        }
        if (relation === PREVTYPE.SF) {
            return 'SF';
        }
    }
}
GanttHelperService.decorators = [
    { type: Injectable, args: [{
                providedIn: 'root'
            },] }
];
/** @nocollapse */
GanttHelperService.ctorParameters = () => [
    { type: NzMessageService },
    { type: GanttRequestService }
];
/** @nocollapse */ GanttHelperService.ngInjectableDef = ɵɵdefineInjectable({ factory: function GanttHelperService_Factory() { return new GanttHelperService(ɵɵinject(NzMessageService$1), ɵɵinject(GanttRequestService)); }, token: GanttHelperService, providedIn: "root" });
if (false) {
    /** @type {?} */
    GanttHelperService.prototype.settingVisible;
    /** @type {?} */
    GanttHelperService.prototype.currentTask;
    /** @type {?} */
    GanttHelperService.prototype.loading;
    /**
     * @type {?}
     * @private
     */
    GanttHelperService.prototype.message;
    /**
     * @type {?}
     * @private
     */
    GanttHelperService.prototype.ganttRequestSev;
}

/**
 * @fileoverview added by tsickle
 * Generated from: lib/gantt-box/gantt-box.component.ts
 * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
class GanttBoxComponent {
    constructor() {
        this.weeksArry = [];
        this.canvasWidth = 800;
        this.loadingShow = false;
        // 清空画布
        this.cleanCanvas = (/**
         * @return {?}
         */
        () => {
            /** @type {?} */
            const ctx = this.canvasRef.nativeElement.getContext('2d');
            ctx.clearRect(0, 0, this.Xmpp.draw.canvasWidth, this.Xmpp.draw.canvasHeight);
        });
    }
    /**
     * @return {?}
     */
    ngOnInit() {
        this.Xmpp.task.canvasInfoListener.subscribe((/**
         * @param {?} res
         * @return {?}
         */
        res => {
            this.changeWidth();
        }));
        // this.Xmpp.addGanttEventListener('mousedownListener', res => {
        //   // console.log('down');
        //   // console.log(res);
        // });
        // this.Xmpp.addGanttEventListener('mouseupListener', res => {
        //   // console.log('up');
        //   // console.log(res);
        // });
        // this.Xmpp.addGanttEventListener('contextmenuListener', res => {
        //   // console.log('右键');
        //   // console.log(res);
        // });
    }
    /**
     * @param {?} event
     * @return {?}
     */
    doMouseMove(event) {
        console.log(event);
    }
    /**
     * @return {?}
     */
    changeWidth() {
        // 日历宽度
        this.loadingShow = true;
        this.weeksArry = this.Xmpp.calendar.weeksArry;
        this.calendarWidth = this.Xmpp.calendar.calenderWidth;
        setTimeout((/**
         * @return {?}
         */
        () => {
            this.loadingShow = false;
            this.drawCanvas();
        }), 200);
    }
    /**
     * @param {?} e
     * @return {?}
     */
    boxScroll(e) {
        this.Xmpp.draw.canvasLeftHide = e.target.scrollLeft;
        this.drawCanvas();
    }
    /**
     * @return {?}
     */
    drawCanvas() {
        console.log('start---drawCanvas');
        /** @type {?} */
        const ctx = this.canvasRef.nativeElement.getContext('2d');
        ctx.clearRect(0, 0, this.Xmpp.draw.canvasWidth, this.Xmpp.draw.canvasHeight);
        /** @type {?} */
        const ctxMask = this.maskCanvas.nativeElement.getContext('2d');
        // 绘制日历
        /** @type {?} */
        const canvasInfo = this.Xmpp.draw.canvasInfo;
        /** @type {?} */
        const actualCanvasInfo = this.Xmpp.draw.actualCanvasInfo;
        if (canvasInfo && canvasInfo.length > 0) {
            // 绘制横道图
            this.Xmpp.draw.drawExceptArea(ctx);
            this.Xmpp.draw.drawTasks(ctx, false);
        }
        if (actualCanvasInfo && actualCanvasInfo.length > 0) {
            this.Xmpp.draw.drawTasks(ctx, true);
        }
    }
}
GanttBoxComponent.decorators = [
    { type: Component, args: [{
                selector: 'app-gantt-box',
                template: "<div class=\"ganttGanttBox\">\r\n    <canvas id=\"myCanvas\" #myCanvas [width]=\"Xmpp.draw.canvasWidth\" [height]=\"Xmpp.draw.canvasHeight\"></canvas>\r\n    <canvas id=\"maskCanvas\" #maskCanvas [width]=\"Xmpp.draw.canvasWidth\" [height]=\"Xmpp.draw.canvasHeight\"></canvas>\r\n    <div class=\"task-list zzj-scrollbar\" (scroll)=\"boxScroll($event)\">\r\n        <div class=\"toolHeader\">\r\n            <div class=\"uprow\" [style.width]=\"calendarWidth +'px'\">\r\n                <div *ngFor=\"let week of weeksArry\" class=\"weeks\" [style.width]=\"Xmpp.calendar.baseCellWidth*7 + 'px'\">\r\n                    {{week}}\r\n                </div>\r\n                <div class=\"clearfix\"></div>\r\n            </div>\r\n            <div class=\"downrow\" [style.width]=\"calendarWidth +'px'\">\r\n                <div class=\"weeksContent\" *ngIf=\"Xmpp.calendar.baseCellWidth > 15\">\r\n                    <div class=\"weeksArry\" *ngFor=\"let week of weeksArry\">\r\n                        <div class=\"weekday\" [style.width]=\"Xmpp.calendar.baseCellWidth + 'px'\" *ngFor=\"let day of Xmpp.calendar.weekDays\">{{day.dayText}}\r\n                        </div>\r\n                    </div>\r\n                </div>\r\n            </div>\r\n        </div>\r\n        <nz-spin [nzSize]=\"'large'\" *ngIf=\"loadingShow\"></nz-spin>\r\n        <div class=\"ganttBack\" [ngStyle]=\"{'width':calendarWidth+'px'}\"></div>\r\n    </div>\r\n</div>",
                styles: ["@charset \"UTF-8\";:host ::ng-deep .ant-menu-item-selected::after{opacity:0}::ng-deep .common-main-wrap .common-main-hd .common-bread-search{margin-top:0}a:active,a:focus,a:hover{outline:0;text-decoration:none}.zzj-scrollbar::-webkit-scrollbar{width:8px;height:6px;overflow:hidden}.zzj-scrollbar::-webkit-scrollbar-track{background-color:transparent}.zzj-scrollbar::-webkit-scrollbar-thumb{background-color:#acacac}.hidden-row{white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:100px}.hidden-row.long{max-width:150px}.hidden-row.longer{max-width:180px}.hidden-row.longest{max-width:210px}.hidden-row.auto{max-width:auto}.breadcrumb{height:70px;line-height:50px;font-size:14px;overflow:hidden}.breadcrumb .head-left{float:left}.breadcrumb .head-right{float:right}.common-bread-search{float:right;margin-top:10px;min-width:280px}.common-main-wrap{margin:30px}.common-main-wrap .common-main-hd{min-height:70px;padding-bottom:10px;line-height:50px;position:relative;z-index:5;overflow:hidden}.common-main-wrap .common-main-hd .common-bread-crumb{float:left;margin-top:23px}.common-main-wrap .common-main-hd .common-bread-search{float:right;margin-top:10px;min-width:280px}.common-main-wrap .common-main-hd .common-table-filter{float:right;margin-top:10px}@media screen and (max-width:1200px){.common-main-wrap .common-main-hd .common-bread-crumb,.common-main-wrap .common-main-hd .common-table-filter{float:none;display:block}}.common-main-wrap .common-main-cont{position:relative;height:auto}.common-table-wrap{border-radius:5px;overflow:hidden;background:#fff;box-shadow:0 0 8px #ddd}.common-table-wrap.auto .ant-table-wrapper{min-width:auto}.common-table-wrap .common-table-cont{max-height:660px;height:640px}.common-table-wrap .common-table-cont .ant-table-thead .ant-table-row th{background:-webkit-gradient(linear,left top,left bottom,from(#fff),to(#f8f8f8));background:linear-gradient(#fff,#f8f8f8);padding:10px}.common-table-wrap .ant-table-wrapper{overflow-x:auto;min-width:1300px}.common-table-wrap .common-pager{margin:10px;text-align:center;position:relative}.common-table-wrap .common-pager .common-pager-helper{float:left}.input-file{width:0;height:0;overflow:hidden;position:absolute;left:0;top:0;border:none;outline:0;box-shadow:none;opacity:0;cursor:pointer}.inner-layout,.outer-layout{height:60px;box-shadow:0 0 8px #ddd;position:relative;z-index:100;background:#fff;padding:0 25px}.inner-layout .inner-layout-left,.inner-layout .outer-layout-left,.outer-layout .inner-layout-left,.outer-layout .outer-layout-left{line-height:60px;float:left}.inner-layout .inner-layout-left img,.inner-layout .outer-layout-left img,.outer-layout .inner-layout-left img,.outer-layout .outer-layout-left img{vertical-align:middle}.inner-layout .inner-layout-right,.inner-layout .outer-layout-right,.outer-layout .inner-layout-right,.outer-layout .outer-layout-right{float:right;line-height:60px}.inner-layout .inner-layout-right a,.inner-layout .outer-layout-right a,.outer-layout .inner-layout-right a,.outer-layout .outer-layout-right a{color:#000}.inner-layout .inner-layout-right .inner-layout-right-user,.inner-layout .inner-layout-right .outer-layout-right-user,.inner-layout .outer-layout-right .inner-layout-right-user,.inner-layout .outer-layout-right .outer-layout-right-user,.outer-layout .inner-layout-right .inner-layout-right-user,.outer-layout .inner-layout-right .outer-layout-right-user,.outer-layout .outer-layout-right .inner-layout-right-user,.outer-layout .outer-layout-right .outer-layout-right-user{width:30px;height:30px}.common-table-status-green{color:#75bf03}.common-table-status-orange{color:orange}.common-table-status-red{color:red}.common-table-status-gray{color:#ccc}::ng-deep .ant-table-thead>tr>th{background-color:#fff}:host ::ng-deep .ant-tree li span.ant-tree-switcher.ant-tree-switcher_close .ant-tree-switcher-icon svg{width:18px;height:18px}:host ::ng-deep .ant-tree li span.ant-tree-switcher.ant-tree-switcher_open .ant-tree-switcher-icon svg{width:18px;height:18px}:host ::ng-deep .ant-table-fixed-header .ant-table-scroll .ant-table-header{overflow-y:hidden}::ng-deep.ant-input-affix-wrapper .ant-input-suffix{right:0}::ng-deep.ant-input-search.ant-input-search-enter-button>.ant-input{padding-right:46px}:host ::ng-deep .ant-table-body::-webkit-scrollbar{width:8px;height:6px;overflow:hidden}:host ::ng-deep .ant-table-body::-webkit-scrollbar-track{background-color:transparent}:host ::ng-deep .ant-table-body::-webkit-scrollbar-thumb{background-color:#acacac}::ng-deep .ant-modal-body{box-sizing:border-box}::ng-deep .ant-col-4{text-align:center}::ng-deep .ant-pagination-item-active,::ng-deep .ant-pagination-item-active:hover{background-color:#419fe8}::ng-deep .ant-pagination-item-active a,::ng-deep .ant-pagination-item-active:hover a{color:#fff}.ant-btn-primary:hover{background-color:#3d8fcd;border-color:#3d8fcd}.ant-btn-primary.disabled:hover,.ant-btn-primary[disabled],.ant-btn-primary[disabled]:hover{background-color:#f5f5f5;border-color:#d9d9d9}::ng-deep .ant-modal-close:hover{color:#419fe8!important}::ng-deep .ant-modal-confirm-error{top:300px}::ng-deep .ant-modal-confirm-confirm{top:300px}::ng-deep .ant-modal-confirm-btns .ant-btn:first-child{border-color:#d9d9d9;color:rgba(0,0,0,.65)}::ng-deep .ant-modal-confirm-btns .ant-btn:first-child:hover{color:#6cbef5;background-color:#fff;border-color:#6cbef5}.breadcrumb{color:#acacac}::ng-deep .ant-select-dropdown-menu::-webkit-scrollbar{width:8px;height:6px;overflow:hidden}::ng-deep .ant-select-dropdown-menu::-webkit-scrollbar-track{background-color:transparent}::ng-deep .ant-select-dropdown-menu::-webkit-scrollbar-thumb{background-color:#acacac}::ng-deep .ant-modal-header{padding-right:40px}::ng-deep .ant-table-placeholder{border-left:1px solid #e8e8e8;border-right:1px solid #e8e8e8}.ganttGanttBox{position:absolute;top:0;bottom:0;overflow:hidden;right:0;left:0}.ganttGanttBox canvas{position:absolute;left:0;right:0;top:50px;bottom:0;z-index:99}.ganttGanttBox #maskCanvas{z-index:100}.task-list{position:absolute;top:0;bottom:0;left:0;right:0;overflow:hidden;overflow-x:auto}.task-list .row{height:40px;border-bottom:1px solid #e5e5e5;background:#fff}.task-list .ganttBack{height:100%;position:absolute;top:0}.toolHeader{background:#fff;height:50px;color:#000;text-align:center}.toolHeader .uprow{height:50%;border-bottom:1px solid #e5e5e5;text-align:left}.toolHeader .uprow .weeks{height:100%;border-right:1px solid #e5e5e5;display:inline-block;text-align:center}.toolHeader .downrow{height:50%;border-bottom:1px solid #e5e5e5}.toolHeader .downrow .weeksContent{height:100%}.toolHeader .downrow .weeksArry{height:100%;float:left}.toolHeader .downrow .weekday{border-right:1px solid #e5e5e5;height:100%;float:left}:host ::ng-deep .ganttGanttBox .task-list nz-spin{position:absolute;top:50%;left:50%;z-index:3}:host ::ng-deep .ganttGanttBox .task-list .mask{position:absolute;top:0;left:0;right:0;bottom:0;background:rgba(0,0,0,.5);z-index:2}"]
            }] }
];
/** @nocollapse */
GanttBoxComponent.ctorParameters = () => [];
GanttBoxComponent.propDecorators = {
    canvasRef: [{ type: ViewChild, args: ['myCanvas', { static: false },] }],
    maskCanvas: [{ type: ViewChild, args: ['maskCanvas', { static: false },] }],
    canvasInfo: [{ type: Input }],
    Xmpp: [{ type: Input }]
};
if (false) {
    /** @type {?} */
    GanttBoxComponent.prototype.canvasRef;
    /** @type {?} */
    GanttBoxComponent.prototype.maskCanvas;
    /** @type {?} */
    GanttBoxComponent.prototype.canvasInfo;
    /** @type {?} */
    GanttBoxComponent.prototype.Xmpp;
    /** @type {?} */
    GanttBoxComponent.prototype.weeksArry;
    /** @type {?} */
    GanttBoxComponent.prototype.weeksWidth;
    /** @type {?} */
    GanttBoxComponent.prototype.calendarWidth;
    /** @type {?} */
    GanttBoxComponent.prototype.canvasWidth;
    /** @type {?} */
    GanttBoxComponent.prototype.loadingShow;
    /** @type {?} */
    GanttBoxComponent.prototype.cleanCanvas;
}

/**
 * @fileoverview added by tsickle
 * Generated from: lib/gantt-chart-service/gantt.config.ts
 * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
/** @type {?} */
const GanttSize = {
    // 底部编辑框高度
    bottomHeight: 300,
    // 每条任务的高度
    taskHeight: 36,
    // 日历一格的宽度
    calenderBaseWidth: 25
};
class GanttProjectModel {
    /**
     * @param {?} param
     */
    constructor(param) {
        this.calendars = [];
        this.dateFormat = [];
        (!isNullOrUndefined(param.id)) && (this.id = param.id);
        (!isNullOrUndefined(param.parentId)) && (this.parentId = param.parentId);
        (!isNullOrUndefined(param.calendars)) && (this.calendars = param.calendars);
        (!isNullOrUndefined(param.creationDate)) && (this.creationDate = param.creationDate);
        (!isNullOrUndefined(param.title)) && (this.title = param.title);
        (!isNullOrUndefined(param.company)) && (this.company = param.company);
        (!isNullOrUndefined(param.author)) && (this.author = param.author);
        (!isNullOrUndefined(param.startDate)) && (this.startDate = param.startDate);
        (!isNullOrUndefined(param.finishDate)) && (this.finishDate = param.finishDate);
        (!isNullOrUndefined(param.dateFormat)) && (this.dateFormat = param.dateFormat);
    }
    /**
     * @return {?}
     */
    toCreateJson() {
        return {
            Title: this.title,
            Company: this.company,
            Author: this.author,
            StartDate: moment(this.dateFormat[0]).toJSON(),
            FinishDate: moment(this.dateFormat[1]).toJSON()
        };
    }
}
if (false) {
    /** @type {?} */
    GanttProjectModel.prototype.id;
    /** @type {?} */
    GanttProjectModel.prototype.parentId;
    /** @type {?} */
    GanttProjectModel.prototype.calendars;
    /** @type {?} */
    GanttProjectModel.prototype.creationDate;
    /** @type {?} */
    GanttProjectModel.prototype.title;
    /** @type {?} */
    GanttProjectModel.prototype.company;
    /** @type {?} */
    GanttProjectModel.prototype.author;
    /** @type {?} */
    GanttProjectModel.prototype.startDate;
    /** @type {?} */
    GanttProjectModel.prototype.finishDate;
    /** @type {?} */
    GanttProjectModel.prototype.dateFormat;
}

/**
 * @fileoverview added by tsickle
 * Generated from: lib/gantt-chart.component.ts
 * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
class GanttComponent {
    // allTasks: GanttModel[] = [];
    /**
     * @param {?} elementRef
     * @param {?} ganttHelperService
     * @param {?} message
     * @param {?} PREVTYPE
     * @param {?} ganttRequestSev
     * @param {?} ele
     */
    constructor(elementRef, ganttHelperService, message, PREVTYPE, ganttRequestSev, ele) {
        this.elementRef = elementRef;
        this.ganttHelperService = ganttHelperService;
        this.message = message;
        this.PREVTYPE = PREVTYPE;
        this.ganttRequestSev = ganttRequestSev;
        this.ele = ele;
        this.Xmpp = new Xmpp();
        // @Input() mppExtendAttrs: IExtendAttr[] = [];
        // @Input() mppInfo: IMPPProject;
        // @Input() mppTasks: ITask[] = [];
        // @Input() mppOptions: IXmppOptions;
        this.leftPanel = {};
        this.rightPanel = {};
        this.mppShowBottomPanel = true;
        this.isFold = false;
        this.scrollListHeight = 0;
        this.resizeBarWith = 3;
        this.scrollBarWith = 6;
        this.rowHeight = 36;
        // public bottomHeight = 230;
        // 新建project
        // public isOkLoading = false;
        // public ganttListView = false;
        // public ganttList = [];
        this.searchTerms = new Subject();
        this.schedulePnlStyleModel = {
            width: 0
        };
        this.createMessage = (/**
         * @param {?} type
         * @param {?} text
         * @return {?}
         */
        (type, text) => {
            this.message.create(type, text);
        });
        this.rulesForNewProject = (/**
         * @param {?} newGanttModel
         * @return {?}
         */
        (newGanttModel) => {
            if (newGanttModel.ganttName === '') {
                this.createMessage('error', '项目名称不能为空');
                return false;
            }
            else if (!newGanttModel.startDate) {
                this.createMessage('error', '开始时间不能为空');
                return false;
            }
            else if (!newGanttModel.endDate) {
                this.createMessage('error', '结束时间不能为空');
                return false;
            }
            else {
                if (newGanttModel.exceptDate.length > 0) {
                    /** @type {?} */
                    const checkName = newGanttModel.exceptDate.findIndex((/**
                     * @param {?} element
                     * @return {?}
                     */
                    (element) => {
                        return element.name === '';
                    }));
                    /** @type {?} */
                    const checkDate = newGanttModel.exceptDate.findIndex((/**
                     * @param {?} element
                     * @return {?}
                     */
                    (element) => {
                        return element.startDate == null;
                    }));
                    if (checkName !== -1) {
                        this.createMessage('error', '例外日期名称不能为空');
                        return false;
                    }
                    else if (checkDate !== -1) {
                        this.createMessage('error', '例外日期不能为空');
                        return false;
                    }
                    else {
                        return true;
                    }
                }
                else {
                    return true;
                }
            }
        });
    }
    /**
     * @return {?}
     */
    get topPnlStyle() {
        /** @type {?} */
        const container = this.ganttContainer ? this.ganttContainer.nativeElement.clientHeight : 875;
        return {
            height: container + 'px'
        };
    }
    // public get bottomPnlStyle() {
    //   return {
    //     height: this.bottomHeight + 'px'
    //   };
    // }
    /**
     * @return {?}
     */
    get leftPnlStyle() {
        return {
            width: this.leftPanel.width + 'px'
        };
    }
    /**
     * @return {?}
     */
    get rightPnlStyle() {
        return {
            width: this.rightPanel.width + 'px'
        };
    }
    // public ngOnChanges(changes: SimpleChanges): void {
    //   if (changes.mppOptions.currentValue) {
    //     // Gantt.column.setColumn(mppOptions.columns);
    //     // Gantt.draw.color = mppOptions.color;
    //     // setTimeout(() => {
    //     //   // 进度模块宽度
    //     //   this.schedulePnlStyleModel.width = this.container.nativeElement.clientWidth - 2;
    //     //   // 任务列表面板宽度
    //     //   this.leftPanel.width = (this.schedulePnlStyleModel.width - this.resizeBarWith - this.scrollBarWith) / 2;
    //     //   this.rightPanel.width = this.leftPanel.width;
    //     //   // this.taskPanel.panelWidth = this.leftPanel.width;
    //     //   // 进度canvas面板宽度
    //     //   // this.ganttPanel.panelWidth = this.leftPanel.width;
    //     //   Gantt.draw.canvasWidth = this.leftPanel.width;
    //     //   // 设置假task列表高度，用以获取虚拟滚动条
    //     //   if (Gantt.allTasks) {
    //     //     this.scrollListHeight = Gantt.allTasks.length * this.rowHeight + this.scrollBarWith;
    //     //   }
    //     //   this.initTasks();
    //     // }, 1000);
    //   }
    // }
    /**
     * @param {?} mppOptions
     * @return {?}
     */
    initProject(mppOptions) {
        // 处理列
        this.Xmpp.column.setColumn(mppOptions.columns);
        // 颜色
        this.Xmpp.draw.color = mppOptions.color;
        // 拓展属性
        this.Xmpp.mpp.mppExtendAttrs = mppOptions.mppExtendAttrs;
        // 项目信息
        this.Xmpp.mpp.mppInfo = mppOptions.mppInfo;
        /** @type {?} */
        let rightScrollBarWith = 0;
        this.Xmpp.globalLoading = true;
        if (mppOptions.size.drawTaskHeight) {
            this.Xmpp.draw.lineHeight = mppOptions.size.drawTaskHeight;
        }
        if (mppOptions.size.drawActualLineHeight) {
            this.Xmpp.draw.actualLineHeight = mppOptions.size.drawActualLineHeight;
        }
        // 获取进度表的task列表
        // mppOptions.mppInfo.tasks = mppOptions.mppTasks;
        // this.getExceptions(ganttInfo);
        this.Xmpp.mpp.setMppInfo(mppOptions.mppInfo);
        this.Xmpp.mpp.setMppTasks(mppOptions.mppTasks);
        return new Promise((/**
         * @param {?} resolve
         * @param {?} reject
         * @return {?}
         */
        (resolve, reject) => {
            setTimeout((/**
             * @return {?}
             */
            () => {
                /** @type {?} */
                const containerHeight = this.container.nativeElement.clientHeight;
                // 设置假task列表高度，用以获取虚拟滚动条
                if (mppOptions.mppTasks.length > 0) {
                    /** @type {?} */
                    const scrollListHeight = this.getScrollHeight();
                    if (scrollListHeight < containerHeight - 50) {
                        rightScrollBarWith = 0;
                    }
                    else {
                        rightScrollBarWith = this.scrollBarWith;
                    }
                    this.scrollListHeight = scrollListHeight;
                }
                // 进度模块宽度
                this.schedulePnlStyleModel.width = this.container.nativeElement.clientWidth;
                // 任务列表面板宽度
                this.leftPanel.width = (this.schedulePnlStyleModel.width - this.resizeBarWith - rightScrollBarWith) / 2;
                this.rightPanel.width = this.leftPanel.width;
                // this.taskPanel.panelWidth = this.leftPanel.width;
                // 进度canvas面板宽度
                // this.ganttPanel.panelWidth = this.leftPanel.width;
                this.Xmpp.draw.canvasWidth = this.leftPanel.width;
                // const height = this.taskbox.nativeElement.clientHeight;
                this.Xmpp.task.showTaskLength = Math.floor((containerHeight - 50) / GanttSize.taskHeight);
                // 50：日历高度； 20：底部滚动条高度
                this.Xmpp.draw.canvasHeight = containerHeight - 50 - this.scrollBarWith;
                // 渲染列表和canvas
                this.Xmpp.render();
                this.Xmpp.globalLoading = false;
                resolve(this.Xmpp.allTasks);
            }), 500);
        }));
    }
    /**
     * @param {?} e
     * @return {?}
     */
    outerResizeCallback(e) {
        this.leftPanel.width = this.schedulePnlStyleModel.width - this.resizeBarWith - this.scrollBarWith - this.rightPanel.width;
    }
    /**
     * @return {?}
     */
    updateTasks() {
        this.Xmpp.render();
    }
    /**
     * @return {?}
     */
    ngOnInit() {
        // const ganttId = this.activatedRoute.snapshot.queryParams.ganttId;
        this.searchTerms
            .pipe(
        // 请求防抖 300毫秒
        debounceTime(500), distinctUntilChanged())
            .subscribe((/**
         * @param {?} term
         * @return {?}
         */
        term => {
            this.Xmpp.draw.updateCanvasInfo();
        }));
    }
    /**
     * 加载表格数据
     * @param {?} mppOptions
     * @return {?}
     */
    initTasks(mppOptions) {
        return __awaiter(this, void 0, void 0, function* () {
            // this.detailView = false;
        });
    }
    // /**
    //  * 选择mpp文件
    //  * @param event
    //  */
    // public selectFile(event: any) {
    //   event = event || window.event;
    //   if (!event || !event.target || !event.target.files) {
    //     return;
    //   }
    //   const files = event.target.files;
    //   this.uploadForm.uploadMMP = files[0];
    // }
    // /**
    //  * 上传mpp
    //  */
    // public async uploadMPPHandle() {
    //   if (this.uploadForm.uploadTitle === '') {
    //     this.message.error('请输入进度名称');
    //     return;
    //   }
    //   if (!this.uploadForm.uploadMMP) {
    //     this.message.error('请选择导入的project文件');
    //     return;
    //   }
    //   this.isOkLoading = true;
    //   console.log(this.uploadForm);
    //   const mpp = await this.ganttRequestSev.uploadMMP(this.uploadForm);
    //   if (mpp) {
    //     console.log(mpp);
    //     // if (mpp) {
    //     //   this.initTasks(mpp.id);
    //     // }
    //     this.message.success('导入成功');
    //     this.uploadForm = {
    //       uploadMMP: null,
    //       uploadTitle: ''
    //     };
    //   } else {
    //     this.message.error('导入失败');
    //   }
    //   this.isOkLoading = false;
    //   this.uploadProjectView = false;
    // }
    /**
     * 下载xml文件
     * @return {?}
     */
    downloadXML() {
        return __awaiter(this, void 0, void 0, function* () {
            if (this.Xmpp.mpp.mppInfo) {
                /** @type {?} */
                const id = this.Xmpp.mpp.mppInfo.id;
                /** @type {?} */
                const url = `http://localhost:5004/mpp/api/v1/mpp/export/${id}`;
                //FileHelper.download('Project', url);
            }
            else {
                this.message.error('未打开项目，请先打开一个项目');
            }
        });
    }
    /**
     * 获取表格列表
     * @param {?} gantt
     * @return {?}
     */
    getGanttTaskList(gantt) {
        return __awaiter(this, void 0, void 0, function* () {
            /** @type {?} */
            const res = yield this.ganttRequestSev.getTasksList(gantt.id);
            gantt.tasks = res;
        });
    }
    /**
     * @param {?} $event
     * @return {?}
     */
    resizeCallback($event) {
        // this.ganttPanel.panelWidth = this.rightPanel.width;
        this.Xmpp.draw.canvasWidth = this.rightPanel.width;
        this.ganttPanel.changeWidth();
    }
    // 进度模块
    /**
     * @return {?}
     */
    get schedulePnlStyle() {
        return {
            width: this.schedulePnlStyleModel.width + 'px',
            height: '100%'
        };
    }
    /**
     * @param {?} e
     * @param {?=} model
     * @return {?}
     */
    dragstartHandler(e, model) {
        e.stopPropagation();
        e.preventDefault();
        // console.log(e);
        /** @type {?} */
        let startX = e.clientX;
        /** @type {?} */
        const dragHandler = (/**
         * @param {?} ev
         * @return {?}
         */
        (ev) => {
            // console.log(e)
            ev.stopPropagation();
            ev.preventDefault();
            this.schedulePnlStyleModel.width -= (e.clientX - startX);
            startX = e.clientX;
        });
        console.log(this.schedulePnlStyleModel);
        /** @type {?} */
        const dragendHandler = (/**
         * @return {?}
         */
        () => {
            document.documentElement.removeEventListener('mousemove', dragHandler, false);
            document.documentElement.removeEventListener('mouseup', dragendHandler, false);
        });
        document.documentElement.addEventListener('mouseup', dragendHandler, false);
        document.documentElement.addEventListener('mousemove', dragHandler, false);
    }
    /**
     * @return {?}
     */
    ngAfterViewInit() {
        // setTimeout(() => {
        //   this.refreshViewHeight();
        // }, 100);
    }
    /**
     * 计算进度列表和canvas面板的高度
     * 触发方式：改变窗口大小、关闭底部panel
     * @return {?}
     */
    refreshViewHeight() {
        // 50: toolbar高度
        /** @type {?} */
        const height = this.taskbox.nativeElement.clientHeight;
        this.Xmpp.task.showTaskLength = Math.ceil((height - 50) / GanttSize.taskHeight);
        // 50：日历高度； 20：底部滚动条高度
        this.Xmpp.draw.canvasHeight = this.taskbox.nativeElement.clientHeight - 50 - this.scrollBarWith;
        // 计算showTask
        this.Xmpp.task.updateTaskHandle();
        // 最后更新 canvas和日历(update canvas)
        this.Xmpp.draw.updateCanvasInfo();
    }
    // public switchBottom(type: string) {
    //   switch (type) {
    //     case 'down':
    //       this.bottomHeight = 40;
    //       this.isFold = true;
    //       setTimeout(() => {
    //         this.refreshViewHeight();
    //       }, 500);
    //       break;
    //     case 'up':
    //       this.bottomHeight = 300;
    //       this.isFold = false;
    //       setTimeout(() => {
    //         this.refreshViewHeight();
    //       }, 500);
    //       break;
    //     default:
    //       break;
    //   }
    // }
    /**
     * @return {?}
     */
    getScrollHeight() {
        /** @type {?} */
        let scrollListHeight = 0;
        if (this.Xmpp.allTasks) {
            // 36： 一个task的高度
            // 加50： 是最后一个输入行的高度
            scrollListHeight = this.Xmpp.task.getAllTaskAfterFold().length * (this.rowHeight + 1);
        }
        return scrollListHeight;
    }
    // 窗口缩放
    /**
     * @param {?} event
     * @return {?}
     */
    windowResize(event) {
        this.refreshViewHeight();
        // tslint:disable-next-line:max-line-length
        this.rightPanel.width = this.container.nativeElement.clientWidth - this.leftPanel.width - this.resizeBarWith - this.scrollBarWith;
    }
    /**
     * 滚动条滚动事件
     * @param {?} e any
     * @return {?}
     */
    scrollHandler(e) {
        /** @type {?} */
        let IsDown = false;
        /** @type {?} */
        const scrollTop = e.target.scrollTop;
        scrollTop > this.lastScrollTop ? IsDown = true : IsDown = false;
        if (IsDown) {
            /** @type {?} */
            const targetTop = Math.ceil(scrollTop / this.rowHeight) * this.rowHeight;
            e.target.scrollTop = targetTop;
        }
        else {
            /** @type {?} */
            const targetTop = Math.floor(scrollTop / this.rowHeight) * this.rowHeight;
            e.target.scrollTop = targetTop;
        }
        this.lastScrollTop = scrollTop;
        /** @type {?} */
        const starIndex = Math.floor(this.lastScrollTop / this.rowHeight);
        // 更新tasklist和canvas
        this.Xmpp.task.startTaskIndex = starIndex;
        this.Xmpp.task.updateTaskHandle();
        this.Xmpp.draw.updateCanvasInfo();
        // 防抖
        // this.searchTerms.next(scrollTop.toString());
    }
    /**
     * 鼠标滚动事件
     * @param {?} e
     * 控制假滚动条滚动
     * @return {?}
     */
    mousewheelhandler(e) {
        /** @type {?} */
        const o = this.elementRef.nativeElement.querySelector('.scrollBar');
        o.scrollTop = o.scrollTop + e.deltaY / 100 * this.rowHeight;
    }
    /**
     * @param {?} e
     * @return {?}
     */
    newTaskBlur(e) {
        // console.log(this.elementRef.nativeElement.querySelector('.scrollBar').scrollHeight)
        /** @type {?} */
        const o = this.elementRef.nativeElement.querySelector('.scrollBar');
        o.scrollTop = this.lastScrollTop + 36;
        // this.mousewheelhandler(e)
    }
    // /**
    //  * 创建gantt
    //  */
    // public createNewGantt() {
    //   this.ganttCreateView = true;
    //   const companyName = JSON.parse(window.localStorage.getItem('project')).companyName;
    //   const name = JSON.parse(window.localStorage.getItem('APDInfo')).userName;
    //   this.createForm = new GanttProjectModel({
    //     dateFormat: null,
    //     author: name,
    //     company: companyName
    //   });
    // }
    /**
     * 新建项目
     * @param {?} group
     * @return {?}
     */
    changeStartDate(group) {
        /** @type {?} */
        const startDate = moment(group.startDate).unix();
        /** @type {?} */
        const endDate = moment(group.endDate).unix();
        if (!group.endDate) {
            group.endDate = startDate;
            return;
        }
        else {
            if (startDate > endDate) {
                group.endDate = startDate;
                return;
            }
        }
    }
    // public async submitCreateGantt() {
    //   const createForm = this.createForm.toCreateJson();
    //   console.log(createForm);
    //   if (!createForm) {
    //     this.message.error('进度名称不能为空');
    //     return;
    //   }
    //   const ganttId = await this.ganttRequestSev.postGantt(createForm);
    //   if (ganttId) {
    //     this.message.success('创建成功');
    //     // const projectId = JSON.parse(window.localStorage.getItem('project')).id;
    //     // this.router.navigate([`/inner/project/${projectId}/model`], { queryParams: { ganttId } });
    //     this.ganttCreateView = false;
    //     // this.messageService.send({ opt: "addTask" })
    //   } else {
    //     this.message.error('创建失败');
    //   }
    // }
    /**
     * 获取项目列表
     * @param {?} group
     * @return {?}
     */
    // public async showGanttList() {
    //   const list = await this.ganttRequestSev.getGanttList();
    //   this.ganttList = [];
    //   list.forEach((element) => {
    //     this.ganttList.push({
    //       id: element.id,
    //       parentId: element.parentId,
    //       calendars: element.calendars,
    //       creationDate: element.creationDate,
    //       title: element.title,
    //       startDate: element.startDate,
    //       finishDate: element.finishDate
    //     });
    //   });
    //   console.log(this.ganttList);
    //   this.ganttListView = true;
    // }
    changeEndDate(group) {
        /** @type {?} */
        const startDate = moment(group.startDate).unix();
        /** @type {?} */
        const endDate = moment(group.endDate).unix();
        if (!group.startDate) {
            group.startDate = endDate;
            return;
        }
        else {
            if (endDate < startDate) {
                group.startDate = endDate;
                return;
            }
        }
    }
    /**
     * @param {?} index
     * @param {?} exceptDate
     * @return {?}
     */
    deletDate(index, exceptDate) {
        exceptDate.splice(index, 1);
    }
    /**
     * @param {?} exceptDate
     * @return {?}
     */
    addDate(exceptDate) {
        exceptDate.push({ name: '', startDate: null, endDate: null });
    }
}
GanttComponent.decorators = [
    { type: Component, args: [{
                selector: 'app-gantt-chart',
                template: "<div class=\"progress\" #container>\r\n    <div class=\"maskLoading\" *ngIf=\"Xmpp.globalLoading\">\r\n        <nz-spin [nzSize]=\"'large'\"></nz-spin>\r\n    </div>\r\n    <div class=\"progress-item\" [ngStyle]=\"schedulePnlStyle\">\r\n        <!-- \u8FDB\u5EA6\u6A21\u5757 -->\r\n        <div class=\"gantt-container\" #ganttContainer>\r\n            <!-- <div class=\"header-box\">\r\n                <app-tool-bar [Xmpp]=\"Xmpp\" *ngIf=\"Xmpp.showTools\"></app-tool-bar>\r\n            </div> -->\r\n            <div class=\"gantt-panel\">\r\n                <!-- <div class=\"top-box\" [ngStyle]=\"topPnlStyle\"> -->\r\n                <div class=\"handlerArea\">\r\n                    <div class=\"task-box\" #taskbox [ngStyle]=\"leftPnlStyle\" (mousewheel)=\"mousewheelhandler($event)\">\r\n                        <app-task-box (newTaskBlur)=\"newTaskBlur($event)\" [Xmpp]=\"Xmpp\" #taskPanel></app-task-box>\r\n                    </div>\r\n                    <div class=\"separate\">\r\n                        <app-resize-bar (resizeCallback)=\"resizeCallback($event)\" [lazyMove]=\"true\" [mode]=\"'between-hor'\" [before]=\"leftPanel\" [after]=\"rightPanel\">\r\n                        </app-resize-bar>\r\n                    </div>\r\n                    <div class=\"gantt-box\" [ngStyle]=\"rightPnlStyle\" (mousewheel)=\"mousewheelhandler($event)\">\r\n                        <app-gantt-box #ganttPanel [Xmpp]=\"Xmpp\" [canvasInfo]=\"Xmpp.draw.canvasInfo\">\r\n                        </app-gantt-box>\r\n                    </div>\r\n                </div>\r\n                <div class=\"scrollBar zzj-scrollbar\" (scroll)=\"scrollHandler($event)\">\r\n                    <div class=\"scrollList\" [style.height]=\"scrollListHeight + 'px'\"></div>\r\n                </div>\r\n                <!-- </div> -->\r\n                <!-- \u5E95\u90E8\u6A21\u5757 -->\r\n                <!-- <div class=\"bottom-box\" [ngStyle]=\"bottomPnlStyle\">\r\n                    <i class=\"anticon anticon-caret-down fold\" (click)=\"switchBottom('down')\" *ngIf=\"!isFold\"></i>\r\n                    <i class=\"anticon anticon-caret-up fold\" (click)=\"switchBottom('up')\" *ngIf=\"isFold\"></i>\r\n                    <div class=\"tools\" style=\"margin-bottom: 12px\">\r\n                        <app-tool-bar></app-tool-bar>\r\n                    </div>\r\n                    <ng-container *ngIf=\"GanttInfo.currentGantt?.detailView && GanttInfo.currentTask\">\r\n                        <div class=\"row\">\r\n                            <p class=\"item\">\r\n                                <label for=\"\">\u4EFB\u52A1\u540D\u79F0\uFF1A</label>\r\n                                <span>\r\n                                  <input nz-input [(ngModel)]=\"GanttInfo.currentTask.taskName\">\r\n                                </span>\r\n                            </p>\r\n                            <p class=\"item edit\" (click)=\"ganttHelperService.showSettings(GanttInfo.currentTask)\">\r\n                                <label style=\"width: 60px\" for=\"\">\u524D\u7F6E\u4EFB\u52A1\uFF1A</label>\r\n                                <span>{{ganttHelperService.showRelation(GanttInfo.currentTask)}}</span>\r\n                            </p>\r\n                        </div>\r\n                        <div class=\"row\">\r\n                            <p class=\"item\">\r\n                                <label for=\"\">\u8BA1\u5212\u5F00\u59CB\u65F6\u95F4\uFF1A</label>\r\n                                <span>\r\n                                  <nz-date-picker [(ngModel)]=\"GanttInfo.currentTask.startDate\" (ngModelChange)=\"updateTasks()\"\r\n                                    [nzAllowClear]=\"false\"></nz-date-picker>\r\n                                </span>\r\n                            </p>\r\n                            <p class=\"item\">\r\n                                <label for=\"\">\u8BA1\u5212\u5B8C\u6210\u65F6\u95F4\uFF1A</label>\r\n                                <span>\r\n                                  <nz-date-picker [(ngModel)]=\"GanttInfo.currentTask.endDate\" (ngModelChange)=\"updateTasks()  \"\r\n                                    [nzAllowClear]=\"false\"></nz-date-picker>\r\n                                </span>\r\n                            </p>\r\n                            <p class=\"item edit\" (click)=\"ganttHelperService.showSettings(GanttInfo.currentTask)\">\r\n                                <label style=\"width: 60px\" for=\"\">\u8BA1\u5212\u5DE5\u671F\uFF1A</label>\r\n                                <span>{{GanttInfo.currentTask.showDuration}}</span>\r\n                            </p>\r\n                        </div>\r\n                        <div class=\"row\">\r\n                            <p class=\"item\">\r\n                                <label for=\"\">\u5B9E\u9645\u5F00\u59CB\u65F6\u95F4\uFF1A</label>\r\n                                <span>\r\n                                  <nz-date-picker [(ngModel)]=\"GanttInfo.currentTask.actualStartDate\" (ngModelChange)=\"updateTasks()\"\r\n                                    [nzAllowClear]=\"false\"></nz-date-picker>\r\n                                </span>\r\n                            </p>\r\n                            <p class=\"item\">\r\n                                <label for=\"\">\u5B9E\u9645\u5B8C\u6210\u65F6\u95F4\uFF1A</label>\r\n                                <span>\r\n                                  <nz-date-picker [(ngModel)]=\"GanttInfo.currentTask.actualEndDate\" (ngModelChange)=\"updateTasks()  \"\r\n                                    [nzAllowClear]=\"false\"></nz-date-picker>\r\n                                </span>\r\n                            </p>\r\n                            <p class=\"item edit\">\r\n                                <label style=\"width: 60px\" for=\"\">\u5B9E\u9645\u5DE5\u671F\uFF1A</label>\r\n                                <span>{{GanttInfo.currentTask.actualDuration}}</span>\r\n                            </p>\r\n                        </div>\r\n                    </ng-container>\r\n                </div> -->\r\n            </div>\r\n        </div>\r\n        <!-- \u8FDB\u5EA6\u5BB9\u5668 -->\r\n    </div>\r\n    <!-- <div class=\"separate\">\r\n        <app-resize-bar [lazyMove]=\"true\" [mode]=\"'single-width'\" [single]=\"schedulePnlStyleModel\" (resizeCallback)=\"outerResizeCallback($event)\">\r\n        </app-resize-bar>\r\n    </div> -->\r\n</div>\r\n\r\n<!-- <nz-modal class=\"settingModal\" [nzVisible]=\"ganttHelperService.settingVisible\" [nzTitle]=\"'\u8BBE\u7F6E'\" [nzContent]=\"settingContent\" (nzOnCancel)=\"ganttHelperService.settingCancel()\" (nzOnOk)=\"ganttHelperService.settingSave()\">\r\n    <ng-template #settingContent>\r\n        <div class=\"content\" *ngIf=\"ganttHelperService.editInfo\">\r\n            <div class=\"name\">\r\n                <span>\u4EFB\u52A1\u540D\u79F0\uFF1A</span>\r\n                <input nz-input [(ngModel)]=\"ganttHelperService.editInfo.taskName\">\r\n            </div>\r\n            <div class=\"duration\">\r\n                <span>\u5DE5\u671F\uFF1A</span>\r\n                <nz-input-number [(ngModel)]=\"ganttHelperService.editInfo.showDuration\" [nzSize]=\"'small'\" [nzMin]=\"1\" [nzStep]=\"1\"></nz-input-number>\r\n            </div>\r\n            <p class=\"line\">\r\n                <span>\u524D\u7F6E\u4EFB\u52A1</span>\r\n            </p>\r\n            <div class=\"relation\" *ngIf=\"GanttInfo.allTasks.length > 0 \">\r\n                <div class=\"title\">\r\n                    <span>\u6807\u8BC6</span>\r\n                    <span>\u4EFB\u52A1\u540D</span>\r\n                    <span>\u7C7B\u578B</span>\r\n                    <span>\u5EF6\u9694\u5929\u6570</span>\r\n                </div>\r\n                <div class=\"row\" *ngFor=\"let item of ganttHelperService.editInfo.relations;let i = index\">\r\n                    <ng-container *ngIf=\"item.isDelete == 0\">\r\n                        <div class=\"item\">\r\n                            <nz-input-number [(ngModel)]=\"item.prevId\" [nzSize]=\"'small'\" [nzMin]=\"1\" [nzMax]=\"GanttInfo.allTasks.length\" [nzStep]=\"1\"></nz-input-number>\r\n                        </div>\r\n                        <div class=\"item\">\r\n                            <nz-select style=\"width: 160px;\" placeholder=\"'\u9009\u62E9\u4E00\u4E2A\u4EFB\u52A1'\" [(ngModel)]=\"item.prevId\" [nzShowSearch]=\"true\">\r\n                                <nz-option *ngFor=\"let option of GanttInfo.allTasks\" [nzLabel]=\"option.id+':'+option.taskName\" [nzValue]=\"option.id\">\r\n                                </nz-option>\r\n                            </nz-select>\r\n                        </div>\r\n                        <div class=\"item\">\r\n                            <nz-select [(ngModel)]=\"item.relation\" placeholder=\"'choose option'\">\r\n                                <nz-option [nzLabel]=\"'\u5B8C\u6210-\u5B8C\u6210(FF)'\" [nzValue]=\"PREVTYPE.FF\"></nz-option>\r\n                                <nz-option [nzLabel]=\"'\u5B8C\u6210-\u5F00\u59CB(FS)'\" [nzValue]=\"PREVTYPE.FS\"></nz-option>\r\n                                <nz-option [nzLabel]=\"'\u5F00\u59CB-\u5B8C\u6210(SF)'\" [nzValue]=\"PREVTYPE.SF\"></nz-option>\r\n                                <nz-option [nzLabel]=\"'\u5F00\u59CB-\u5F00\u59CB(SS)'\" [nzValue]=\"PREVTYPE.SS\"></nz-option>\r\n                            </nz-select>\r\n                        </div>\r\n                        <div class=\"item\">\r\n                            <nz-input-number [(ngModel)]=\"item.delay\" [nzSize]=\"'small'\" [nzMin]=\"0\" [nzStep]=\"1\"></nz-input-number>\r\n                        </div>\r\n                        <i class=\"anticon anticon-delete\" (click)=\"ganttHelperService.deleteRelation(i)\"></i>\r\n                        <i *ngIf=\"i == ganttHelperService.editInfo.relations.length-1\" class=\"anticon anticon-plus\" (click)=\"ganttHelperService.addRelation()\"></i>\r\n                    </ng-container>\r\n                </div>\r\n            </div>\r\n        </div>\r\n    </ng-template>\r\n</nz-modal> -->",
                styles: ["@charset \"UTF-8\";:host ::ng-deep .ant-menu-item-selected::after{opacity:0}::ng-deep .common-main-wrap .common-main-hd .common-bread-search{margin-top:0}a:active,a:focus,a:hover{outline:0;text-decoration:none}.zzj-scrollbar::-webkit-scrollbar{width:8px;height:6px;overflow:hidden}.zzj-scrollbar::-webkit-scrollbar-track{background-color:transparent}.zzj-scrollbar::-webkit-scrollbar-thumb{background-color:#acacac}.hidden-row{white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:100px}.hidden-row.long{max-width:150px}.hidden-row.longer{max-width:180px}.hidden-row.longest{max-width:210px}.hidden-row.auto{max-width:auto}.breadcrumb{height:70px;line-height:50px;font-size:14px;overflow:hidden}.breadcrumb .head-left{float:left}.breadcrumb .head-right{float:right}.common-bread-search{float:right;margin-top:10px;min-width:280px}.common-main-wrap{margin:30px}.common-main-wrap .common-main-hd{min-height:70px;padding-bottom:10px;line-height:50px;position:relative;z-index:5;overflow:hidden}.common-main-wrap .common-main-hd .common-bread-crumb{float:left;margin-top:23px}.common-main-wrap .common-main-hd .common-bread-search{float:right;margin-top:10px;min-width:280px}.common-main-wrap .common-main-hd .common-table-filter{float:right;margin-top:10px}@media screen and (max-width:1200px){.common-main-wrap .common-main-hd .common-bread-crumb,.common-main-wrap .common-main-hd .common-table-filter{float:none;display:block}}.common-main-wrap .common-main-cont{position:relative;height:auto}.common-table-wrap{border-radius:5px;overflow:hidden;background:#fff;box-shadow:0 0 8px #ddd}.common-table-wrap.auto .ant-table-wrapper{min-width:auto}.common-table-wrap .common-table-cont{max-height:660px;height:640px}.common-table-wrap .common-table-cont .ant-table-thead .ant-table-row th{background:-webkit-gradient(linear,left top,left bottom,from(#fff),to(#f8f8f8));background:linear-gradient(#fff,#f8f8f8);padding:10px}.common-table-wrap .ant-table-wrapper{overflow-x:auto;min-width:1300px}.common-table-wrap .common-pager{margin:10px;text-align:center;position:relative}.common-table-wrap .common-pager .common-pager-helper{float:left}.input-file{width:0;height:0;overflow:hidden;position:absolute;left:0;top:0;border:none;outline:0;box-shadow:none;opacity:0;cursor:pointer}.inner-layout,.outer-layout{height:60px;box-shadow:0 0 8px #ddd;position:relative;z-index:100;background:#fff;padding:0 25px}.inner-layout .inner-layout-left,.inner-layout .outer-layout-left,.outer-layout .inner-layout-left,.outer-layout .outer-layout-left{line-height:60px;float:left}.inner-layout .inner-layout-left img,.inner-layout .outer-layout-left img,.outer-layout .inner-layout-left img,.outer-layout .outer-layout-left img{vertical-align:middle}.inner-layout .inner-layout-right,.inner-layout .outer-layout-right,.outer-layout .inner-layout-right,.outer-layout .outer-layout-right{float:right;line-height:60px}.inner-layout .inner-layout-right a,.inner-layout .outer-layout-right a,.outer-layout .inner-layout-right a,.outer-layout .outer-layout-right a{color:#000}.inner-layout .inner-layout-right .inner-layout-right-user,.inner-layout .inner-layout-right .outer-layout-right-user,.inner-layout .outer-layout-right .inner-layout-right-user,.inner-layout .outer-layout-right .outer-layout-right-user,.outer-layout .inner-layout-right .inner-layout-right-user,.outer-layout .inner-layout-right .outer-layout-right-user,.outer-layout .outer-layout-right .inner-layout-right-user,.outer-layout .outer-layout-right .outer-layout-right-user{width:30px;height:30px}.common-table-status-green{color:#75bf03}.common-table-status-orange{color:orange}.common-table-status-red{color:red}.common-table-status-gray{color:#ccc}::ng-deep .ant-table-thead>tr>th{background-color:#fff}:host ::ng-deep .ant-tree li span.ant-tree-switcher.ant-tree-switcher_close .ant-tree-switcher-icon svg{width:18px;height:18px}:host ::ng-deep .ant-tree li span.ant-tree-switcher.ant-tree-switcher_open .ant-tree-switcher-icon svg{width:18px;height:18px}:host ::ng-deep .ant-table-fixed-header .ant-table-scroll .ant-table-header{overflow-y:hidden}::ng-deep.ant-input-affix-wrapper .ant-input-suffix{right:0}::ng-deep.ant-input-search.ant-input-search-enter-button>.ant-input{padding-right:46px}:host ::ng-deep .ant-table-body::-webkit-scrollbar{width:8px;height:6px;overflow:hidden}:host ::ng-deep .ant-table-body::-webkit-scrollbar-track{background-color:transparent}:host ::ng-deep .ant-table-body::-webkit-scrollbar-thumb{background-color:#acacac}::ng-deep .ant-modal-body{box-sizing:border-box}::ng-deep .ant-col-4{text-align:center}::ng-deep .ant-pagination-item-active,::ng-deep .ant-pagination-item-active:hover{background-color:#419fe8}::ng-deep .ant-pagination-item-active a,::ng-deep .ant-pagination-item-active:hover a{color:#fff}.ant-btn-primary:hover{background-color:#3d8fcd;border-color:#3d8fcd}.ant-btn-primary.disabled:hover,.ant-btn-primary[disabled],.ant-btn-primary[disabled]:hover{background-color:#f5f5f5;border-color:#d9d9d9}::ng-deep .ant-modal-close:hover{color:#419fe8!important}::ng-deep .ant-modal-confirm-error{top:300px}::ng-deep .ant-modal-confirm-confirm{top:300px}::ng-deep .ant-modal-confirm-btns .ant-btn:first-child{border-color:#d9d9d9;color:rgba(0,0,0,.65)}::ng-deep .ant-modal-confirm-btns .ant-btn:first-child:hover{color:#6cbef5;background-color:#fff;border-color:#6cbef5}.breadcrumb{color:#acacac}::ng-deep .ant-select-dropdown-menu::-webkit-scrollbar{width:8px;height:6px;overflow:hidden}::ng-deep .ant-select-dropdown-menu::-webkit-scrollbar-track{background-color:transparent}::ng-deep .ant-select-dropdown-menu::-webkit-scrollbar-thumb{background-color:#acacac}::ng-deep .ant-modal-header{padding-right:40px}::ng-deep .ant-table-placeholder{border-left:1px solid #e8e8e8;border-right:1px solid #e8e8e8}.progress{height:100%;background-color:#fff;z-index:802;border:1px solid #333}.progress .maskLoading{background:rgba(233,233,233,.5);position:absolute;z-index:999;left:0;right:0;bottom:0;top:0}.progress .maskLoading .ant-spin-nested-loading{position:absolute;left:50%;top:50%;-webkit-transform:translateX(-50%) translateY(-50%);transform:translateX(-50%) translateY(-50%)}.progress .btn-container{position:absolute;left:-40px;display:-webkit-box;display:flex;-webkit-box-pack:center;justify-content:center;-webkit-box-align:center;align-items:center;background-color:#333;opacity:.36;width:40px;height:40px;cursor:pointer}.progress .progress-item{height:100%;-webkit-transition:.3s;transition:.3s;font-size:12px}::ng-deep .gantt-container{height:100%;width:100%;overflow:hidden}::ng-deep .gantt-container .header-box{width:100%;height:40px;background:#f9f9f9;line-height:40px;border-bottom:1px solid #e5e5e5}::ng-deep .gantt-container .header-box .button{float:right;padding:0 10px;color:#419fe8;border-radius:3px;cursor:pointer}::ng-deep .gantt-container .header-box .title{padding:0 20px;max-width:300px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;float:left}::ng-deep .gantt-container .header-box .anticon-menu-unfold{cursor:pointer}::ng-deep .gantt-container .gantt-panel{height:100%;overflow:hidden;position:relative}::ng-deep .gantt-container .top-box{overflow:hidden;position:relative}::ng-deep .gantt-container .bottom-box{position:relative;-webkit-transition:.5s;transition:.5s}::ng-deep .gantt-container .bottom-box .fold{display:inline-block;position:absolute;right:20px;font-size:22px;cursor:pointer;top:10px;z-index:9}::ng-deep .gantt-container .bottom-box p.item{display:inline-block;margin:10px 48px 10px 16px}::ng-deep .gantt-container .bottom-box p.item label{display:inline-block;width:90px}::ng-deep .gantt-container .bottom-box p.item input{width:170px}::ng-deep .gantt-container .bottom-box p.edit:hover{cursor:pointer;color:#419fe8}::ng-deep .dialog-newProgress .top-form .row{margin:10px 0}::ng-deep .dialog-newProgress .expect-day .list{max-height:200px;overflow:hidden;overflow-y:auto;padding:0 20px;margin-bottom:20px}::ng-deep .dialog-newProgress .expect-day .list .row{margin:10px 0}::ng-deep .dialog-newProgress .expect-day .list .row input{width:120px;margin-right:10px}::ng-deep .dialog-newProgress .expect-day .list .row .ant-calendar-picker{width:120px}::ng-deep .dialog-newProgress .expect-weekday .list{padding:0 20px}::ng-deep .dialog-newProgress .expect-weekday .row{margin:10px 0}::ng-deep .dialog-newProgress p.title{padding:15px 15px 8px;font-size:14px;border-bottom:1px solid #d9d9d9;color:#199d89;margin-bottom:20px}:host ::ng-deep .gantt-mask{position:absolute;top:40px;width:100%;height:100%;background:rgba(233,233,233,.5);z-index:9;text-align:center}:host ::ng-deep .gantt-mask nz-spin{position:absolute;top:50%;-webkit-transform:translateY(-50%);transform:translateY(-50%)}:host ::ng-deep .gantt-mask .warnning{text-align:center;color:#419fe8;margin-top:200px;font-size:24px}.handlerArea{position:absolute;left:0;bottom:0;top:0;right:0}.separate{width:2px;height:100%;float:left;cursor:col-resize;z-index:801;background:#ccc;-webkit-transition:.3s;transition:.3s}.task-box{float:left;position:relative;height:100%}.gantt-box{position:relative;float:left;height:100%;overflow:hidden}.scrollBar{width:20px;position:absolute;top:50px;bottom:0;right:0;overflow:hidden;overflow-y:scroll;z-index:1}::ng-deep .settingModal .ant-modal-content{width:700px}::ng-deep .settingModal .name{display:inline-block;margin-left:10px}::ng-deep .settingModal .name input{width:200px}::ng-deep .settingModal .duration{display:inline-block;margin-left:20px}::ng-deep .settingModal .duration nz-input-number{width:100px}::ng-deep .settingModal .line{margin-top:10px;position:relative;height:20px;border-bottom:1px solid #419fe8;margin-bottom:10px;width:100%}::ng-deep .settingModal .line span{position:absolute;color:#419fe8;padding:10px;background:#fff;left:50%;-webkit-transform:translateX(-50%);transform:translateX(-50%)}::ng-deep .settingModal .relation{margin-top:15px}::ng-deep .settingModal .relation .row{width:100%;height:40px;line-height:40px;padding:0 10px}::ng-deep .settingModal .relation .title{padding:10px}::ng-deep .settingModal .relation .title span{display:inline-block;text-align:center}::ng-deep .settingModal .relation .title span:nth-child(1){width:80px}::ng-deep .settingModal .relation .title span:nth-child(2){width:180px}::ng-deep .settingModal .relation .title span:nth-child(3){width:130px}::ng-deep .settingModal .relation .title span:nth-child(4){width:100px}::ng-deep .settingModal .relation .row .item{display:inline-block}::ng-deep .settingModal .relation .row .item:nth-child(1){width:80px}::ng-deep .settingModal .relation .row .item:nth-child(2){width:180px;text-align:center}::ng-deep .settingModal .relation .row .item:nth-child(2) nz-select{width:160px}::ng-deep .settingModal .relation .row .item:nth-child(3){width:160px;text-align:center}::ng-deep .settingModal .relation .row .item:nth-child(4){width:100px}::ng-deep .settingModal .relation .anticon-delete{margin-left:5px}::ng-deep .settingModal .ant-input-number-input{height:auto}:host ::ng-deep .ant-input{height:30px;font-size:12px}::ng-deep .ganttList .ant-modal-footer{display:none}.listContent{max-height:500px;overflow:auto}.listContent .item{padding:10px;border-bottom:1px solid #e8e8e8;cursor:pointer}.listContent .item span{display:inline-block;width:360px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.listContent .item span:hover{color:#419fe8}.listContent .item i{color:#419fe8;padding:0 10px;cursor:pointer}.listContent .item:hover{background:rgba(204,204,204,.24)}::ng-deep .createGanttModal .row .title{border-left:3px solid #2dbdc5;padding:3px 10px;margin:10px 0;display:block}"]
            }] }
];
/** @nocollapse */
GanttComponent.ctorParameters = () => [
    { type: ElementRef },
    { type: GanttHelperService },
    { type: NzMessageService },
    { type: undefined, decorators: [{ type: Inject, args: ['PREVTYPE',] }] },
    { type: GanttRequestService },
    { type: ElementRef }
];
GanttComponent.propDecorators = {
    taskbox: [{ type: ViewChild, args: ['taskbox', { static: false },] }],
    ganttContainer: [{ type: ViewChild, args: ['ganttContainer', { static: false },] }],
    container: [{ type: ViewChild, args: ['container', { static: false },] }],
    ganttPanel: [{ type: ViewChild, args: [GanttBoxComponent, { static: false },] }],
    ganttId: [{ type: Input }],
    mppShowBottomPanel: [{ type: Input }]
};
if (false) {
    /** @type {?} */
    GanttComponent.prototype.taskbox;
    /** @type {?} */
    GanttComponent.prototype.ganttContainer;
    /** @type {?} */
    GanttComponent.prototype.container;
    /** @type {?} */
    GanttComponent.prototype.ganttPanel;
    /** @type {?} */
    GanttComponent.prototype.Xmpp;
    /** @type {?} */
    GanttComponent.prototype.leftPanel;
    /** @type {?} */
    GanttComponent.prototype.rightPanel;
    /** @type {?} */
    GanttComponent.prototype.ganttId;
    /** @type {?} */
    GanttComponent.prototype.mppShowBottomPanel;
    /** @type {?} */
    GanttComponent.prototype.isFold;
    /** @type {?} */
    GanttComponent.prototype.lastScrollTop;
    /** @type {?} */
    GanttComponent.prototype.scrollListHeight;
    /** @type {?} */
    GanttComponent.prototype.resizeBarWith;
    /** @type {?} */
    GanttComponent.prototype.scrollBarWith;
    /** @type {?} */
    GanttComponent.prototype.rowHeight;
    /**
     * @type {?}
     * @private
     */
    GanttComponent.prototype.searchTerms;
    /** @type {?} */
    GanttComponent.prototype.schedulePnlStyleModel;
    /** @type {?} */
    GanttComponent.prototype.createMessage;
    /** @type {?} */
    GanttComponent.prototype.rulesForNewProject;
    /**
     * @type {?}
     * @private
     */
    GanttComponent.prototype.elementRef;
    /** @type {?} */
    GanttComponent.prototype.ganttHelperService;
    /**
     * @type {?}
     * @private
     */
    GanttComponent.prototype.message;
    /** @type {?} */
    GanttComponent.prototype.PREVTYPE;
    /**
     * @type {?}
     * @private
     */
    GanttComponent.prototype.ganttRequestSev;
    /** @type {?} */
    GanttComponent.prototype.ele;
}

/**
 * @fileoverview added by tsickle
 * Generated from: lib/tool-bar/tool-bar.component.ts
 * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
class ToolBarComponent {
    /**
     * @param {?} _notification
     * @param {?} confirmServ
     * @param {?} message
     * @param {?} ganttHelpServ
     * @param {?} ganttRequestSev
     */
    constructor(_notification, confirmServ, message, ganttHelpServ, ganttRequestSev) {
        this._notification = _notification;
        this.confirmServ = confirmServ;
        this.message = message;
        this.ganttHelpServ = ganttHelpServ;
        this.ganttRequestSev = ganttRequestSev;
        this.ganttChecked = false;
        this._percent = 0;
        this.simulate = false;
        this.playdisabled = false;
        this.pausedisabled = true;
        this.startDate = null;
        this.showStart = null;
        this.endDate = null;
        this.finishDate = null;
        this.diffDate = null;
        this.simulateVisible = false;
        this.calenderVisible = false;
        this.currentStep = 0;
        this.uuids = [];
        this.playTasks = [];
        this.createNotification = (/**
         * @param {?} type
         * @param {?} title
         * @param {?} message
         * @return {?}
         */
        (type, title, message) => {
            this._notification.create(type, title, message);
        });
        // public render() {
        //   let currentStep = this.currentStep;
        //   let isPlanning = false;
        //   if (isPlanning) {
        //     let uuidItem = this.playTasks[currentStep - 1];
        //     let uuid = uuidItem.uuid;
        //     let finishAt = uuidItem.finishAt;
        //     this.ganttApi.renderUuid(uuid);
        //     // 该构件完成时间
        //     this.finishDate = moment.unix(finishAt).format('YYYY-MM-DD');
        //     // 构件时差
        //     this.diffDate = moment.unix(finishAt).diff(moment(this.startDate), 'days');
        //   } else {
        //     let task = this.playTasks[currentStep - 1];
        //     let symbol = task.symbol;
        //     let endDate = task.endDate;
        //     this.ganttApi.renderUuidsFromTask(symbol);
        //     // 该构件完成时间
        //     this.finishDate = moment(endDate).format('YYYY-MM-DD');
        //     // 构件时差
        //     this.diffDate = moment(endDate).diff(moment(this.startDate), 'days');
        //   }
        // }
        /*
          * 完成时间不能大于开始时间的
          * 禁用开始时间前的日期
           */
        this.startValueChange = (/**
         * @return {?}
         */
        () => {
            if (this.startDate > this.endDate) {
                this.endDate = null;
            }
        });
        this.endValueChange = (/**
         * @return {?}
         */
        () => {
            if (this.startDate > this.endDate) {
                this.startDate = null;
            }
        });
        this.disabledEndDate = (/**
         * @param {?} endValue
         * @return {?}
         */
        (endValue) => {
            if (!endValue || !this.startDate) {
                return false;
            }
            return endValue.getTime() <= this.startDate.getTime();
        });
        this.showModal = (/**
         * @return {?}
         */
        () => {
            this.simulateVisible = true;
        });
        // public simulateOk = () => {
        //   console.log('点击了确定');
        //   this.reload();
        //   this.getAllplayTasks();
        //   this.Xmpp.extraInfo.detailView = false;
        //   this.showStart = moment(this.startDate).format('YYYY-MM-DD');
        // }
        this.simulateCancel = (/**
         * @param {?} e
         * @return {?}
         */
        (e) => {
            this.simulateVisible = false;
        });
    }
    /**
     * @return {?}
     */
    ngOnInit() {
        // this.selector = Neon.getSelector();
    }
    /**
     * @param {?} value
     * @return {?}
     */
    transformDate(value) {
        if (typeof value === 'number') {
            return moment.unix(value);
        }
        else {
            return value;
        }
    }
    // 日历设置
    /**
     * @return {?}
     */
    calenderShow() {
        this.calenderVisible = true;
    }
    /**
     * @return {?}
     */
    calenderCancel() {
        this.calenderVisible = false;
    }
    /**
     * @param {?} group
     * @return {?}
     */
    changeStartDate(group) {
        /** @type {?} */
        const startDate = moment(group.startDate);
        /** @type {?} */
        const endDate = moment(group.endDate);
        if (!group.endDate) {
            group.endDate = startDate;
            return;
        }
        else {
            if (startDate.isAfter(endDate)) {
                group.endDate = startDate;
                return;
            }
        }
    }
    /**
     * @param {?} group
     * @return {?}
     */
    changeEndDate(group) {
        /** @type {?} */
        const startDate = moment(group.startDate);
        /** @type {?} */
        const endDate = moment(group.endDate);
        if (!group.startDate) {
            group.startDate = endDate;
            return;
        }
        else {
            if (endDate.isBefore(startDate)) {
                group.startDate = endDate;
                return;
            }
        }
    }
    // }
    // 保存allTasks
    /**
     * @param {?} type
     * @return {?}
     */
    saveTasks(type) {
        // this.ganttHelpServ.saveTasksHanle(this.Xmpp, type);
    }
    // 跟踪横道图
    /**
     * @param {?} e
     * @return {?}
     */
    ganttTracking(e) {
    }
    // 插入新的task
    /**
     * @return {?}
     */
    addTask() {
        this.Xmpp.task.addTaskHandle();
    }
    // 删除选中元素
    /**
     * @return {?}
     */
    deleteTask() {
        /** @type {?} */
        const that = this;
        this.confirmServ.confirm({
            nzTitle: '是否要删除选中任务及其所有的子任务？？',
            nzContent: '点击确认将删除选中任务及其所有的子任务，点击取消将不删除任何任务。',
            /**
             * @return {?}
             */
            nzOnOk() {
                that.deleteTaskHandle();
            }
        });
    }
    /**
     * @return {?}
     */
    deleteTaskHandle() {
        /** @type {?} */
        const deleteTasks = [];
        /** @type {?} */
        const search = (/**
         * @param {?} element
         * @return {?}
         */
        (element) => {
            if (element.childTaskID && element.childTaskID.length > 0) {
                element.childTaskID.forEach((/**
                 * @param {?} childID
                 * @return {?}
                 */
                (childID) => {
                    if (deleteTasks.indexOf(childID) === -1) {
                        deleteTasks.push(childID);
                    }
                    search(this.Xmpp.allTasks[childID - 1]);
                }));
            }
            else {
                return;
            }
        });
        for (const element of this.Xmpp.allTasks) {
            /** @type {?} */
            const id = element.id;
            if (element.isSelected) {
                deleteTasks.push(id);
                search(element);
                // allTasks.splice(id - 1, 1)
            }
        }
        // 将删除的task放在this.alreadyDeleteTasks中
        for (const id of deleteTasks) {
            /** @type {?} */
            const finder = this.Xmpp.allTasks.find((/**
             * @param {?} task
             * @return {?}
             */
            (task) => {
                return task.id === id;
            }));
            if (finder.sqId) {
                // this.ganttHelpServ.alreadyDeleteTasks.push(finder.sqId);
            }
        }
        this.Xmpp.task.deleteTaskHandle(deleteTasks);
    }
    // 降级
    /**
     * @return {?}
     */
    depressTaskLevel() {
        /** @type {?} */
        const tasks = this.checkSelectNumber();
        this.Xmpp.task.depressTaskLevel(tasks);
    }
    // //升级
    /**
     * @return {?}
     */
    promoteTaskLevel() {
        /** @type {?} */
        const tasks = this.checkSelectNumber();
        this.Xmpp.task.promoteTaskLevel(tasks);
    }
    /**
     * @return {?}
     */
    checkSelectNumber() {
        /** @type {?} */
        const selectNumber = [];
        this.Xmpp.allTasks.forEach((/**
         * @param {?} element
         * @return {?}
         */
        (element) => {
            if (element.isSelected) {
                selectNumber.push(element);
            }
        }));
        return selectNumber;
    }
    // // 新增里程碑
    /**
     * @return {?}
     */
    addMilepost() {
        this.Xmpp.task.addTaskHandle(new XmppTask({ isMilepost: true }));
    }
    /**
       * 绑定构件
       * @param isFirstBind
       */
    // public async bingdingGUID(isFirstBind: boolean) {
    //   let uuids: string[];
    //   const selectTasks = this.checkSelectNumber();
    //   const task = selectTasks[0];
    //   const ganttId = this.Xmpp.currentGantt.id;
    //   const extend = await this.ganttRequestSev.getTaskAttrs(ganttId, task.sqId);
    //   const finder = extend.find((attr) => {
    //     return attr.fieldID === EXTENDATTRS.binding.FieldID;
    //   });
    //   if (isFirstBind) {
    //     uuids = this.ganttApi.getSelectedUUIDs();
    //   } else {
    //     // 追加构件
    //     uuids = this.ganttApi.addOver();
    //   }
    //   if (uuids.length === 0) {
    //     this.createNotification('error', '请选择构件', 'small');
    //     return;
    //   }
    //   if (selectTasks.length !== 1) {
    //     this.createNotification('error', '请选择单个任务绑定构件', 'small');
    //   }
    //   const bingUUids = [];
    //   // selectTasks[0].bindings = uuid;
    //   uuids.forEach((uid) => {
    //     bingUUids.push({
    //       uuid: gum.btoa(uid),
    //       isFinished: false
    //     });
    //   });
    //   if (!task.extendAttrs) {
    //     task.extendAttrs = {};
    //     task.extendAttrs.uuids = bingUUids;
    //     const param = {
    //       FieldID: EXTENDATTRS.binding.FieldID,
    //       Value: JSON.stringify(task.extendAttrs)
    //     };
    //     const res = this.ganttRequestSev.bindTaskExtendedAttribute(ganttId, task.sqId, param);
    //     if (res) {
    //       this.message.success('绑定成功');
    //     } else {
    //       this.message.success('绑定失败');
    //     }
    //   } else {
    //     task.extendAttrs.uuids = bingUUids;
    //     const param = {
    //       Value: JSON.stringify(task.extendAttrs)
    //     };
    //     const res = await this.ganttRequestSev.updateExtendedAttrbute(ganttId, task.sqId, finder.id, param);
    //     if (res) {
    //       this.message.success('更新绑定成功');
    //     } else {
    //       this.message.success('更新绑定失败');
    //     }
    //   }
    //   // let symbol = selectTasks[0].symbol;
    //   // let extendAttrs = Gantt.mpp.extraAttrMap.get(symbol);
    //   // Object.assign(extendAttrs, { bindings });
    //   // Gantt.mpp.extraAttrMap.set(symbol, extendAttrs);
    // }
    /**
     * 解绑构件
     * @return {?}
     */
    // public async unbingdingGUID() {
    //   const selectTasks = this.checkSelectNumber();
    //   const ganttId = this.Xmpp.currentGantt.id;
    //   for (let i = 0; i < selectTasks.length; i++) {
    //     const task: GanttModel = selectTasks[i];
    //     if (!task.extendAttrs) {
    //       continue;
    //     }
    //     if (!task.extendAttrs.uuids) {
    //       return;
    //     }
    //     delete task.extendAttrs.uuids;
    //     const param = {
    //       Value: JSON.stringify(task.extendAttrs)
    //     };
    //     const res = await this.ganttRequestSev.updateExtendedAttrbute(ganttId, task.sqId, task.extendAttrsId, param);
    //     if (res) {
    //       this.message.success('解绑成功');
    //     } else {
    //       this.message.success('解绑失败');
    //     }
    //   }
    //   // this.modelService.selectFloorShow()
    //   this.ganttApi.clearSelectedUUIDS();
    // }
    ///////////////////////////////////// 施工模拟 ////////////////////////////////////
    // 退出模拟
    simulateHide() {
        this.simulate = false;
        // this.modelService.selectFloorShow()
    }
    /**
     * @return {?}
     */
    refresh() {
        this.Xmpp.render();
    }
    /**
     * @return {?}
     */
    compress() {
        /** @type {?} */
        const baseWidth = GanttSize.calenderBaseWidth;
        if (baseWidth > 5) {
            GanttSize.calenderBaseWidth = baseWidth - 5;
            this.Xmpp.draw.updateCanvasInfo();
        }
        else {
            this.message.error('不能再缩小了');
        }
    }
    /**
     * @return {?}
     */
    expand() {
        /** @type {?} */
        const baseWidth = GanttSize.calenderBaseWidth;
        if (baseWidth < 30) {
            GanttSize.calenderBaseWidth = baseWidth + 5;
            this.Xmpp.draw.updateCanvasInfo();
        }
        else {
            this.message.error('不能再放大了');
        }
    }
    /**
     * @return {?}
     */
    reload() {
        this._percent = 0;
        this.currentStep = 0;
        this.playTasks = [];
        this.playdisabled = false;
        this.pausedisabled = true;
    }
    /**
     * @return {?}
     */
    increase() {
        if (this.interval) {
            clearInterval(this.interval);
        }
        console.log(this.playTasks);
        if (this.currentStep < this.playTasks.length) {
            this._percent = this._percent + this.perStep;
            this.currentStep++;
            // this.render();
        }
        else {
            this._percent = 100;
        }
        this.playdisabled = false;
        this.pausedisabled = true;
    }
    /**
     * @return {?}
     */
    decline() {
        if (this.interval) {
            clearInterval(this.interval);
        }
        if (this.currentStep > 0) {
            this.remove();
            this._percent = this._percent - this.perStep;
            this.currentStep--;
        }
        else {
            this.currentStep = 0;
            this._percent = 0;
        }
        this.playdisabled = true;
        this.pausedisabled = false;
    }
    // public play() {
    //   this.playdisabled = true;
    //   this.pausedisabled = false;
    //   // let isPlanning = this.ganttPermission.isPlanning;
    //   this.interval = setInterval(() => {
    //     if (this.currentStep < this.playTasks.length) {
    //       this._percent = this._percent + this.perStep;
    //       this.currentStep++;
    //       this.render();
    //     } else {
    //       this._percent = 100;
    //       this.currentStep = this.playTasks.length;
    //       clearInterval(this.interval);
    //       return;
    //     }
    //   }, 1000);
    // }
    /**
     * @return {?}
     */
    pause() {
        if (this.interval) {
            clearInterval(this.interval);
            this.pausedisabled = true;
            this.playdisabled = false;
        }
    }
    /**
     * @return {?}
     */
    remove() {
        /** @type {?} */
        const currentStep = this.currentStep;
        /** @type {?} */
        const isPlanning = false;
        if (isPlanning) {
            /** @type {?} */
            const uuidItem = this.playTasks[currentStep - 1];
            /** @type {?} */
            const finishAt = uuidItem.finishAt;
            // 该构件完成时间
            this.finishDate = moment.unix(finishAt).format('YYYY-MM-DD');
            // 构件时差
            this.diffDate = moment.unix(finishAt).diff(moment(this.startDate), 'days');
        }
        else {
            /** @type {?} */
            const task = this.playTasks[currentStep - 1];
            /** @type {?} */
            const symbol = task.symbol;
            /** @type {?} */
            const endDate = task.endDate;
            // 该构件完成时间
            this.finishDate = moment(endDate).format('YYYY-MM-DD');
            // 构件时差
            this.diffDate = moment(endDate).diff(moment(this.startDate), 'days');
        }
    }
    /**
     * @return {?}
     */
    getAllplayTasks() {
        /** @type {?} */
        const allTasks = this.Xmpp.allTasks;
        /** @type {?} */
        const isPlanning = false;
        /** @type {?} */
        const playTasks = [];
        /** @type {?} */
        const startUnix = moment(this.startDate).hours(0).minutes(0).seconds(0).unix();
        /** @type {?} */
        const endUnix = moment(this.endDate).hours(11).minutes(59).seconds(59).unix();
        if (isPlanning) {
            for (let i = 0; i < allTasks.length; i++) {
                /** @type {?} */
                const element = allTasks[i];
                /** @type {?} */
                const bindings = allTasks[i].bindings;
                if (bindings && bindings.length > 0) {
                    bindings.forEach((/**
                     * @param {?} item
                     * @return {?}
                     */
                    (item) => {
                        /** @type {?} */
                        const finishAt = item.finishAt;
                        /** @type {?} */
                        const uuid = item.uuid;
                        if (playTasks.indexOf(item) === -1 && finishAt && finishAt >= moment(this.startDate).unix() && finishAt <= moment(this.endDate).unix()) {
                            playTasks.push(item);
                        }
                    }));
                }
            }
            if (playTasks.length > 0) {
                this.playTasks = playTasks;
                this.simulateVisible = false;
                this.perStep = Number((100 / playTasks.length).toFixed(2));
                // 显示进度条
                this.simulate = true;
            }
            else {
                this.createNotification('error', '请检查', '所选时间段没有绑定的构件');
                return;
            }
        }
        else {
            // 拼装playTasks
            /** @type {?} */
            const playTasks = [];
            /** @type {?} */
            const minStart = startUnix;
            for (let i = 0; i < allTasks.length; i++) {
                /** @type {?} */
                const element = allTasks[i];
                /** @type {?} */
                const task_Start = element.startDate ? moment(element.startDate).unix() : 0;
                /** @type {?} */
                const task_End = element.startDate ? moment(element.endDate).unix() : 0;
                if (task_Start && task_End &&
                    task_Start >= startUnix &&
                    task_End <= endUnix &&
                    element.bindings && element.bindings.length > 0) {
                    playTasks.push(element);
                }
            }
            // playTasks按计划开始时间排序
            for (let i = 0; i < playTasks.length; i++) {
                for (let j = i + 1; j < playTasks.length; j++) {
                    if (moment(playTasks[i].startDate).unix() > moment(playTasks[j].startDate).unix()) {
                        /** @type {?} */
                        const tmp = playTasks[i];
                        playTasks[i] = playTasks[j];
                        playTasks[j] = tmp;
                    }
                }
            }
            if (playTasks.length > 0) {
                this.playTasks = playTasks;
                this.simulateVisible = false;
                this.perStep = Math.ceil(100 / this.playTasks.length);
                // 显示进度条
                this.simulate = true;
            }
            else {
                this.createNotification('error', '请检查', '所选时间段没有绑定的构件');
                return;
            }
        }
        // this.uuids = uuids;
    }
}
ToolBarComponent.decorators = [
    { type: Component, args: [{
                selector: 'app-tool-bar',
                template: "<div class=\"toolbar\">\r\n    <div class=\"buttonGroup\">\r\n\r\n        <div class=\"icon-group\">\r\n            <!-- <nz-tooltip [nzTitle]=\"'\u65E5\u5386\u8BBE\u7F6E'\" [nzPlacement]=\"'top'\" (click)=\"calenderShow()\">\r\n        <i nz-tooltip class=\"fa fa-calendar\"></i>\r\n        <span nz-tooltip class=\"sp sp_calendar\"></span>\r\n      </nz-tooltip> -->\r\n            <nz-tooltip [nzTitle]=\"'\u63D2\u5165\u884C'\" [nzPlacement]=\"'top'\" (click)=\"addTask()\">\r\n                <span nz-tooltip class=\"sp sp_add\"></span>\r\n                <!-- <i nz-tooltip class=\"anticon anticon-file-add\"></i> -->\r\n            </nz-tooltip>\r\n            <nz-tooltip [nzTitle]=\"'\u5220\u9664\u884C'\" [nzPlacement]=\"'top'\" (click)=\"deleteTask()\">\r\n                <span nz-tooltip class=\"sp sp_delete\"></span>\r\n                <!-- <i nz-tooltip class=\"anticon anticon-delete\"></i> -->\r\n            </nz-tooltip>\r\n            <nz-tooltip [nzTitle]=\"'\u6DFB\u52A0\u91CC\u7A0B\u7891'\" [nzPlacement]=\"'top'\" (click)=\"addMilepost()\">\r\n                <span nz-tooltip class=\"sp sp_milestone\"></span>\r\n                <!-- <i nz-tooltip class=\"anticon anticon-environment\"></i> -->\r\n            </nz-tooltip>\r\n            <nz-tooltip [nzTitle]=\"'\u5347\u7EA7'\" [nzPlacement]=\"'top'\" (click)='promoteTaskLevel()'>\r\n                <span nz-tooltip class=\"sp sp_upLevel\"></span>\r\n                <!-- <i nz-tooltip class=\"anticon anticon-caret-up\"></i> -->\r\n            </nz-tooltip>\r\n            <nz-tooltip [nzTitle]=\"'\u964D\u7EA7'\" [nzPlacement]=\"'top'\" (click)=\"depressTaskLevel()\">\r\n                <span nz-tooltip class=\"sp sp_downLevel\"></span>\r\n                <!-- <i nz-tooltip class=\"anticon anticon-caret-down\"></i> -->\r\n            </nz-tooltip>\r\n            <!-- <nz-tooltip [nzTitle]=\"'\u7ED1\u5B9A\u6784\u4EF6'\" [nzPlacement]=\"'top'\" (click)=\"bingdingGUID(true)\">\r\n        <span nz-tooltip class=\"sp sp_bind\"></span>\r\n      </nz-tooltip>\r\n      <nz-tooltip [nzTitle]=\"'\u89E3\u7ED1\u6784\u4EF6'\" [nzPlacement]=\"'top'\" (click)=\"unbingdingGUID()\">\r\n        <span nz-tooltip class=\"sp sp_unbind\"></span>\r\n      </nz-tooltip> -->\r\n            <!-- <nz-tooltip [nzTitle]=\"'\u8FFD\u52A0\u6784\u4EF6'\" [nzPlacement]=\"'top'\" (click)=\"addBingdingGUID($event)\">\r\n        <span nz-tooltip class=\"sp sp_addbind\"></span>\r\n      </nz-tooltip>\r\n      <nz-tooltip [nzTitle]=\"'\u786E\u8BA4\u8FFD\u52A0'\" [nzPlacement]=\"'top'\" (click)=\"configBingdingGUID($event)\">\r\n        <span nz-tooltip class=\"sp sp_configBind\"></span>\r\n      </nz-tooltip> -->\r\n            <!-- <nz-tooltip [nzTitle]=\"'\u65BD\u5DE5\u6A21\u62DF'\" [nzPlacement]=\"'top'\" (click)=\"showModal()\">\r\n        <span nz-tooltip class=\"sp sp_play\"></span>\r\n      </nz-tooltip> -->\r\n            <nz-tooltip [nzTitle]=\"'\u4FDD\u5B58'\" [nzPlacement]=\"'top'\" (click)=\"saveTasks('save')\">\r\n                <span nz-tooltip class=\"sp sp_save\"></span>\r\n                <!-- <i nz-tooltip class=\"fa fa-floppy-o\"></i> -->\r\n            </nz-tooltip>\r\n            <nz-tooltip [nzTitle]=\"'\u5237\u65B0\u6A2A\u9053\u56FE'\" [nzPlacement]=\"'top'\" (click)=\"refresh()\">\r\n                <span nz-tooltip class=\"sp sp_refresh\"></span>\r\n                <!-- <i nz-tooltip class=\"fa fa-refresh\"></i> -->\r\n            </nz-tooltip>\r\n            <!-- <nz-tooltip [nzTitle]=\"'\u7F29\u5C0F\u6A2A\u9053\u56FE'\" [nzPlacement]=\"'top'\" (click)=\"compress()\">\r\n        <span nz-tooltip class=\"sp sp_compress\"></span>\r\n      </nz-tooltip>\r\n      <nz-tooltip [nzTitle]=\"'\u653E\u5927\u6A2A\u9053\u56FE'\" [nzPlacement]=\"'top'\" (click)=\"expand()\">\r\n        <span nz-tooltip class=\"sp sp_expand\"></span>\r\n      </nz-tooltip> -->\r\n\r\n\r\n            <!-- <nz-tooltip [nzTitle]=\"'\u63D0\u4EA4'\" [nzPlacement]=\"'top'\">\r\n        <i nz-tooltip class=\"fa fa-floppy-o\"></i>\r\n      </nz-tooltip> -->\r\n        </div>\r\n        <!-- <div class=\"button-group group1\">\r\n      <button nz-button [nzType]=\"'default'\" [nzSize]=\"small\" (click)=\"calenderShow()\">\r\n        <i class=\"anticon anticon-calendar\"></i>\r\n        <span>\u65E5\u5386\u8BBE\u7F6E</span>\r\n      </button>\r\n      <button nz-button [nzType]=\"'default'\" [nzSize]=\"small\" (click)=\"addTask($event)\">\r\n        <i class=\"anticon anticon-file-add\"></i>\r\n        <span>\u63D2\u5165\u884C</span>\r\n      </button>\r\n      <button nz-button [nzType]=\"'default'\" [nzSize]=\"small\" (click)=\"deleteTask($event)\">\r\n        <i class=\"anticon anticon-delete\"></i>\r\n        <span>\u5220\u9664\u884C</span>\r\n      </button>\r\n    </div>\r\n    <div class=\"button-group group2\">\r\n      <button nz-button [nzType]=\"'default'\" [nzSize]=\"small\" (click)=\"addMilepost($event)\">\r\n        <i class=\"anticon anticon-environment\"></i>\r\n        <span>\u6DFB\u52A0\u91CC\u7A0B\u7891</span>\r\n      </button>\r\n      <button nz-button [nzType]=\"'default'\" [nzSize]=\"small\" (click)='promoteTaskLevel($event)'>\r\n        <i class=\"anticon anticon-caret-up\"></i>\r\n        <span>\u5347\u7EA7</span>\r\n      </button>\r\n      <button nz-button [nzType]=\"'default'\" [nzSize]=\"small\" (click)=\"depressTaskLevel($event)\">\r\n        <i class=\"anticon anticon-caret-down\"></i>\r\n        <span>\u964D\u7EA7</span>\r\n      </button>\r\n      <button nz-button [nzType]=\"'default'\" [nzSize]=\"small\" (click)=\"bingdingGUID($event)\">\r\n        <i class=\"anticon anticon-pushpin\"></i>\r\n        <span>\u7ED1\u5B9A\u6784\u4EF6</span>\r\n      </button>\r\n      <button nz-button [nzType]=\"'default'\" [nzSize]=\"small\" (click)=\"unbingdingGUID($event)\">\r\n        <i class=\"anticon anticon-pushpin-o\"></i>\r\n        <span>\u89E3\u7ED1\u6784\u4EF6</span>\r\n      </button>\r\n      <button nz-button [nzType]=\"'default'\" [nzSize]=\"small\" (click)=\"addBingdingGUID($event)\">\r\n        <i class=\"anticon anticon-pushpin-o\"></i>\r\n        <span>\u8FFD\u52A0\u6784\u4EF6</span>\r\n      </button>\r\n      <button nz-button [nzType]=\"'default'\" [nzSize]=\"small\" (click)=\"configBingdingGUID($event)\">\r\n        <i class=\"anticon anticon-pushpin-o\"></i>\r\n        <span>\u786E\u8BA4\u8FFD\u52A0</span>\r\n      </button>\r\n    </div>\r\n    <div class=\"button-group group3\">\r\n      <button nz-button [nzType]=\"'primary'\" [nzSize]=\"small\" (click)=\"saveTasks('save')\">\r\n        <i class=\"anticon anticon-save\"></i>\r\n        <span>\u4FDD\u5B58</span>\r\n      </button>\r\n      <button nz-button [nzType]=\"'primary'\" [nzSize]=\"small\" (click)=\"saveTasks('submit')\">\r\n        <i class=\"anticon anticon-check\"></i>\r\n        <span>\u63D0\u4EA4\u5BA1\u6838</span>\r\n      </button>\r\n      <button nz-button [nzType]=\"'primary'\" [nzSize]=\"small\">\r\n        <i class=\"anticon anticon-upload\"></i>\r\n        <span>\u5BFC\u5165\u8BA1\u5212</span>\r\n      </button>\r\n      <button nz-button [nzType]=\"'primary'\" [nzSize]=\"small\">\r\n        <i class=\"anticon anticon-download\"></i>\r\n        <span>\u5BFC\u51FA\u8BA1\u5212</span>\r\n      </button>\r\n      <button nz-button [nzType]=\"'primary'\" [nzSize]=\"small\" (click)=\"showModal()\">\r\n        <i class=\"anticon anticon-video-camera\"></i>\r\n        <span>\u65BD\u5DE5\u6A21\u62DF</span>\r\n      </button>\r\n    </div> -->\r\n        <div class=\"clearfix\"></div>\r\n    </div>\r\n    <!-- <div *ngIf=\"simulate\" class=\"simulate\" style=\"height:46px;padding: 10px 30px 0px 10px;\">\r\n    <nz-progress [nzPercent]=\"_percent\"></nz-progress>\r\n    <nz-button-group class=\"button-group\">\r\n      <button nz-button [nzType]=\"'ghost'\" (click)=\"decline()\">\r\n        <i class=\"anticon anticon-backward\"></i>\r\n      </button>\r\n      <button nz-button [nzType]=\"'ghost'\" (click)=\"play()\" [disabled]=\"playdisabled\">\r\n        <i class=\"anticon anticon-caret-right\"></i>\r\n      </button>\r\n      <button nz-button [nzType]=\"'ghost'\" (click)=\"pause()\" [disabled]=\"pausedisabled\">\r\n        <i class=\"anticon anticon-pause-circle\"></i>\r\n      </button>\r\n      <button nz-button [nzType]=\"'ghost'\" (click)=\"increase()\">\r\n        <i class=\"anticon anticon-forward\"></i>\r\n      </button>\r\n    </nz-button-group>\r\n    <button nz-button [nzType]=\"'default'\" [nzSize]=\"small\" (click)=\"simulateHide($event)\" class=\"back-btn\">\r\n      <span>\u9000\u51FA\u6A21\u62DF</span>\r\n    </button>\r\n    <span class=\"startDate\">\u5F00\u59CB\u65F6\u95F4\uFF1A{{showStart? showStart : ''}}</span>\r\n    <span class=\"startDate\" *ngIf=\"finishDate\">\u6784\u4EF6\u5B8C\u6210\u65F6\u95F4\uFF1A{{finishDate? finishDate : ''}}</span>\r\n    <span class=\"startDate\" *ngIf=\"diffDate\">\u65F6\u5DEE\uFF1A{{diffDate? diffDate : ''}} \u5929</span>\r\n  </div> -->\r\n    <!-- <nz-modal [nzVisible]=\"simulateVisible\" [nzTitle]=\"'\u9009\u62E9\u65F6\u95F4\u6BB5'\" [nzContent]=\"modalContent\" (nzOnCancel)=\"simulateCancel($event)\"\r\n    (nzOnOk)=\"simulateOk()\">\r\n    <ng-template #modalContent>\r\n      <nz-date-picker style=\"width: 40%;\" [(ngModel)]=\"startDate\" (ngModelChange)=\"startDate=$event;startValueChange()\" [nzDisabledDate]=\"disabledStartDate\"\r\n        placeholder=\"'Start date'\"></nz-date-picker>\r\n      ~\r\n      <nz-date-picker style=\"width: 40%;\" [(ngModel)]=\"endDate\" (ngModelChange)=\"endDate=$event;endValueChange()\" [nzDisabledDate]=\"disabledEndDate\"\r\n        placeholder=\"'End date'\"></nz-date-picker>\r\n    </ng-template>\r\n  </nz-modal> -->\r\n    <!-- <nz-modal [nzVisible]=\"calenderVisible\" [nzTitle]=\"'\u65E5\u5386\u8BBE\u7F6E'\" [nzContent]=\"calenderContent\" (nzOnCancel)=\"calenderCancel()\"\r\n    (nzOnOk)=\"calenderOk()\">\r\n    <ng-template #calenderContent>\r\n      <div class=\"expect-day\" *ngIf=\"ganttService.currentGanttInfo && ganttService.currentGanttInfo.exceptDate\">\r\n        <div class=\"list\">\r\n          <div class=\"expectRow\" *ngFor=\"let date of ganttService.currentGanttInfo.exceptDate;let i = index\">\r\n            <input nz-input [(ngModel)]=\"date.name\" placeholder=\"'\u8BF7\u8F93\u5165\u540D\u79F0'\">\r\n            <nz-date-picker [(ngModel)]=\"date.startDate\" placeholder=\"'\u5F00\u59CB\u65F6\u95F4'\" (ngModelChange)=\"changeStartDate(date)\"></nz-date-picker>\r\n            ~\r\n            <nz-date-picker [(ngModel)]=\"date.endDate\" placeholder=\"'\u7ED3\u675F\u65F6\u95F4'\" (ngModelChange)=\"changeEndDate(date)\"></nz-date-picker>\r\n            <i class=\"anticon anticon-delete\" (click)=\"deletDate(i)\"></i>\r\n          </div>\r\n        </div>\r\n        <div class=\"addButton\">\r\n          <button nz-button [nzType]=\"'primary'\" (click)=\"addDate()\">\r\n            <span>\u589E\u52A0\u4F8B\u5916\u65E5\u671F</span>\r\n          </button>\r\n        </div>\r\n      </div>\r\n    </ng-template>\r\n  </nz-modal> -->\r\n</div>",
                styles: ["::ng-deep .toolbar{background:#fff}::ng-deep .toolbar .work-type{color:#454545;padding:0 25px;border-bottom:1px solid #ccc;box-shadow:1px 1px 1px #ccc}::ng-deep .toolbar .ant-switch-checked{background-color:#419fe8}::ng-deep .toolbar .close{float:right;width:20px;text-align:center;height:20px;line-height:20px;font-size:20px;cursor:pointer;position:relative;top:-2px}::ng-deep .toolbar .button-group{display:inline-block;font-size:0}::ng-deep .toolbar .button-group button{border-radius:0;margin-right:5px}::ng-deep .toolbar .button-group button.ant-btn-default{background:#454545;color:#fff}::ng-deep .toolbar .button-group button.ant-btn-default:hover{border-color:#8b8b8b;background:#959595}::ng-deep .toolbar .button-group button:last-child{margin-right:0}::ng-deep .toolbar .icon-group{background:#f9f9f9;border:1px solid #e5e5e5;overflow:hidden;height:40px}::ng-deep .toolbar .icon-group i{font-size:18px;color:#454545;cursor:pointer;margin:0 7px}::ng-deep .toolbar .icon-group .switch{position:relative;top:10px;float:right;margin:0 10px;right:57px}::ng-deep .toolbar .icon-group .sp{width:32px;height:32px;display:inline-block}::ng-deep .toolbar .icon-group .sp_calendar{background-image:url(/assets/images/sprite-icon.png);background-position:-100px -253px;cursor:pointer}::ng-deep .toolbar .icon-group .sp_add{background-image:url(/assets/images/sprite-icon.png);background-position:-100px -285px;cursor:pointer}::ng-deep .toolbar .icon-group .sp_delete{background-image:url(/assets/images/sprite-icon.png);background-position:-100px -349px;cursor:pointer}::ng-deep .toolbar .icon-group .sp_milestone{background-image:url(/assets/images/sprite-icon.png);background-position:-100px -381px;cursor:pointer}::ng-deep .toolbar .icon-group .sp_upLevel{background-image:url(/assets/images/sprite-icon.png);background-position:-100px -667px;cursor:pointer}::ng-deep .toolbar .icon-group .sp_downLevel{background-image:url(/assets/images/sprite-icon.png);background-position:-100px -635px;cursor:pointer}::ng-deep .toolbar .icon-group .sp_bind{background-image:url(/assets/images/sprite-icon.png);background-position:-100px -412px;cursor:pointer}::ng-deep .toolbar .icon-group .sp_unbind{background-image:url(/assets/images/sprite-icon.png);background-position:-100px -443px;cursor:pointer}::ng-deep .toolbar .icon-group .sp_addbind{background-image:url(/assets/images/sprite-icon.png);background-position:-100px -476px;cursor:pointer}::ng-deep .toolbar .icon-group .sp_configBind{background-image:url(/assets/images/sprite-icon.png);background-position:-100px -509px;cursor:pointer}::ng-deep .toolbar .icon-group .sp_play{background-image:url(/assets/images/sprite-icon.png);background-position:-100px -539px;cursor:pointer}::ng-deep .toolbar .icon-group .sp_save{background-image:url(/assets/images/sprite-icon.png);background-position:-100px -571px;cursor:pointer}::ng-deep .toolbar .icon-group .sp_refresh{background-image:url(/assets/images/sprite-icon.png);background-position:-100px -603px;cursor:pointer}::ng-deep .toolbar .icon-group .sp_compress{background-image:url(/assets/images/sprite-icon.png);background-position:-100px -253px;cursor:pointer}::ng-deep .toolbar .icon-group .sp_expand{background-image:url(/assets/images/sprite-icon.png);background-position:-100px -253px;cursor:pointer}.expectRow{margin:10px 0}:host ::ng-deep .expectRow nz-input{width:100px;margin-right:10px}.button-group{position:absolute;left:8px;top:60px}.back-btn{position:absolute;top:60px;left:180px}"]
            }] }
];
/** @nocollapse */
ToolBarComponent.ctorParameters = () => [
    { type: NzNotificationService },
    { type: NzModalService },
    { type: NzMessageService },
    { type: GanttHelperService },
    { type: GanttRequestService }
];
ToolBarComponent.propDecorators = {
    Xmpp: [{ type: Input }]
};
if (false) {
    /** @type {?} */
    ToolBarComponent.prototype.Xmpp;
    /** @type {?} */
    ToolBarComponent.prototype.ganttChecked;
    /** @type {?} */
    ToolBarComponent.prototype.selector;
    /** @type {?} */
    ToolBarComponent.prototype._percent;
    /** @type {?} */
    ToolBarComponent.prototype.interval;
    /** @type {?} */
    ToolBarComponent.prototype.simulate;
    /** @type {?} */
    ToolBarComponent.prototype.playdisabled;
    /** @type {?} */
    ToolBarComponent.prototype.pausedisabled;
    /** @type {?} */
    ToolBarComponent.prototype.startDate;
    /** @type {?} */
    ToolBarComponent.prototype.showStart;
    /** @type {?} */
    ToolBarComponent.prototype.endDate;
    /** @type {?} */
    ToolBarComponent.prototype.finishDate;
    /** @type {?} */
    ToolBarComponent.prototype.diffDate;
    /** @type {?} */
    ToolBarComponent.prototype.simulateVisible;
    /** @type {?} */
    ToolBarComponent.prototype.calenderVisible;
    /** @type {?} */
    ToolBarComponent.prototype.perStep;
    /** @type {?} */
    ToolBarComponent.prototype.currentStep;
    /** @type {?} */
    ToolBarComponent.prototype.uuids;
    /** @type {?} */
    ToolBarComponent.prototype.playTasks;
    /** @type {?} */
    ToolBarComponent.prototype.permission;
    /** @type {?} */
    ToolBarComponent.prototype.createNotification;
    /** @type {?} */
    ToolBarComponent.prototype.startValueChange;
    /** @type {?} */
    ToolBarComponent.prototype.endValueChange;
    /** @type {?} */
    ToolBarComponent.prototype.disabledEndDate;
    /** @type {?} */
    ToolBarComponent.prototype.showModal;
    /** @type {?} */
    ToolBarComponent.prototype.simulateCancel;
    /**
     * @type {?}
     * @private
     */
    ToolBarComponent.prototype._notification;
    /**
     * @type {?}
     * @private
     */
    ToolBarComponent.prototype.confirmServ;
    /**
     * @type {?}
     * @private
     */
    ToolBarComponent.prototype.message;
    /**
     * @type {?}
     * @private
     */
    ToolBarComponent.prototype.ganttHelpServ;
    /**
     * @type {?}
     * @private
     */
    ToolBarComponent.prototype.ganttRequestSev;
}

/**
 * @fileoverview added by tsickle
 * Generated from: lib/task-box/task-box.component.ts
 * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
// import { GanttPermission } from '../../../services/gantt-chart/this.Xmpp.permission';
class EditModel {
    /**
     * @param {?} param
     */
    constructor(param) {
        (param.relations) && (this.relations = param.relations);
        (param.taskName) && (this.taskName = param.taskName);
        (param.showDuration) && (this.showDuration = param.showDuration);
    }
}
if (false) {
    /** @type {?} */
    EditModel.prototype.relations;
    /** @type {?} */
    EditModel.prototype.taskName;
    /** @type {?} */
    EditModel.prototype.showDuration;
}
class TaskBoxComponent {
    /**
     * @param {?} _notification
     * @param {?} ganttHelpServ
     * @param {?} message
     */
    constructor(_notification, ganttHelpServ, message) {
        this._notification = _notification;
        this.ganttHelpServ = ganttHelpServ;
        this.message = message;
        this.newTaskBlur = new EventEmitter();
        this.isVisible = false;
        this.currentDate = moment();
        this.taskNameWidth = 100;
        this.prevTaskWidth = 0;
        this.headerWidth = 340;
        this.otherWidthTotal = 800;
        this.actualDisabled = true;
        this.isAllselected = false;
        // 前置任务编辑器
        this.editPermission = true;
        this.columnList = [];
        this.newTask = {
            id: -1,
            taskName: '',
            startDate: null,
            endDate: null
        };
        this.ctrlDown = false;
        this.settingModalView = false;
        this.PREVTYPE = PREVTYPE;
        this.clickTimer = null;
        this.createNotification = (/**
         * @param {?} type
         * @param {?} title
         * @param {?} message
         * @return {?}
         */
        (type, title, message) => {
            this._notification.create(type, title, message);
        });
        console.log(this.Xmpp);
        /** @type {?} */
        const that = this;
        document.onkeydown = (/**
         * @param {?} event
         * @return {?}
         */
        function (event) {
            /** @type {?} */
            const e = event || window.event || arguments.callee.caller.arguments[0];
            if (e && e.keyCode === 17) { // 按 Esc
                that.ctrlDown = true;
            }
        });
        document.onkeyup = (/**
         * @param {?} event
         * @return {?}
         */
        function (event) {
            /** @type {?} */
            const e = event || window.event || arguments.callee.caller.arguments[0];
            if (e && e.keyCode === 17) { // 按 Esc
                that.ctrlDown = false;
            }
        });
    }
    /**
     * @return {?}
     */
    ngOnInit() {
        // this.headerWidth = this.Xmpp.column.totalWidth;
        // this.columnList = this.Xmpp.column.columnNames;
    }
    /**
     * @param {?} c
     * @param {?} task
     * @param {?} open
     * @return {?}
     */
    editStuteChange(c, task, open) {
        if (open) {
            this.editTaskId = task.id;
            c.isEdit = true;
        }
        else {
            this.editTaskId = null;
            c.isEdit = false;
            if (c.key === 'duration' || c.key === 'actualDuration' || c.type === 'date') {
                this.Xmpp.render();
            }
        }
        setTimeout((/**
         * @return {?}
         */
        () => {
            // console.log(this.editInput)
            if (this.editInput) {
                this.editInput.nativeElement.focus();
            }
        }), 300);
    }
    /**
     * @param {?} $event
     * @param {?} column
     * @return {?}
     */
    resizeCallback($event, column) {
        /** @type {?} */
        const finder = this.Xmpp.column.columnNames.find((/**
         * @param {?} item
         * @return {?}
         */
        (item) => item.key === column.key));
        if (finder) {
            finder.width += $event.x;
            this.Xmpp.column.totalWidth += $event.x;
        }
    }
    /**
     * @param {?} type
     * @param {?} $event
     * @return {?}
     */
    addTaskFromNewLine(type, $event) {
        if (!$event || $event === '') {
            return;
        }
        this.Xmpp.task.activeTaskId = null;
        if (type === 'name' && $event !== '') {
            this.Xmpp.task.addTaskHandle({ taskName: $event });
        }
        if (type === 'startDate') {
            this.Xmpp.task.addTaskHandle({ startDate: $event, duration: 1 });
        }
        if (type === 'endDate') {
            this.Xmpp.task.addTaskHandle({ endDate: $event, duration: 1 });
        }
        this.newTask = {
            id: -1,
            taskName: '',
            startDate: null,
            endDate: null,
        };
        setTimeout((/**
         * @return {?}
         */
        () => {
            // this.newTask = null;
            this.newTaskBlur.emit();
            setTimeout((/**
             * @return {?}
             */
            () => {
                if (this.editInput) {
                    this.editInput.nativeElement.focus();
                }
            }), 500);
        }), 500);
    }
    // 工期blur
    /*
      工作安排中， 禁用计划完成时间早于当前时间的任务
      */
    /**
     * @param {?} endDate
     * @return {?}
     */
    isBeforeCurrent(endDate) {
        /** @type {?} */
        const isPlanning = false;
        if (isPlanning) {
            /** @type {?} */
            const currentDate = this.currentDate;
            /** @type {?} */
            const isBefore = moment(endDate).isBefore(currentDate);
            if (isBefore) {
                return true;
            }
            else {
                return false;
            }
        }
        else {
            return false;
        }
    }
    /*
      * 时间选择器
      */
    /**
     * @param {?} task
     * @return {?}
     */
    dateClickTask(task) {
        this.updateServiceData();
    }
    /**
     * @private
     * @return {?}
     */
    updateServiceData() {
        this.Xmpp.render();
    }
    /**
     * @param {?} task
     * @return {?}
     */
    foldTaskLevel(task) {
        /** @type {?} */
        const index = task.id - 1;
        /** @type {?} */
        const allTasks = this.Xmpp.allTasks;
        /** @type {?} */
        const children = allTasks[index].childTaskID;
        for (let i = 0; i < children.length; i++) {
            /** @type {?} */
            const child = children[i] - 1;
            allTasks[child].isSelected = false;
        }
        allTasks[index].isFold = true;
        this.Xmpp.render();
    }
    /**
     * @param {?} task
     * @return {?}
     */
    openTaskLevel(task) {
        /** @type {?} */
        const index = task.id - 1;
        this.Xmpp.allTasks[index].isFold = false;
        this.Xmpp.render();
    }
    // 全选
    /**
     * @return {?}
     */
    selectAllTask() {
        /** @type {?} */
        const allTasks = this.Xmpp.allTasks;
        /** @type {?} */
        const allSelected = this.isAllselected;
        if (allSelected) {
            allTasks.forEach((/**
             * @param {?} element
             * @return {?}
             */
            (element) => {
                element.isSelected = true;
            }));
            this.Xmpp.task.selectedTasks = this.Xmpp.allTasks;
        }
        else {
            allTasks.forEach((/**
             * @param {?} element
             * @return {?}
             */
            (element) => {
                element.isSelected = false;
            }));
            this.Xmpp.task.selectedTasks = [];
        }
        console.log(this.Xmpp.task.selectedTasks);
        // this.Xmpp.render();
    }
    /**
     * @return {?}
     */
    selectAll() {
        this.Xmpp.task.isAllSelect = !this.Xmpp.task.isAllSelect;
        if (this.Xmpp.task.isAllSelect) {
            this.Xmpp.task.selectedTasks = this.Xmpp.allTasks;
        }
        else {
            this.Xmpp.task.selectedTasks = [];
        }
        this.Xmpp.allTasks.forEach((/**
         * @param {?} task
         * @return {?}
         */
        task => {
            task.isSelected = this.Xmpp.task.isAllSelect;
        }));
        console.log(this.Xmpp.task.selectedTasks);
    }
    /**
     * @param {?=} task
     * @return {?}
     */
    clickTaskRow(task) {
        // if (!this.Xmpp.task.activeTaskId || (this.Xmpp.task.activeTaskId && this.Xmpp.task.activeTaskId !== task.id)) {
        //   this.Xmpp.task.activeTaskId = task.id;
        //   task.isSelected = true;
        // }
        clearTimeout(this.clickTimer);
        /** @type {?} */
        let that = this;
        this.clickTimer = setTimeout((/**
         * @return {?}
         */
        function () {
            if (that.ctrlDown) {
                task.isSelected = !task.isSelected;
                /** @type {?} */
                const index = that.Xmpp.task.selectedTasks.findIndex((/**
                 * @param {?} item
                 * @return {?}
                 */
                item => item.id === task.id));
                if (task.isSelected) {
                    if (index === -1) {
                        that.Xmpp.task.selectedTasks.push(task);
                    }
                }
                else {
                    if (index !== -1) {
                        that.Xmpp.task.selectedTasks.splice(index, 1);
                    }
                }
            }
            else {
                that.Xmpp.task.selectedTasks.forEach((/**
                 * @param {?} task
                 * @return {?}
                 */
                task => {
                    task.isSelected = false;
                }));
                task.isSelected = true;
                if (task.isSelected) {
                    that.Xmpp.task.selectedTasks = [task];
                }
                else {
                    that.Xmpp.task.selectedTasks = [];
                }
            }
            if (task.id !== -1) {
                /** @type {?} */
                const c = (/** @type {?} */ ((document.getElementById('maskCanvas'))));
                /** @type {?} */
                const ctxMask = c.getContext('2d');
                ctxMask.clearRect(0, 0, that.Xmpp.draw.canvasWidth, that.Xmpp.draw.canvasHeight);
                that.Xmpp.draw.drawSelectTask(task.id);
            }
        }), 300);
    }
    /**
     * 双击显示设置弹窗
     * @param {?} task
     * @return {?}
     */
    showSettings(task) {
        clearTimeout(this.clickTimer);
        /** @type {?} */
        const relations = [];
        task.prevRelation.forEach((/**
         * @param {?} ele
         * @return {?}
         */
        (ele) => {
            relations.push(ele);
        }));
        if (relations.length === 0) {
            relations.push(new XmppPredecessorLink({
                relation: 1,
                delay: 0
            }));
        }
        /** @type {?} */
        const showDuration = task.showDuration;
        this.editInfo = new EditModel({
            relations,
            taskName: task.taskName,
            showDuration
        });
        this.settingTask = task;
        this.settingModalView = true;
    }
    /**
     * 设置弹窗提交事件
     * @return {?}
     */
    settingSave() {
        /** @type {?} */
        const relations = this.editInfo.relations;
        /** @type {?} */
        const prevRelation = [];
        relations.forEach((/**
         * @param {?} element
         * @return {?}
         */
        (element) => {
            if (element.prevId && !isNullOrUndefined(element.relation)) {
                prevRelation.push(new XmppPredecessorLink({
                    id: element.id,
                    prevId: parseInt(element.prevId),
                    relation: element.relation,
                    delay: element.delay,
                    isDelete: element.isDelete
                }));
            }
        }));
        /** @type {?} */
        const checkResult = this.checkRelations(prevRelation);
        if (checkResult) {
            this.message.error(checkResult);
            // alert(checkResult);
        }
        else {
            this.settingTask.prevRelation = prevRelation;
            this.settingTask.taskName = this.editInfo.taskName;
            // currentTask.showDuration = this.editInfo.showDuration;
            this.getShowDuration(this.editInfo.showDuration);
            this.Xmpp.render();
            this.settingModalView = false;
        }
    }
    /**
     * @param {?} value
     * @return {?}
     */
    getShowDuration(value) {
        /** @type {?} */
        const wantedShow = value;
        /** @type {?} */
        const exceptDate = this.Xmpp.calendar.exceptDate;
        /** @type {?} */
        const startDate = this.settingTask.startDate;
        /** @type {?} */
        let endDate;
        if (startDate) {
            // 先判断有没有受例外日期的影响
            /** @type {?} */
            const startUnix1 = moment(startDate).unix();
            /** @type {?} */
            const endUnix1 = moment(startDate).add(wantedShow - 1, 'days').unix();
            // 先根据例外日期，改变任务的开始时间和结束时间
            exceptDate.forEach((/**
             * @param {?} item
             * @return {?}
             */
            (item) => {
                /** @type {?} */
                let toDate = moment(item.toDate).unix();
                /** @type {?} */
                let fromDate = moment(item.fromDate).unix();
                // 任务结束时间在例外日期之间
                if (endUnix1 <= toDate && endUnix1 >= fromDate) {
                    /** @type {?} */
                    const correctDate = moment(item.toDate).clone().add(1, 'days');
                    endDate = correctDate;
                }
            }));
            // 再统计任务中所有的例外日期总天数
            /** @type {?} */
            const startUnix2 = moment(startDate).unix();
            /** @type {?} */
            let endUnix2;
            if (endDate) {
                endUnix2 = moment(endDate).unix();
            }
            else {
                endDate = moment(startDate).add(wantedShow - 1, 'days');
                endUnix2 = endUnix1;
            }
            /** @type {?} */
            let allExcept = 0;
            exceptDate.forEach((/**
             * @param {?} item
             * @return {?}
             */
            (item) => {
                /** @type {?} */
                let toDate = moment(item.toDate).unix();
                /** @type {?} */
                let fromDate = moment(item.fromDate).unix();
                // 例外日期在任务的开始时间和结束时间之间
                if (startUnix2 <= toDate && endUnix2 >= fromDate) {
                    /** @type {?} */
                    const exceptDuration = moment(item.toDate).clone().diff(moment(item.fromDate), 'days') + 1;
                    allExcept = allExcept + exceptDuration;
                }
            }));
            /** @type {?} */
            const duration = moment(endDate).clone().diff(moment(startDate), 'days') + 1;
            /** @type {?} */
            const showCount = duration - allExcept;
            if (showCount !== wantedShow) {
                /** @type {?} */
                const changes = wantedShow - showCount;
                this.settingTask.duration = duration + changes;
            }
            else {
                this.settingTask.duration = duration;
            }
        }
        else {
            this.settingTask.duration = value;
            this.settingTask.showDuration = value;
        }
    }
    /**
     * @param {?} relations
     * @return {?}
     */
    checkRelations(relations) {
        /** @type {?} */
        let checkRepeat;
        /** @type {?} */
        let checkSameId;
        /** @type {?} */
        let checkLoop;
        /** @type {?} */
        let checkPrevId;
        /** @type {?} */
        const allTasks = this.Xmpp.allTasks;
        /** @type {?} */
        const taskLength = allTasks.length;
        /** @type {?} */
        const usefulRelation = [];
        relations.forEach((/**
         * @param {?} rela
         * @return {?}
         */
        (rela) => {
            if (!rela.isDelete) {
                usefulRelation.push(rela);
            }
        }));
        // 检查4: 非法字符
        usefulRelation.forEach((/**
         * @param {?} element
         * @return {?}
         */
        (element) => {
            /** @type {?} */
            const id = parseInt(element.prevId);
            if (isNaN(id)) {
                checkPrevId = `任务标识必须为数字`;
                return false;
            }
            else {
                if (id < 1 || id > taskLength) {
                    checkPrevId = `任务标识不存在, error:'${id}'`;
                    return false;
                }
            }
        }));
        // 检查1： 前置任务id重复
        usefulRelation.forEach((/**
         * @param {?} i
         * @return {?}
         */
        (i) => {
            /** @type {?} */
            const id = i.prevId;
            /** @type {?} */
            const idArray = [];
            usefulRelation.forEach((/**
             * @param {?} j
             * @return {?}
             */
            (j) => {
                if (j.prevId === id) {
                    idArray.push(j);
                }
            }));
            if (idArray.length > 1) {
                checkRepeat = `任务'${idArray[0]}'两次链接到同一个后续任务`;
                return;
            }
        }));
        // 检查2：prevId与任务Id相同
        usefulRelation.forEach((/**
         * @param {?} element
         * @return {?}
         */
        (element) => {
            /** @type {?} */
            const id = element.prevId;
            if (id === this.settingTask.id) {
                checkSameId = `前置任务不能为自己, error:${id}`;
                return;
            }
        }));
        // 检查3: 是否产生循环
        usefulRelation.forEach((/**
         * @param {?} element
         * @return {?}
         */
        (element) => {
            /** @type {?} */
            const id = element.prevId;
            /** @type {?} */
            const prevTask = allTasks[id - 1];
            /** @type {?} */
            let check;
            if (prevTask && prevTask.prevRelation.length > 0) {
                check = prevTask.prevRelation.findIndex((/**
                 * @param {?} relation
                 * @return {?}
                 */
                (relation) => {
                    return relation.prevId === this.settingTask.id;
                }));
                if (check !== -1) {
                    checkLoop = `任务'${id}'产生循环`;
                    return;
                }
            }
        }));
        if (checkPrevId) {
            return checkPrevId;
        }
        else if (checkRepeat) {
            return checkRepeat;
        }
        else if (checkSameId) {
            return checkSameId;
        }
        else if (checkLoop) {
            return checkLoop;
        }
        else {
            return false;
        }
    }
    /**
     * @return {?}
     */
    addRelation() {
        this.editInfo.relations.push(new XmppPredecessorLink({
            relation: 1,
            delay: 0
        }));
    }
    /**
     * @param {?} index
     * @return {?}
     */
    deleteRelation(index) {
        // this.editInfo.relations.splice(index, 1);
        this.editInfo.relations[index].isDelete = 1;
    }
    // clickTaskName(task: GanttModel) {
    //   // this.clickCheckBox(task)
    //   // let activeTask = this.Xmpp.task.activeTask;
    //   // if (!this.Xmpp.task.activeTask) {
    //   //   this.Xmpp.task.activeTask = task;
    //   // } else {
    //   //   if (this.Xmpp.task.activeTask.id == task.id) {
    //   //     this.Xmpp.task.activeTask = null
    //   //   } else {
    //   //     this.Xmpp.task.activeTask = task;
    //   //   }
    //   // }
    //   // console.log(this.Xmpp.task.activeTask)
    //   // this.Xmpp.draw.updateCanvasInfo();
    // }
    // public clickCheckBox(task) {
    //   this.Xmpp.task.caculateListener.next();
    // }
    /**
     * @return {?}
     */
    submitFinishBinds() {
        // this.ganttHelpServ.saveTasksHanle(this.Xmpp, 'save');
    }
    /**
     * @param {?} date
     * @return {?}
     */
    getActualDate(date) {
        if (date) {
            return moment(date).format('YYYY-MM-DD');
        }
        else {
            return false;
        }
    }
}
TaskBoxComponent.decorators = [
    { type: Component, args: [{
                selector: 'app-task-box',
                template: "<div class=\"ganttTaskBox zzj-scrollbar\">\r\n    <div class=\"toolHeader\" [style.width]=\"Xmpp.column.totalWidth+'px'\">\r\n        <div class=\"column id\" [style.width]=\"'30px'\" (click)=\"selectAll()\"></div>\r\n        <ng-container *ngFor=\"let c of Xmpp.column.columnNames\">\r\n            <ng-container *ngIf=\"c.key != 'checkbox'\">\r\n                <div class=\"column\" [style.width]=\"c.width+'px'\">\r\n                    {{c.name}}\r\n                </div>\r\n                <app-resize-bar *ngIf=\"c.resize\" [lazyMove]=\"true\" [mode]=\"'single-width'\" (resizeCallback)=\"resizeCallback($event, c)\">\r\n                </app-resize-bar>\r\n            </ng-container>\r\n\r\n            <ng-container *ngIf=\"c.key == 'checkbox'\">\r\n                <div class=\"column\" *ngIf=\"c.key == 'checkbox'\" [style.width]=\"c.width+'px'\">\r\n                    <label nz-checkbox [(ngModel)]=\"isAllselected\" (ngModelChange)=\"selectAllTask()\"></label>\r\n                </div>\r\n            </ng-container>\r\n        </ng-container>\r\n    </div>\r\n    <div class=\"task-list\" *ngIf=\"Xmpp.task.showTask?.length>0\">\r\n        <ng-container *ngFor=\"let task of Xmpp.task.showTask;let i = index\">\r\n            <div class=\"row\" [ngClass]=\"{'isSummary':task.childTaskID.length > 0,'gantt_active':task.isSelected}\" (dblclick)=\"showSettings(task)\" (click)=\"clickTaskRow(task)\" [style.width]=\"Xmpp.column.totalWidth+'px'\">\r\n                <div class=\"column id\" [style.width]=\"'30px'\">{{task.id}}</div>\r\n                <ng-container *ngFor=\"let c of Xmpp.column.columnNames\">\r\n\r\n                    <div class=\"column tags\" [style.width]=\"c.width+'px'\" *ngIf=\"c.type == 'tags'\">\r\n                        <ng-container *ngFor=\"let tag of task.tags\">\r\n                            <i *ngIf=\"!tag.iconUrl && tag.iconType\" nz-icon [nzType]=\"tag.iconType\" nzTheme=\"outline\"></i>\r\n                            <img *ngIf=\"tag.iconUrl\" [src]=\"tag.iconUrl\" alt=\"\">\r\n                        </ng-container>\r\n                    </div>\r\n\r\n                    <div class=\"column\" [style.width]=\"c.width+'px'\" *ngIf=\"c.type == 'checkbox'\">\r\n                        <label nz-checkbox [(ngModel)]=\"task.isSelected\"></label>\r\n                    </div>\r\n\r\n                    <div class=\"column\" [style.width]=\"c.width+'px'\" *ngIf=\"c.type == 'text'\" (click)=\"editStuteChange(c, task, true)\">\r\n                        <span *ngIf=\"!c.isEdit  || editTaskId != task.id\">{{task[c.key]}}</span>\r\n                        <input style=\"text-align: center;\" #editInput (blur)=\"editStuteChange(c, task, false)\" (keyup.enter)=\"editStuteChange(c, task, false)\" type=\"text\" *ngIf=\"c.isEdit && editTaskId == task.id\" [(ngModel)]=\"task[c.key]\">\r\n                    </div>\r\n\r\n\r\n                    <div *ngIf=\"c.type == 'taskName'\" class=\"column taskName\" (click)=\"editStuteChange(c, task, true)\" [style.width]=\"c.width+'px'\" [style.padding-left]=\"(task.level) * 15 + 'px'\">\r\n                        <i [style.left]=\"(task.level-1) * 15 + 'px'\" *ngIf=\"task.childTaskID.length > 0 && !task.isFold\" class=\"anticon anticon-caret-down\" (click)=\"foldTaskLevel(task)\"></i>\r\n                        <i [style.left]=\"(task.level-1) * 15 + 'px'\" *ngIf=\"task.childTaskID.length > 0 && task.isFold\" class=\"anticon anticon-caret-right\" (click)=\"openTaskLevel(task)\"></i>\r\n                        <div class=\"name\">\r\n                            <span *ngIf=\"!c.isEdit || editTaskId != task.id\">{{task.taskName}}</span>\r\n                            <input autoselect #editInput (blur)=\"editStuteChange(c, task, false)\" (keyup.enter)=\"editStuteChange(c, task, false)\" class=\"edit\" autofocus=\"autofocus\" type=\"text\" *ngIf=\"c.isEdit && editTaskId == task.id\" [(ngModel)]=\"task.taskName\">\r\n                        </div>\r\n                    </div>\r\n\r\n\r\n                    <div class=\"column\" (click)=\"editStuteChange(c, task, true)\" [style.width]=\"c.width+'px'\" *ngIf=\"c.type == 'date'\">\r\n                        <span *ngIf=\"!c.isEdit  || editTaskId != task.id\">{{task[c.key] | datePipe}}</span>\r\n                        <nz-date-picker *ngIf=\"c.isEdit && editTaskId == task.id\" [(ngModel)]=\"task[c.key]\" (ngModelChange)=\"editStuteChange(c, task, false)\" [nzAllowClear]=\"false\">\r\n                        </nz-date-picker>\r\n                    </div>\r\n\r\n                    <div class=\"resize_placeholder\" *ngIf=\"c.resize\"></div>\r\n                </ng-container>\r\n            </div>\r\n        </ng-container>\r\n        <ng-container *ngIf=\"(Xmpp.task.showTask.length < Xmpp.task.showTaskLength)\">\r\n            <div class=\"row\" *ngIf=\"newTask\" [ngClass]=\"{'gantt_active':newTask.isSelected}\">\r\n                <div class=\"column id\" [style.width]=\"'30px'\"><i nz-icon nzType=\"plus\" nzTheme=\"outline\"></i></div>\r\n                <ng-container *ngFor=\"let c of Xmpp.column.columnNames\">\r\n                    <!-- \u6807\u7B7E -->\r\n                    <div class=\"column\" [style.width]=\"c.width+'px'\" *ngIf=\"c.type == 'tags'\">\r\n                        <span></span>\r\n                    </div>\r\n                    <!-- \u591A\u9009\u6846 -->\r\n                    <div class=\"column\" [style.width]=\"c.width+'px'\" *ngIf=\"c.type == 'checkbox'\">\r\n                        <span style=\"width:100%\"></span>\r\n                    </div>\r\n                    <!-- \u6587\u672C -->\r\n                    <div class=\"column\" [style.width]=\"c.width+'px'\" *ngIf=\"c.type == 'text'\">\r\n                        <span style=\"width:100%\"></span>\r\n                    </div>\r\n                    <!-- \u4EFB\u52A1\u540D\u79F0 -->\r\n                    <div *ngIf=\"c.type == 'taskName'\" style=\"height: 100%;float: left\">\r\n                        <div class=\"column taskName\" [style.width]=\"c.width+'px'\" (click)=\"editStuteChange(c, newTask, true)\">\r\n                            <!-- <input class=\"newTask\" autofocus=\"autofocus\" #newTaskNameInput\r\n                                (blur)=\"addTaskFromNewLine('name', newTask.taskName)\"\r\n                                (keyup.enter)=\"addTaskFromNewLine('name', newTask.taskName)\"\r\n                                [(ngModel)]=\"newTask.taskName\" type=\"text\"> -->\r\n                            <span *ngIf=\"!c.isEdit || editTaskId != newTask.id\">{{newTask.taskName}}</span>\r\n                            <input autoselect #editInput (blur)=\"editStuteChange(c, newTask, false);addTaskFromNewLine('name', newTask.taskName)\" (keyup.enter)=\"editStuteChange(c, newTask, false);addTaskFromNewLine('name', newTask.taskName)\" class=\"edit\" autofocus=\"autofocus\" type=\"text\"\r\n                                *ngIf=\"c.isEdit && editTaskId == newTask.id\" [(ngModel)]=\"newTask.taskName\">\r\n                        </div>\r\n                        <div class=\"taskname_placeholder\"></div>\r\n                    </div>\r\n                    <!-- \u65E5\u671F\u9009\u62E9 -->\r\n                    <!-- <div class=\"column\" [style.width]=\"c.width+'px'\" *ngIf=\"c.type == 'date'\">\r\n                        <nz-date-picker [nzAllowClear]=\"false\" [ngModel]=\"newTask[c.key]\"\r\n                            (ngModelChange)=\"addTaskFromNewLine(c.key, $event)\">\r\n                        </nz-date-picker>\r\n                    </div> -->\r\n                    <div class=\"column\" (click)=\"editStuteChange(c, newTask, true)\" [style.width]=\"c.width+'px'\" *ngIf=\"c.type == 'date'\">\r\n                        <span *ngIf=\"!c.isEdit  || editTaskId != newTask.id\">{{newTask[c.key] | datePipe}}</span>\r\n                        <!-- <nz-date-picker *ngIf=\"c.isEdit && editTaskId === newTask.id\" [(ngModel)]=\"newTask[c.key]\" (ngModelChange)=\"addTaskFromNewLine(c.key, $event);c.isEdit =false;\" [nzAllowClear]=\"false\">\r\n                        </nz-date-picker> -->\r\n                        <input *ngIf=\"c.isEdit && editTaskId === newTask.id\" type=\"datetime\" [(ngModel)]=\"newTask[c.key]\" (ngModelChange)=\"addTaskFromNewLine(c.key, $event);c.isEdit =false;\">\r\n                    </div>\r\n                    <div class=\"resize_placeholder\" *ngIf=\"c.resize\"></div>\r\n                </ng-container>\r\n            </div>\r\n        </ng-container>\r\n    </div>\r\n    <!-- <nz-modal [nzVisible]=\"isVisible\" [nzTitle]=\"'\u9009\u62E9\u5B8C\u6210\u65F6\u95F4'\" [nzContent]=\"listContent\" (nzOnCancel)=\"handleCancel()\" (nzOnOk)=\"handleOk()\">\r\n    <ng-template #listContent>\r\n      <nz-date-picker [(ngModel)]=\"uuidDate\" placeholder=\"'Select date'\" [nzAllowClear]=\"false\"></nz-date-picker>\r\n    </ng-template>\r\n  </nz-modal> -->\r\n</div>\r\n\r\n\r\n<nz-modal class=\"settingModal\" [nzVisible]=\"settingModalView\" [nzTitle]=\"'\u8BBE\u7F6E'\" [nzContent]=\"settingContent\" (nzOnCancel)=\"settingModalView = false\" (nzOnOk)=\"settingSave()\">\r\n    <ng-template #settingContent>\r\n        <div class=\"content\" *ngIf=\"editInfo\">\r\n            <div class=\"name\">\r\n                <span>\u4EFB\u52A1\u540D\u79F0\uFF1A</span>\r\n                <input nz-input [(ngModel)]=\"editInfo.taskName\">\r\n            </div>\r\n            <div class=\"duration\">\r\n                <span>\u5DE5\u671F\uFF1A</span>\r\n                <nz-input-number [(ngModel)]=\"editInfo.showDuration\" [nzSize]=\"'small'\" [nzMin]=\"1\" [nzStep]=\"1\">\r\n                </nz-input-number>\r\n            </div>\r\n            <p class=\"line\">\r\n                <span>\u524D\u7F6E\u4EFB\u52A1</span>\r\n            </p>\r\n            <div class=\"relation\" *ngIf=\"Xmpp.allTasks.length > 0 \">\r\n                <div class=\"title\">\r\n                    <span>\u6807\u8BC6</span>\r\n                    <span>\u4EFB\u52A1\u540D</span>\r\n                    <span>\u7C7B\u578B</span>\r\n                    <span>\u5EF6\u9694\u5929\u6570</span>\r\n                </div>\r\n                <div class=\"row\" *ngFor=\"let item of editInfo.relations;let i = index\">\r\n                    <ng-container *ngIf=\"item.isDelete == 0\">\r\n                        <div class=\"item\">\r\n                            <nz-input-number [(ngModel)]=\"item.prevId\" [nzSize]=\"'small'\" [nzMin]=\"1\" [nzMax]=\"Xmpp.allTasks.length\" [nzStep]=\"1\"></nz-input-number>\r\n                        </div>\r\n                        <div class=\"item\">\r\n                            <nz-select style=\"width: 160px;\" placeholder=\"'\u9009\u62E9\u4E00\u4E2A\u4EFB\u52A1'\" [(ngModel)]=\"item.prevId\" [nzShowSearch]=\"true\">\r\n                                <nz-option *ngFor=\"let option of Xmpp.allTasks\" [nzLabel]=\"option.id+':'+option.taskName\" [nzValue]=\"option.id\">\r\n                                </nz-option>\r\n                            </nz-select>\r\n                        </div>\r\n                        <div class=\"item\">\r\n                            <nz-select [(ngModel)]=\"item.relation\" placeholder=\"'choose option'\">\r\n                                <nz-option [nzLabel]=\"'\u5B8C\u6210-\u5B8C\u6210(FF)'\" [nzValue]=\"PREVTYPE.FF\"></nz-option>\r\n                                <nz-option [nzLabel]=\"'\u5B8C\u6210-\u5F00\u59CB(FS)'\" [nzValue]=\"PREVTYPE.FS\"></nz-option>\r\n                                <nz-option [nzLabel]=\"'\u5F00\u59CB-\u5B8C\u6210(SF)'\" [nzValue]=\"PREVTYPE.SF\"></nz-option>\r\n                                <nz-option [nzLabel]=\"'\u5F00\u59CB-\u5F00\u59CB(SS)'\" [nzValue]=\"PREVTYPE.SS\"></nz-option>\r\n                            </nz-select>\r\n                        </div>\r\n                        <div class=\"item\">\r\n                            <nz-input-number [(ngModel)]=\"item.delay\" [nzSize]=\"'small'\" [nzMin]=\"0\" [nzStep]=\"1\">\r\n                            </nz-input-number>\r\n                        </div>\r\n                        <i nz-icon nzType=\"delete\" nzTheme=\"outline\" (click)=\"deleteRelation(i)\"></i>\r\n                        <i *ngIf=\"i == editInfo.relations.length-1\" class=\"anticon anticon-plus\" (click)=\"addRelation()\"></i>\r\n                    </ng-container>\r\n                </div>\r\n            </div>\r\n        </div>\r\n    </ng-template>\r\n</nz-modal>",
                styles: ["@charset \"UTF-8\";:host ::ng-deep .ant-menu-item-selected::after{opacity:0}::ng-deep .common-main-wrap .common-main-hd .common-bread-search{margin-top:0}a:active,a:focus,a:hover{outline:0;text-decoration:none}.zzj-scrollbar::-webkit-scrollbar{width:8px;height:6px;overflow:hidden}.zzj-scrollbar::-webkit-scrollbar-track{background-color:transparent}.zzj-scrollbar::-webkit-scrollbar-thumb{background-color:#acacac}.hidden-row{white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:100px}.hidden-row.long{max-width:150px}.hidden-row.longer{max-width:180px}.hidden-row.longest{max-width:210px}.hidden-row.auto{max-width:auto}.breadcrumb{height:70px;line-height:50px;font-size:14px;overflow:hidden}.breadcrumb .head-left{float:left}.breadcrumb .head-right{float:right}.common-bread-search{float:right;margin-top:10px;min-width:280px}.common-main-wrap{margin:30px}.common-main-wrap .common-main-hd{min-height:70px;padding-bottom:10px;line-height:50px;position:relative;z-index:5;overflow:hidden}.common-main-wrap .common-main-hd .common-bread-crumb{float:left;margin-top:23px}.common-main-wrap .common-main-hd .common-bread-search{float:right;margin-top:10px;min-width:280px}.common-main-wrap .common-main-hd .common-table-filter{float:right;margin-top:10px}@media screen and (max-width:1200px){.common-main-wrap .common-main-hd .common-bread-crumb,.common-main-wrap .common-main-hd .common-table-filter{float:none;display:block}}.common-main-wrap .common-main-cont{position:relative;height:auto}.common-table-wrap{border-radius:5px;overflow:hidden;background:#fff;box-shadow:0 0 8px #ddd}.common-table-wrap.auto .ant-table-wrapper{min-width:auto}.common-table-wrap .common-table-cont{max-height:660px;height:640px}.common-table-wrap .common-table-cont .ant-table-thead .ant-table-row th{background:-webkit-gradient(linear,left top,left bottom,from(#fff),to(#f8f8f8));background:linear-gradient(#fff,#f8f8f8);padding:10px}.common-table-wrap .ant-table-wrapper{overflow-x:auto;min-width:1300px}.common-table-wrap .common-pager{margin:10px;text-align:center;position:relative}.common-table-wrap .common-pager .common-pager-helper{float:left}.input-file{width:0;height:0;overflow:hidden;position:absolute;left:0;top:0;border:none;outline:0;box-shadow:none;opacity:0;cursor:pointer}.inner-layout,.outer-layout{height:60px;box-shadow:0 0 8px #ddd;position:relative;z-index:100;background:#fff;padding:0 25px}.inner-layout .inner-layout-left,.inner-layout .outer-layout-left,.outer-layout .inner-layout-left,.outer-layout .outer-layout-left{line-height:60px;float:left}.inner-layout .inner-layout-left img,.inner-layout .outer-layout-left img,.outer-layout .inner-layout-left img,.outer-layout .outer-layout-left img{vertical-align:middle}.inner-layout .inner-layout-right,.inner-layout .outer-layout-right,.outer-layout .inner-layout-right,.outer-layout .outer-layout-right{float:right;line-height:60px}.inner-layout .inner-layout-right a,.inner-layout .outer-layout-right a,.outer-layout .inner-layout-right a,.outer-layout .outer-layout-right a{color:#000}.inner-layout .inner-layout-right .inner-layout-right-user,.inner-layout .inner-layout-right .outer-layout-right-user,.inner-layout .outer-layout-right .inner-layout-right-user,.inner-layout .outer-layout-right .outer-layout-right-user,.outer-layout .inner-layout-right .inner-layout-right-user,.outer-layout .inner-layout-right .outer-layout-right-user,.outer-layout .outer-layout-right .inner-layout-right-user,.outer-layout .outer-layout-right .outer-layout-right-user{width:30px;height:30px}.common-table-status-green{color:#75bf03}.common-table-status-orange{color:orange}.common-table-status-red{color:red}.common-table-status-gray{color:#ccc}::ng-deep .ant-table-thead>tr>th{background-color:#fff}:host ::ng-deep .ant-tree li span.ant-tree-switcher.ant-tree-switcher_close .ant-tree-switcher-icon svg{width:18px;height:18px}:host ::ng-deep .ant-tree li span.ant-tree-switcher.ant-tree-switcher_open .ant-tree-switcher-icon svg{width:18px;height:18px}:host ::ng-deep .ant-table-fixed-header .ant-table-scroll .ant-table-header{overflow-y:hidden}::ng-deep.ant-input-affix-wrapper .ant-input-suffix{right:0}::ng-deep.ant-input-search.ant-input-search-enter-button>.ant-input{padding-right:46px}:host ::ng-deep .ant-table-body::-webkit-scrollbar{width:8px;height:6px;overflow:hidden}:host ::ng-deep .ant-table-body::-webkit-scrollbar-track{background-color:transparent}:host ::ng-deep .ant-table-body::-webkit-scrollbar-thumb{background-color:#acacac}::ng-deep .ant-modal-body{box-sizing:border-box}::ng-deep .ant-col-4{text-align:center}::ng-deep .ant-pagination-item-active,::ng-deep .ant-pagination-item-active:hover{background-color:#419fe8}::ng-deep .ant-pagination-item-active a,::ng-deep .ant-pagination-item-active:hover a{color:#fff}.ant-btn-primary:hover{background-color:#3d8fcd;border-color:#3d8fcd}.ant-btn-primary.disabled:hover,.ant-btn-primary[disabled],.ant-btn-primary[disabled]:hover{background-color:#f5f5f5;border-color:#d9d9d9}::ng-deep .ant-modal-close:hover{color:#419fe8!important}::ng-deep .ant-modal-confirm-error{top:300px}::ng-deep .ant-modal-confirm-confirm{top:300px}::ng-deep .ant-modal-confirm-btns .ant-btn:first-child{border-color:#d9d9d9;color:rgba(0,0,0,.65)}::ng-deep .ant-modal-confirm-btns .ant-btn:first-child:hover{color:#6cbef5;background-color:#fff;border-color:#6cbef5}.breadcrumb{color:#acacac}::ng-deep .ant-select-dropdown-menu::-webkit-scrollbar{width:8px;height:6px;overflow:hidden}::ng-deep .ant-select-dropdown-menu::-webkit-scrollbar-track{background-color:transparent}::ng-deep .ant-select-dropdown-menu::-webkit-scrollbar-thumb{background-color:#acacac}::ng-deep .ant-modal-header{padding-right:40px}::ng-deep .ant-table-placeholder{border-left:1px solid #e8e8e8;border-right:1px solid #e8e8e8}input[type=date]::-webkit-inner-spin-button{display:none}input[type=date]::-webkit-clear-button{display:none}.toolHeader{background:#fff;height:50px;border-bottom:1px solid #e5e5e5}.toolHeader .resize-bar{width:2px;background:#ccc;border:none}.toolHeader .column{float:left;padding:0 10px;height:100%;color:#000;line-height:50px;text-align:center;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;border-right:1px solid #ccc}.toolHeader .column span.disabled{color:#2dbdc5}.toolHeader .column.taskName{text-align:left;padding-left:13px;position:relative}.toolHeader .column.id{cursor:pointer}.toolHeader .column.id:hover{background:#999}.ganttTaskBox{position:absolute;top:0;bottom:0;width:100%;overflow:hidden;overflow-x:auto}.resize-bar{width:1px;cursor:col-resize;height:100%;float:left}.greyFont{color:#ccc}::ng-deep .task-list{position:absolute;bottom:0;top:50px}::ng-deep .task-list .row{cursor:pointer;height:36px;background:#fff;overflow:hidden;border-bottom:1px solid #e5e5e5;position:relative}::ng-deep .task-list .row.isSummary{font-weight:700}::ng-deep .task-list .row .column{float:left;padding:0 10px;height:100%;color:#000;line-height:36px;text-align:center;border-right:1px solid #ccc}::ng-deep .task-list .row .resize-bar{width:2px;background:#ccc}::ng-deep .task-list .gantt_active{background:rgba(65,159,232,.6)}::ng-deep .task-list .anticon-environment{color:#419fe8}::ng-deep .task-list .ant-checkbox-checked .ant-checkbox-inner,::ng-deep .task-list .ant-checkbox-indeterminate .ant-checkbox-inner{background-color:#419fe8;border-color:#419fe8}::ng-deep .task-list .ant-checkbox-input:focus+.ant-checkbox-inner,::ng-deep .task-list .ant-checkbox-wrapper:hover .ant-checkbox-inner,::ng-deep .task-list .ant-checkbox:hover .ant-checkbox-inner{border-color:#419fe8}.column:nth-child(1){width:40px}.column.id{background:#ccc}.column.tags{white-space:nowrap;text-overflow:ellipsis;overflow:hidden}.column.tags i,.column.tags img{margin:0 3px}.column.resize-bar{padding:0!important}.column.prevtask{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.column.prevtask span{white-space:nowrap;text-overflow:ellipsis;overflow:hidden;display:block}.column.startDate{width:120px}.column.duration{width:75px}.column.duration input{width:100%}.column.actualStartDate,.column.endDate{width:120px}.column.actualDuration{width:50px}.column.actualEndDate{width:120px}.column.finishRate,.column.finishSubmit,.column.submit{width:70px}.column.finishRate i,.column.submit i{cursor:pointer}.column.finishRate i:hover,.column.submit i:hover{color:#8a8a8a}::ng-deep .column input{border:none;outline:0;box-shadow:none;background:0 0;height:100%;width:100%}.column:nth-child(12) input,.column:nth-child(9) input{text-align:center}::ng-deep .ant-input-number{position:relative;padding:4px 7px;width:100%;cursor:text;line-height:1.5;color:rgba(0,0,0,.65);background-color:#fff;background-image:none;-webkit-transition:.3s;transition:.3s;margin:0;height:100%;display:inline-block;border:1px solid #d9d9d9}.resize_placeholder{width:2px;background:#ccc;height:100%;float:left}::ng-deep .column.taskName{position:relative;height:100%;float:left}::ng-deep .column.taskName .name{text-align:left;padding:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}::ng-deep .column.taskName .anticon-caret-down,::ng-deep .column.taskName .anticon-caret-right{-webkit-transform:scale(.7);transform:scale(.7);cursor:pointer;float:left;position:absolute;left:0;top:12px;z-index:9;font-size:15px;margin-right:4px}::ng-deep .column.taskName input.newTask{width:100%;height:100%;float:left;border:1px solid #ccc}::ng-deep .column.duration .ant-input{text-align:center}::ng-deep .gantt_isParent .ant-input{font-weight:700}::ng-deep .gantt_isChild .ant-input{padding-left:10px!important}::ng-deep .column .anticon{cursor:pointer}::ng-deep .settingModal .ant-modal-content{width:700px}::ng-deep .settingModal .name{display:inline-block;margin-left:10px}::ng-deep .settingModal .name input{width:200px}::ng-deep .settingModal .duration{display:inline-block;margin-left:20px}::ng-deep .settingModal .duration nz-input-number{width:100px}::ng-deep .settingModal .line{margin-top:10px;position:relative;height:20px;border-bottom:1px solid #419fe8;margin-bottom:10px;width:100%}::ng-deep .settingModal .line span{position:absolute;color:#419fe8;padding:10px;background:#fff;left:50%;-webkit-transform:translateX(-50%);transform:translateX(-50%)}::ng-deep .settingModal .relation{margin-top:15px}::ng-deep .settingModal .relation .row{width:100%;height:40px;line-height:40px;padding:0 10px}::ng-deep .settingModal .relation .title{padding:10px}::ng-deep .settingModal .relation .title span{display:inline-block;text-align:center}::ng-deep .settingModal .relation .title span:nth-child(1){width:80px}::ng-deep .settingModal .relation .title span:nth-child(2){width:180px}::ng-deep .settingModal .relation .title span:nth-child(3){width:130px}::ng-deep .settingModal .relation .title span:nth-child(4){width:100px}::ng-deep .settingModal .relation .row .item{display:inline-block}::ng-deep .settingModal .relation .row .item:nth-child(1){width:80px}::ng-deep .settingModal .relation .row .item:nth-child(2){width:180px;text-align:center}::ng-deep .settingModal .relation .row .item:nth-child(2) nz-select{width:160px}::ng-deep .settingModal .relation .row .item:nth-child(3){width:160px;text-align:center}::ng-deep .settingModal .relation .row .item:nth-child(4){width:100px}::ng-deep .settingModal .relation .anticon-delete{margin-left:5px}"]
            }] }
];
/** @nocollapse */
TaskBoxComponent.ctorParameters = () => [
    { type: NzNotificationService },
    { type: GanttHelperService },
    { type: NzMessageService }
];
TaskBoxComponent.propDecorators = {
    newTaskNameInput: [{ type: ViewChild, args: ['newTaskNameInput', { static: false },] }],
    editInput: [{ type: ViewChild, args: ['editInput', { static: false },] }],
    Xmpp: [{ type: Input }],
    newTaskBlur: [{ type: Output }]
};
if (false) {
    /** @type {?} */
    TaskBoxComponent.prototype.newTaskNameInput;
    /** @type {?} */
    TaskBoxComponent.prototype.editInput;
    /** @type {?} */
    TaskBoxComponent.prototype.Xmpp;
    /** @type {?} */
    TaskBoxComponent.prototype.newTaskBlur;
    /** @type {?} */
    TaskBoxComponent.prototype.isVisible;
    /** @type {?} */
    TaskBoxComponent.prototype.currentDate;
    /** @type {?} */
    TaskBoxComponent.prototype.taskNameWidth;
    /** @type {?} */
    TaskBoxComponent.prototype.prevTaskWidth;
    /** @type {?} */
    TaskBoxComponent.prototype.headerWidth;
    /** @type {?} */
    TaskBoxComponent.prototype.otherWidthTotal;
    /** @type {?} */
    TaskBoxComponent.prototype.actualDisabled;
    /** @type {?} */
    TaskBoxComponent.prototype.isAllselected;
    /** @type {?} */
    TaskBoxComponent.prototype.editPermission;
    /** @type {?} */
    TaskBoxComponent.prototype.columnList;
    /** @type {?} */
    TaskBoxComponent.prototype.newTask;
    /** @type {?} */
    TaskBoxComponent.prototype.ctrlDown;
    /** @type {?} */
    TaskBoxComponent.prototype.editTaskId;
    /** @type {?} */
    TaskBoxComponent.prototype.settingModalView;
    /** @type {?} */
    TaskBoxComponent.prototype.editInfo;
    /** @type {?} */
    TaskBoxComponent.prototype.PREVTYPE;
    /** @type {?} */
    TaskBoxComponent.prototype.settingTask;
    /** @type {?} */
    TaskBoxComponent.prototype.clickTimer;
    /** @type {?} */
    TaskBoxComponent.prototype.createNotification;
    /**
     * @type {?}
     * @private
     */
    TaskBoxComponent.prototype._notification;
    /**
     * @type {?}
     * @private
     */
    TaskBoxComponent.prototype.ganttHelpServ;
    /**
     * @type {?}
     * @private
     */
    TaskBoxComponent.prototype.message;
}

/**
 * @fileoverview added by tsickle
 * Generated from: lib/resize-bar/resize-bar.component.ts
 * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
class ResizeBarComponent {
    constructor() {
        // between-hor//两个水平
        // between-ver//两个垂直
        // single-hor
        // single-ver
        // single-width
        // single-height
        this.lazyMove = false;
        this.resizeCallback = new EventEmitter();
        this.childResizeLeft = 0;
        this.childOpacity = 1;
    }
    /**
     * @return {?}
     */
    get resizeChildStyle() {
        return {
            left: this.childResizeLeft + 'px',
            opacity: this.childOpacity
        };
    }
    /**
     * @return {?}
     */
    ngOnInit() {
    }
    /**
     * @param {?} event
     * @return {?}
     */
    mousedown(event) {
        event = event || window.event;
        if (event == null) {
            return;
        }
        event.stopPropagation();
        /** @type {?} */
        let preX = event.x;
        /** @type {?} */
        let preY = event.y;
        /** @type {?} */
        const startX = event.x;
        /** @type {?} */
        const startY = event.y;
        document.onmousemove = (/**
         * @param {?} evtMove
         * @return {?}
         */
        (evtMove) => {
            evtMove = evtMove || window.event;
            if (evtMove == null) {
                return;
            }
            /** @type {?} */
            const moveX = evtMove.x - preX;
            /** @type {?} */
            const moveY = evtMove.y - preY;
            this.resizing(moveX, moveY);
            preX = evtMove.x;
            preY = evtMove.y;
        });
        document.onmouseup = (/**
         * @param {?} evtUp
         * @return {?}
         */
        (evtUp) => {
            /** @type {?} */
            const moveX = evtUp.x - startX;
            /** @type {?} */
            const moveY = evtUp.y - startY;
            document.onmousemove = null;
            document.onmouseup = null;
            this.resizeCallback.emit({ x: moveX, y: moveY });
        });
    }
    /**
     * 懒拖拽
     * 先移动resize-bar，再改变两边的容器宽度
     * @param {?} event any
     * @return {?}
     */
    lazyMoveMouseDown(event) {
        event = event || window.event;
        if (event == null) {
            return;
        }
        event.stopPropagation();
        /** @type {?} */
        const startX = event.x;
        /** @type {?} */
        const startY = event.y;
        /** @type {?} */
        let preX = event.x;
        /** @type {?} */
        let preY = event.y;
        document.onmousemove = (/**
         * @param {?} evtMove
         * @return {?}
         */
        (evtMove) => {
            evtMove.stopPropagation();
            evtMove = evtMove || window.event;
            if (evtMove == null) {
                return;
            }
            /** @type {?} */
            const moveX = evtMove.x - preX;
            this.childResizeLeft += moveX;
            this.childOpacity = 0.5;
            preX = evtMove.x;
            preY = evtMove.y;
        });
        document.onmouseup = (/**
         * @param {?} evtUp
         * @return {?}
         */
        (evtUp) => {
            /** @type {?} */
            const moveX = evtUp.x - startX;
            /** @type {?} */
            const moveY = evtUp.y - startY;
            this.resizing(moveX, moveY);
            this.childResizeLeft = 0;
            this.childOpacity = 1;
            document.onmousemove = null;
            document.onmouseup = null;
            this.resizeCallback.emit({ x: moveX, y: moveY });
        });
    }
    /**
     * @param {?} moveX
     * @param {?} moveY
     * @return {?}
     */
    resizing(moveX, moveY) {
        if (this.mode === 'between-hor' || this.mode === 'between-ver') {
            this.resizeBoth(moveX, moveY);
        }
        if (this.mode === 'single-height' || 'single-width') {
            this.resizeSingle(moveX, moveY);
        }
    }
    /**
     * 改变两侧容器
     * @param {?} moveX 宽度改变的值
     * @param {?} moveY 高度改变的值
     * @return {?}
     */
    resizeBoth(moveX, moveY) {
        if (this.before == null || this.after == null) {
            return;
        }
        if (this.mode === 'between-hor') {
            /** @type {?} */
            const beforeW = this.before.width + moveX;
            /** @type {?} */
            const afterW = this.after.width - moveX;
            if (beforeW > 0 && afterW > 0) {
                this.before.width = beforeW;
                this.after.width = afterW;
            }
        }
        if (this.mode === 'between-ver') {
            /** @type {?} */
            const beforeH = this.before.height + moveY;
            /** @type {?} */
            const afterH = this.after.height - moveY;
            if (beforeH > 0 && afterH > 0) {
                this.before.height = beforeH;
                this.after.height = afterH;
            }
        }
    }
    /**
     * 只改变一侧容器
     * @param {?} moveX 宽度改变的值
     * @param {?} moveY 高度改变的值
     * @return {?}
     */
    resizeSingle(moveX, moveY) {
        if (this.single == null) {
            return;
        }
        if (this.mode === 'single-height') {
            /** @type {?} */
            const height = this.single.height - moveY;
            if (height > 0) {
                if (this.single.setHeight) {
                    this.single.setHeight(height);
                }
                else {
                    this.single.height = height;
                }
            }
        }
        if (this.mode === 'single-width') {
            /** @type {?} */
            const width = this.single.width - moveX;
            if (width > 0) {
                if (this.single.setWidth) {
                    this.single.setWidth(width);
                }
                else {
                    this.single.width = width;
                }
            }
        }
    }
}
ResizeBarComponent.decorators = [
    { type: Component, args: [{
                selector: 'app-resize-bar',
                template: "<!-- \u5373\u65F6\u6539\u53D8\u5BB9\u5668\u5BBD\u9AD8 -->\r\n<div class=\"separate noChild\" (mousedown)=\"mousedown($event)\" draggable=\"false\" *ngIf=\"!lazyMove\"></div>\r\n<!-- \u5148\u62D6\u62FD\u518D\u6539\u53D8\u5BB9\u5668\u5BBD\u9AD8 -->\r\n<div style=\"position:relative\" class=\"separate\" *ngIf=\"lazyMove\">\r\n    <div class=\"child\" (mousedown)=\"lazyMoveMouseDown($event)\"  draggable=\"false\"\r\n        [ngStyle]=\"resizeChildStyle\"></div>\r\n</div>",
                styles: [".separate{height:100%;width:2px;background:#ccc;float:left;cursor:col-resize}.separate .child{height:100%;background:#ccc;position:absolute;width:2px;z-index:99}.separate .child:hover{width:5px}.separate.noChild{position:relative;z-index:99}.separate.noChild:hover{width:5px}"]
            }] }
];
/** @nocollapse */
ResizeBarComponent.ctorParameters = () => [];
ResizeBarComponent.propDecorators = {
    lazyMove: [{ type: Input }],
    mode: [{ type: Input }],
    before: [{ type: Input }],
    after: [{ type: Input }],
    single: [{ type: Input }],
    single_width: [{ type: Input }],
    resizeCallback: [{ type: Output }]
};
if (false) {
    /** @type {?} */
    ResizeBarComponent.prototype.lazyMove;
    /** @type {?} */
    ResizeBarComponent.prototype.mode;
    /** @type {?} */
    ResizeBarComponent.prototype.before;
    /** @type {?} */
    ResizeBarComponent.prototype.after;
    /** @type {?} */
    ResizeBarComponent.prototype.single;
    /** @type {?} */
    ResizeBarComponent.prototype.single_width;
    /** @type {?} */
    ResizeBarComponent.prototype.resizeCallback;
    /** @type {?} */
    ResizeBarComponent.prototype.childResizeLeft;
    /** @type {?} */
    ResizeBarComponent.prototype.childOpacity;
}

/**
 * @fileoverview added by tsickle
 * Generated from: lib/src/lib/gantt.main.ts
 * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
// @dynamic
class Project {
    /**
     * @param {?} container
     * @param {?} options
     * @return {?}
     */
    static newProject(container, options) {
        return __awaiter(this, void 0, void 0, function* () {
            /** @type {?} */
            const factory = Project.resolver.resolveComponentFactory(GanttComponent);
            /** @type {?} */
            const componentRef = container.createComponent(factory);
            yield componentRef.instance.initProject(options);
            return componentRef;
        });
    }
}
if (false) {
    /** @type {?} */
    Project.resolver;
}

/**
 * @fileoverview added by tsickle
 * Generated from: lib/pipes/Date.pipe.ts
 * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
class DatePipe {
    /**
     * @param {?} value
     * @param {...?} args
     * @return {?}
     */
    transform(value, ...args) {
        /** @type {?} */
        let result = '';
        if (value && value !== '') {
            result = moment(value).format('YYYY-MM-DD');
        }
        return result;
    }
}
DatePipe.decorators = [
    { type: Pipe, args: [{
                name: 'datePipe'
            },] }
];

/**
 * @fileoverview added by tsickle
 * Generated from: lib/pipes/gantt-pipe.module.ts
 * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
class GanttPipeModule {
}
GanttPipeModule.decorators = [
    { type: NgModule, args: [{
                declarations: [DatePipe],
                imports: [
                    CommonModule
                ],
                exports: [DatePipe]
            },] }
];

/**
 * @fileoverview added by tsickle
 * Generated from: lib/gantt-chart.module.ts
 * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
const ɵ0 = PREVTYPE, ɵ1 = GanttSize;
// import { GanttComponent } from './gantt-chart.component';
// import { BuildLogService } from '../../services/project/build-logs/build-log.service';
class GanttChartModule {
    /**
     * @param {?} resolver
     */
    constructor(resolver) {
        this.resolver = resolver;
        Project.resolver = resolver;
    }
}
GanttChartModule.decorators = [
    { type: NgModule, args: [{
                imports: [
                    CommonModule,
                    FormsModule,
                    NgZorroAntdModule,
                    GanttPipeModule
                    // NgZzjModule,
                    // RouterModule.forChild([{ path: "", component: GanttComponent }])
                ],
                exports: [GanttComponent],
                declarations: [ResizeBarComponent, GanttComponent, ToolBarComponent, TaskBoxComponent, GanttBoxComponent],
                providers: [GanttHelperService, GanttRequestService, {
                        provide: 'PREVTYPE',
                        useValue: ɵ0
                    }, {
                        provide: 'GanttSize',
                        useValue: ɵ1
                    }],
                entryComponents: [
                    GanttComponent
                ]
            },] }
];
/** @nocollapse */
GanttChartModule.ctorParameters = () => [
    { type: ComponentFactoryResolver }
];
if (false) {
    /**
     * @type {?}
     * @private
     */
    GanttChartModule.prototype.resolver;
}

/**
 * @fileoverview added by tsickle
 * Generated from: public-api.ts
 * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */

/**
 * @fileoverview added by tsickle
 * Generated from: zzj-zzj-xmpp.ts
 * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */

export { EXTENDATTRS, GanttChartModule, GanttComponent, GanttMethod, GanttProjectModel, GanttRequestService, GanttSize, PREVTYPE, PROJECTID, Project, UInfoModel, Xmpp, XmppPredecessorLink, XmppTask, XmppWeekDayType, GanttPipeModule as ɵa, DatePipe as ɵb, GanttBoxComponent as ɵc, GanttHelperService as ɵd, RequestClientService as ɵe, ResizeBarComponent as ɵf, ToolBarComponent as ɵg, TaskBoxComponent as ɵh };
//# sourceMappingURL=zzj-zzj-xmpp.js.map
