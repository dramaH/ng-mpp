export const environment = {
  production: true,
  mppUrl: 'http://kzzbim.spddemo.com:88',
  ganttSrc: '@zzj/zzj-xmpp'
};
